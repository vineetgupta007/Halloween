terraform {
  required_providers {
    saviynt = {
      source  = "saviynt/saviynt"
      version = ">= 0.3.3"
    }
  }
}

resource "saviynt_endpoint_resource" "this" {
  for_each = var.endpoints

  # --- Required Core Fields ---
  # Assuming endpoint_name is the key in the map
  endpoint_name   = each.key

  # Requires exact match to your CSV headers (e.g., 'display_name', 'security_system')
  display_name    = try(each.value.display_name != "" ? each.value.display_name : each.key, each.key)
  security_system = each.value.associated_system

  # --- General Info ---
  description = try(each.value.description != "" ? each.value.description : "Managed by Terraform", "Managed by Terraform")
  owner_type  = try(each.value.owner_type != "" ? each.value.owner_type : "User", "User")

  # --- Boolean / Action Toggles ---
  requestable                                   = try(each.value.requestable != "" ? each.value.requestable : "true", "true")
  enable_copy_access                            = try(each.value.enable_copy_access != "" ? each.value.enable_copy_access : "true", "true")
  disable_new_account_request_if_account_exists = try(each.value.disable_new_acc_if_exists != "" ? each.value.disable_new_acc_if_exists : "false", "false")
  disable_remove_account                        = try(each.value.disable_remove_account != "" ? each.value.disable_remove_account : "false", "false")
  disable_modify_account                        = try(each.value.disable_modify_account != "" ? each.value.disable_modify_account : "false", "false")
  block_inflight_request                        = try(each.value.block_inflight_request != "" ? each.value.block_inflight_request : "false", "false")
  create_ent_task_for_remove_acc                = try(each.value.create_ent_task_for_remove_acc != "" ? each.value.create_ent_task_for_remove_acc : "true", "true")
  allow_remove_all_role_on_request              = try(each.value.allow_remove_all_role_on_request != "" ? each.value.allow_remove_all_role_on_request : "false", "false")

  # --- Rules & Actions ---
  user_account_correlation_rule = try(each.value.correlation_rule != "" ? each.value.correlation_rule : "SQL###(users.username) = accounts.customproperty1", "SQL###(users.username) = accounts.customproperty1")
  out_of_band_action            = try(each.value.out_of_band_action != "" ? each.value.out_of_band_action : "2", "2")
  # account_name_rule             = try(each.value.account_name_rule != "" ? each.value.account_name_rule : null, "(users.username)")
  # account_name_rule             = try(each.value.account_name_rule != "" ? each.value.account_name_rule : null, null)
  account_name_validator_regex  = try(each.value.name_regex != "" ? each.value.name_regex : "^[a-zA-Z0-9_. -]{5,15}$", "^[a-zA-Z0-9_. -]{5,15}$")

  # --- JSON Configurations ---
  # Defaulting to null if empty so Saviynt uses its own internal defaults
  status_config   = try(each.value.status_config != "" ? each.value.status_config : null, null)
  plugin_configs  = try(each.value.plugin_configs != "" ? each.value.plugin_configs : null, null)
  endpoint_config = try(each.value.endpoint_config != "" ? each.value.endpoint_config : null, null)

  # --- Queries ---
  # Defaulting to null if empty, otherwise it will try to run an empty query
  access_query                    = try(each.value.access_query != "" ? each.value.access_query : null, null)
  service_account_access_query    = try(each.value.svc_access_query != "" ? each.value.svc_access_query : null, null)
  allow_change_password_sql_query = try(each.value.pwd_change_query != "" ? each.value.pwd_change_query : null, null)
  change_password_access_query    = try(each.value.change_pwd_access_query != "" ? each.value.change_pwd_access_query : null, null)

  # --- Custom Properties (Data) ---
  custom_property1 = try(each.value.cp1 != "" ? each.value.cp1 : null, null)
  custom_property2 = try(each.value.cp2 != "" ? each.value.cp2 : null, null)
  custom_property3 = try(each.value.cp3 != "" ? each.value.cp3 : null, null)
  custom_property4 = try(each.value.cp4 != "" ? each.value.cp4 : null, null)
  custom_property5 = try(each.value.cp5 != "" ? each.value.cp5 : null, null)

  # --- Custom Properties (Labels) ---
  account_custom_property_1_label = try(each.value.cp1_label != "" ? each.value.cp1_label : "Attribute 1", "Attribute 1")
  account_custom_property_2_label = try(each.value.cp2_label != "" ? each.value.cp2_label : "Attribute 2", "Attribute 2")
  account_custom_property_3_label = try(each.value.cp3_label != "" ? each.value.cp3_label : "Attribute 3", "Attribute 3")
  account_custom_property_4_label = try(each.value.cp4_label != "" ? each.value.cp4_label : "Attribute 4", "Attribute 4")
  account_custom_property_5_label = try(each.value.cp5_label != "" ? each.value.cp5_label : "Attribute 5", "Attribute 5")

  # Example showing up to 60 as requested in template
  custom_property60_label = try(each.value.cp60_label != "" ? each.value.cp60_label : "Custom Label 60", "Custom Label 60")

  lifecycle {
    prevent_destroy = false
  }
}
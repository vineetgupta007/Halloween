// Copyright (c) 2025 Saviynt Inc.
// SPDX-License-Identifier: MPL-2.0

terraform {
  required_providers {
    saviynt = {
      source  = "saviynt/saviynt"
      version = ">= 0.3.3"
    }
  }
}

# --- VARIABLES ---

variable "trigger_base_name" {
  description = "Base name for the job trigger (from your CSV)"
  type        = string
}

variable "security_system" {
  description = "The name of the security system (from your CSV)"
  type        = string
}

# --- RESOURCE ---

resource "saviynt_ws_retry_job_resource" "system_ws_retry_job" {
  jobs = [
    {
      # Appends "_WS_Retry" to the base name from your CSV
      trigger_name     = "${var.trigger_base_name}_WS_Retry"
      job_group        = "utility"

      # Runs every hour on the 15-minute mark (adjust as needed for your enterprise)
      cron_expression  = "0 15 * * * ?"
      trigger_group    = "GRAILS_JOBS"

      # IMPORTANT: The resource expects a list, so we wrap your string variable in brackets
      security_systems = [var.security_system]

      # Retries specific task types (e.g., 1=Create, 2=Update, 3=Add Access, etc.)
      task_types       = "1,2,3,4,5"
    }
  ]
}
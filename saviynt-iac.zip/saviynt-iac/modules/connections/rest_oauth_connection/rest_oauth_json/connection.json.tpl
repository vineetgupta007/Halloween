{
    "authentications": {
      "acctAuth": {
        "authType": "oauth2",
        "url": "${ping_host}/fss/as/token.oauth2",
        "httpParams": {
          "grant_type": "client_credentials",
          "scope": "api",
          "client_id": "${ping_client_id}",
          "client_secret": "${ping_client_secret}"
        },
        "httpHeaders": {
          "Content-Type": "application/x-www-form-urlencoded"
        },
        "authError": [
          "InvalidAuthenticationToken"
        ],
        "httpMethod": "POST",
        "httpContentType": "application/x-www-form-urlencoded",
        "errorPath": "error.code",
        "maxRefreshTryCount": 5,
        "tokenResponsePath": "access_token",
        "tokenType": "Bearer",
        "retryFailureStatusCode": [
          401
        ],
        "accessToken": "Bearer token"
      }
    }
  }
// Copyright (c) 2025 Saviynt Inc.
// SPDX-License-Identifier: MPL-2.0

terraform {
  required_providers {
    saviynt = {
      source  = "saviynt/saviynt"
      version = ">= 0.3.3"
    }
  }
}

variable "rest_oauth_connection_name" {
  type        = string
  description = "The unique name for the REST OAuth Connection"
  default     = "PingDirectory REST OAuth Connection"
}

variable "ping_host" {
  type        = string
  description = "PingDirectory host URL"
  validation {
    condition     = can(regex("^https://", var.ping_host))
    error_message = "ping_host must start with https://"
  }
}

variable "ping_client_id" {
  type        = string
  description = "OAuth2 Client ID"
}

variable "ping_client_secret" {
  type        = string
  description = "OAuth2 Client Secret"
  sensitive   = true
}

variable "ping_base_dn" {
  type        = string
  description = "Base DN"
  default     = "dc=example,dc=com"
}

variable "ping_users_dn" {
  type        = string
  description = "Users OU DN"
  default     = "ou=Users,dc=example,dc=com"
}

variable "ping_groups_dn" {
  type        = string
  description = "Groups OU DN"
  default     = "ou=Groups,dc=example,dc=com"
}

locals {
  template_vars = {
    ping_host           = var.ping_host
    ping_client_id      = var.ping_client_id
    ping_client_secret  = var.ping_client_secret
    ping_base_dn        = var.ping_base_dn
    ping_users_dn       = var.ping_users_dn
    ping_groups_dn      = var.ping_groups_dn
  }
}

resource "saviynt_rest_connection_resource" "rest_connection" {
  connection_name         = var.rest_oauth_connection_name
  connection_json         = templatefile("${path.module}/rest_oauth_json/connection.json.tpl",         local.template_vars)
  import_account_ent_json = templatefile("${path.module}/rest_oauth_json/import_account_ent.json.tpl", local.template_vars)
  # add_access_json         = templatefile("${path.module}/rest_json/import_account_ent.json.tpl", local.template_vars)
  # remove_access_json      = templatefile("${path.module}/rest_json/import_account_ent.json.tpl", local.template_vars)
  status_threshold_config = file("${path.module}/rest_oauth_json/status_threshold_config.json")
}
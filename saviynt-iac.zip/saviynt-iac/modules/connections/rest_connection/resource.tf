// Copyright (c) 2025 Saviynt Inc.
// SPDX-License-Identifier: MPL-2.0

terraform {
  required_providers {
    saviynt = {
      source  = "saviynt/saviynt"
      version = ">= 0.3.3"
    }
  }
}

variable "rest_connection_name" {
  type        = string
  description = "The unique name for the REST Connection"
  default     = "PingDirectory REST Connection"
}

variable "ping_host" {
  type        = string
  description = "PingDirectory host URL"
  validation {
    condition     = can(regex("^https://", var.ping_host))
    error_message = "ping_host must start with https://"
  }
}

variable "ping_base_dn" {
  type        = string
  description = "Base DN"
  default     = "dc=example,dc=com"
}

variable "ping_users_dn" {
  type        = string
  description = "Users OU DN"
  default     = "ou=Users,dc=example,dc=com"
}

variable "ping_groups_dn" {
  type        = string
  description = "Groups OU DN"
  default     = "ou=Groups,dc=example,dc=com"
}

variable "ping_admin_dn" {
  type        = string
  description = "Admin bind DN for PingDirectory"
  default     = "uid=DirectoryAdmin,ou=geworker,o=gevernova.com"
}

variable "ping_admin_password" {
  type        = string
  description = "Admin bind password for PingDirectory"
  sensitive   = true
}

locals {
  template_vars = {
    ping_host           = var.ping_host
    ping_base_dn        = var.ping_base_dn
    ping_users_dn       = var.ping_users_dn
    ping_groups_dn      = var.ping_groups_dn
    ping_admin_dn       = var.ping_admin_dn
    ping_admin_password = var.ping_admin_password
  }
}

resource "saviynt_rest_connection_resource" "rest_connection" {
  connection_name         = var.rest_connection_name
  connection_json         = templatefile("${path.module}/rest_json/connection.json.tpl",         local.template_vars)
  import_account_ent_json = templatefile("${path.module}/rest_json/import_account_ent.json.tpl", local.template_vars)
  # add_access_json         = templatefile("${path.module}/rest_json/import_account_ent.json.tpl", local.template_vars)
  # remove_access_json      = templatefile("${path.module}/rest_json/import_account_ent.json.tpl", local.template_vars)
  status_threshold_config = file("${path.module}/rest_json/status_threshold_config.json")
}
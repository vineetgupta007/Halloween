{
	"globalSettings": {
		"dateFormat": "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
		"userSourceList": [
			"ALL"
		]
	},
	"accountParams": {
		"connection": "acctAuth",
		"processingType": "SequentialAndIterative",
		"statusAndThresholdConfig": {
			"accountThresholdValue": 200000,
			"inactivateAccountsNotInFile": true,
			"deleteAccountsNotInFile": false
		},
		"successResponses": {
			"statusCode": [
				200,
				201,
				202,
				203,
				204,
				205
			]
		},
		"call": {
			"call1": {
				"callOrder": 0,
				"stageNumber": 0,
				"http": {
					"url": "${ping_host}/directory/v1/${ping_users_dn}/subtree?searchScope=wholeSubtree&filter=(isMemberOf%20eq%20%22cn=Test-AAG-1,ou=Groups,o=gevernova.com%22%20or%20isMemberOf%20eq%20%22cn=Test-AAG-2,ou=Groups,o=gevernova.com%22%20or%20isMemberOf%20eq%20%22cn=Test-AAG-3,ou=Groups,o=gevernova.com%22%20or%20isMemberOf%20eq%20%22cn=Test-AAG-4,ou=Groups,o=gevernova.com%22)%20and%20objectClass%20eq%20%22inetOrgPerson%22&includeAttributes=cn,uid,entryUUID,givenName,sn,entryDN,createTimestamp,modifyTimestamp,objectClass&limit=1000",
					"httpHeaders": {
						"Authorization": "$${access_token}",
						"Accept": "application/json"
					},
					"httpContentType": "application/json",
					"httpMethod": "GET"
				},
				"listField": "_embedded.entries",
				"keyField": "accountID",
				"colsToPropsMap": {
					"DISPLAYNAME": "cn~#~char",
					"name": "uid~#~char",
					"accountID": "entryUUID~#~char",
					"COMMENTS": "description~#~char",
					"CUSTOMPROPERTY1": "givenName~#~char",
					"CUSTOMPROPERTY2": "sn~#~char",
					"CUSTOMPROPERTY3": "_dn~#~char",
					"updatedate": "modifyTimestamp~#~date",
					"createdate": "createTimestamp~#~date",
					"CUSTOMPROPERTY4": "objectClass~#~char"
				},
				"doNotChangeIfFailed": true
			}
		}
	},
	"entitlementParams": {
		"processingType": "SequentialAndIterative",
		"entTypes": {
			"Group": {
				"entTypeOrder": 0,
				"entTypeLabels": {},
				"successResponses": {
					"statusCode": [
						200,
						201,
						202,
						203,
						204,
						205
					]
				},
				"call": {
					"call1": {
						"connection": "acctAuth",
						"callOrder": 0,
						"stageNumber": 0,
						"http": {
							"url": "${ping_host}/directory/v1/${ping_groups_dn}/subtree?searchScope=wholeSubtree&filter=cn%20eq%20%22Test-AAG-1%22%20or%20cn%20eq%20%22Test-AAG-2%22%20or%20cn%20eq%20%22Test-AAG-3%22%20or%20cn%20eq%20%22Test-AAG-4%22%20or%20cn%20eq%20%22Test-AAG-5%22&includeAttributes=cn,displayName,entryDN,entryUUID,description,createTimestamp,modifyTimestamp,objectClass&limit=1000",
							"httpHeaders": {
								"Authorization": "$${access_token}",
								"Accept": "application/json"
							},
							"httpContentType": "application/json",
							"httpMethod": "GET"
						},
						"listField": "_embedded.entries",
						"keyField": "entitlementID",
						"colsToPropsMap": {
							"entitlementID": "entryUUID~#~char",
							"description": "description~#~char",
							"entitlement_value": "cn~#~char",
							"displayname": "cn~#~char",
							"updatedate": "modifyTimestamp~#~date",
							"createdate": "createTimestamp~#~date",
							"customproperty1": "cn~#~char",
							"customproperty2": "_dn~#~char",
							"customproperty3": "objectClass~#~char"
						},
						"doNotChangeIfFailed": true,
						"disableDeletedEntitlements": true
					}
				}
			},
			"Parent": {
				"entTypeOrder": 1,
				"entTypeLabels": {},
				"successResponses": {
					"statusCode": [
						200,
						201,
						202,
						203,
						204,
						205
					]
				},
				"call": {
					"call1": {
						"connection": "acctAuth",
						"callOrder": 0,
						"stageNumber": 0,
						"http": {
							"url": "${ping_host}/directory/v1/${ping_groups_dn}/subtree?searchScope=wholeSubtree&filter=cn%20eq%20%22Test-AAG-6%22%20or%20cn%20eq%20%22Test-AAG-7%22%20or%20cn%20eq%20%22Test-AAG-8%22%20or%20cn%20eq%20%22Test-AAG-9%22%20or%20cn%20eq%20%22Test-AAG-11%22&includeAttributes=cn,displayName,entryDN,entryUUID,description,createTimestamp,modifyTimestamp,objectClass&limit=1000",
							"httpHeaders": {
								"Authorization": "$${access_token}",
								"Accept": "application/json"
							},
							"httpContentType": "application/json",
							"httpMethod": "GET"
						},
						"listField": "_embedded.entries",
						"keyField": "entitlementID",
						"colsToPropsMap": {
							"entitlementID": "entryUUID~#~char",
							"description": "description~#~char",
							"entitlement_value": "cn~#~char",
							"displayname": "cn~#~char",
							"updatedate": "modifyTimestamp~#~date",
							"createdate": "createTimestamp~#~date",
							"customproperty1": "cn~#~char",
							"customproperty2": "_dn~#~char",
							"customproperty3": "objectClass~#~char"
						},
						"doNotChangeIfFailed": true,
						"disableDeletedEntitlements": true
					}
				}
			}
		}
	},
	"acctEntParams": {
		"entTypes": {
			"Group": {
				"successResponses": {
					"statusCode": [
						200,
						201,
						202,
						203,
						204,
						205
					]
				},
				"call": {
					"call1": {
						"connection": "acctAuth",
						"processingType": "httpEntToAcct",
						"http": {
							"url": "${ping_host}/directory/v1/${ping_groups_dn}/subtree?searchScope=wholeSubtree&filter=cn%20eq%20%22$${id}%22&includeAttributes=cn,entryUUID,member,objectClass",
							"httpContentType": "application/json",
							"httpMethod": "GET",
							"httpHeaders": {
								"Authorization": "$${access_token}",
								"Accept": "application/json"
							}
						},
						"listField": "_embedded.entries[0].member",
						"entKeyField": "entitlementID",
						"acctIdPath": "",
						"acctKeyField": "customproperty3",
						"doNotChangeIfFailed": true
					}
				}
			},
			"Parent": {
				"successResponses": {
					"statusCode": [
						200,
						201,
						202,
						203,
						204,
						205
					]
				},
				"call": {
					"call1": {
						"connection": "acctAuth",
						"processingType": "httpEntToAcct",
						"http": {
							"url": "${ping_host}/directory/v1/${ping_groups_dn}/subtree?searchScope=wholeSubtree&filter=cn%20eq%20%22$${id}%22&includeAttributes=cn,entryUUID,member,objectClass",
							"httpContentType": "application/json",
							"httpMethod": "GET",
							"httpHeaders": {
								"Authorization": "$${access_token}",
								"Accept": "application/json"
							}
						},
						"listField": "_embedded.entries[0].member",
						"entKeyField": "entitlementID",
						"acctIdPath": "",
						"acctKeyField": "customproperty3",
						"doNotChangeIfFailed": true
					}
				}
			}
		}
	}
}
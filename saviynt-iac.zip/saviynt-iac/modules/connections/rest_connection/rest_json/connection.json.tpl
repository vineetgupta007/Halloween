{
	"authentications": {
		"acctAuth": {
			"authType": "Basic",
			"errorPath": "",
			"maxRefreshTryCount": 4,
			"tokenResponsePath": "access_token",
			"tokenType": "Basic",
			"accessToken": "Basic xyz",
			"properties": {
				"userName": "${ping_admin_dn}",
				"password": "${ping_admin_password}"
			},
			"httpHeaders": {
				"Authorization": "Basic xyz"
			},
			"authError": [
				"Invalid integration key in request credentials",
				"AuthenticationFailed"
			],
			"retryFailureStatusCode": [
				401
			],
			"userName": "${ping_admin_dn}",
			"password": "${ping_admin_password}"
		}
	}
}
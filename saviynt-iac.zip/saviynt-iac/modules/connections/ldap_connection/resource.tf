// Copyright (c) 2025 Saviynt Inc.
// SPDX-License-Identifier: MPL-2.0

terraform {
  required_providers {
    saviynt = {
      source  = "saviynt/saviynt"
      version = ">= 0.3.3"
    }
  }
}

variable "ldap_connection_name" {
  type        = string
  description = "The unique name for the ActiveDirectory/LDAP connection"
  default     = "Primary LDAP Connection"
}

variable "email_template" {
  type        = string
  description = "The email template to be used for this connection"
  default     = "Application Discovery Email Template"
}

variable "IP_ADDRESS" {
  type        = string
  description = "Target System Host Server"
}
variable "LDAP_PORT" {
  type        = string
  description = "Port for the connection (SSL Port preferred)"
}
variable "LDAP_PROTOCOL" {
  type        = string
  description = "Protocol type (e.g., LDAP(S), HTTP, etc.)"
}
variable "PASSWORD" {
  type        = string
  description = "Connection password"
  sensitive   = true
}
variable "BIND_USER" {
  type        = string
  description = "Connection username"
}
variable "VAULT_CONNECTION" {
  type        = string
  description = "Vault connection"
}
variable "VAULT_CONFIG" {
  type        = string
  description = "Vault config"
}
variable "SAVE_IN_VAULT" {
  type        = string
  description = "Save in vault"
}

resource "saviynt_ad_connection_resource" "ldap_connection" {
  connection_name       = var.ldap_connection_name
  email_template        = var.email_template
  url                   = format("%s://%s:%d", var.LDAP_PROTOCOL, var.IP_ADDRESS, var.LDAP_PORT)
  password              = var.PASSWORD
  username              = var.BIND_USER
  vault_connection      = var.VAULT_CONNECTION
  vault_configuration   = var.VAULT_CONFIG
  save_in_vault         = var.SAVE_IN_VAULT
  searchfilter          = "o=tsg,o=ge.com"
  base                  = "o=tsg,o=ge.com"
  group_search_base_dn  = "o=tsg,o=ge.com"
  ldap_or_ad            = "LDAP"
  objectfilter          = "(objectClass=tsgposixaccount)" //TBD - User Account Filter
  account_attribute     = "[DISPLAYNAME::cn#String,NAME::uid#String,ACCOUNTID::uid#String,COMMENTS::description#String,CUSTOMPROPERTY1::uidnumber#String,CUSTOMPROPERTY2::uid#String,CUSTOMPROPERTY3::gecos#String,CUSTOMPROPERTY4::company#String,CUSTOMPROPERTY5::tsghpchomedirectory#String,CUSTOMPROPERTY6::tsghpcloginshell#String,CUSTOMPROPERTY7::tsglinuxhomedirectory#String,CUSTOMPROPERTY8::tsglinuxloginshell#String,CUSTOMPROPERTY9::tsgnashomedirectory#String,CUSTOMPROPERTY10::tsgposixaccounttype#String,CUSTOMPROPERTY11::tsgrecordowner#String,CUSTOMPROPERTY12::tsgunixhomedirectory#String,CUSTOMPROPERTY13::tsgunixloginshell#String,CUSTOMPROPERTY14::tsgunixstatus#String,CUSTOMPROPERTY15::entrydn#String,CREATED_ON::createTimestamp#customDate--yyyyMMddHHmmss.SSS'Z',UPDATEDATE::modifyTimestamp#customDate--yyyyMMddHHmmss.SSS'Z',CUSTOMPROPERTY20::objectClass#String,RECONCILATION_FIELD::ACCOUNTID]"
  entitlement_attribute = "nisNetgroupTriple"//TBD - Entitlement Type for Unix based Server
  page_size             = "1000"
  //user_attribute        = "[CUSTOMPROPERTY1::CN#String,USERNAME::name#String,DISPLAYNAME::displayName#String,CUSTOMPROPERTY25::company#String,CUSTOMPROPERTY3::sn#String,COMMENTS::distinguishedName#String,CUSTOMPROPERTY4::homeDirectory#String,CUSTOMPROPERTY5::co#String,CUSTOMPROPERTY6::cn#String,CUSTOMPROPERTY7::givenName#String,CUSTOMPROPERTY8::title#String,CUSTOMPROPERTY9::telephoneNumber#String,CUSTOMPROPERTY10::c#String,CUSTOMPROPERTY11::uSNCreated#String,ENDDATE::accountExpires#millisec,CUSTOMPROPERTY12::logonCount#String,CUSTOMPROPERTY13::physicalDeliveryOfficeName#String,UPDATEDATE::whenChanged#date,CUSTOMPROPERTY14::extensionAttribute1#String,CUSTOMPROPERTY15::extensionAttribute2#String,CUSTOMPROPERTY16::streetAddress#String,CUSTOMPROPERTY17::mailNickname#String,CUSTOMPROPERTY18::department#String,CUSTOMPROPERTY19::countryCode#String,CUSTOMPROPERTY2::sAMAccountName#String,CUSTOMPROPERTY20::userPrincipalName#String,CUSTOMPROPERTY21::manager#String,CUSTOMPROPERTY22::homePhone#String,CUSTOMPROPERTY23::mobile#String,CREATEDATE::whenCreated#date,customproperty24::userAccountControl#String,STATUSKEY::userAccountControl#Number]"
  //filter                = "(sAMAccountName=*-adm)"
  //endpoints_filter      = jsonencode({ AD_Child = [{ memberOf = ["CN=ADGroup15,DC=domainname,DC=com"] }] })
  create_account_json = jsonencode(
    {
      objectClass              = ["top", "person", "organizationalPerson", "posixAccount", "inetOrgPerson", "shadowAccount", "tsgposixaccount"],
      uid                      = "$${account}",
      uidnumber                = "$${user.username}",
      givenName                = "$${user.firstname}",
      sn                       = "$${if(user.lastname != null){user?.lastname.trim()} else {''}}",
      cn                       = "$${if(user.displayname != null && user.displayname != ''){user?.displayname.trim()} else {user.lastname+', '+user.firstname}}",
      gecos                    = "$${if(user.displayname != null && user.displayname != ''){user?.displayname.trim()} else {user.lastname+', '+user.firstname}}",
      loginshell               = "/bin/bash",
      tsgposixaccounttype      = "User",
      tsgservergroup           = "Users",
      tsglinuxhomedirectory    = "/home/$${task.accountName}",
      tsglinuxloginshell       = "/bin/bash",
      company                  = "GE Vernova",
      tsghpchomedirectory      = "/home/hpc/$${task.accountName}",
      tsghpcloginshell         = "/bin/bash",
      tsgnashomedirectory      = "/export/home1/$${task.accountName}",
      tsgunixhomedirectory     = "/export/home/$${task.accountName}",
      tsgunixloginshell        = "/bin/ksh",
      tsgunixstatus            = "A",
      tsgrecordowner           = "$${user.username}",
      gidnumber                = "$${user.username}",
      homedirectory            = "/home/$${task.accountName}"
    }
  )
  import_json = jsonencode(
    {
      envproperties = {
        "com.sun.jndi.ldap.connect.timeout" = "10000",
        "com.sun.jndi.ldap.read.timeout"    = "50000"
      }
  })
  /*enable_account_json = jsonencode({
    USEDNFROMACCOUNT = "YES",
    MOVEDN           = "NO",
    REMOVEGROUPS     = "NO",
    //ENABLEACCOUNTOU  = "CN=Users,DC=corp,DC=AD,DC=com",
    AFTERMOVEACTIONS = {
      userAccountControl = "512",
      otherMailbox = [
        "$${user?.customproperty15.toString().replace(',','\",\"')}"
      ]
    }
  })*/
  reuse_inactive_account = "FALSE"
  account_name_rule      = "uid=$${task.accountName},ou=people,o=tsg,o=ge.com"
  /*remove_account_action  = jsonencode({ removeAction = "SUSPEND", userAccountControl = "546" })*/
  set_random_password    = "FALSE"
  group_import_mapping = jsonencode({
    importGroupHierarchy       = "true",
    entitlementTypeName        = "nisNetgroupTriple",
    groupAccountMappingAttributeName = "nisNetgroupTriple",
    performGroupAccountLinking = "true",
    incrementalTimeField       = "modifyTimestamp",
    groupObjectClass           = "(objectClass=tsgnisnetgroup)",
    mapping                    = "entitlement_value:cn_char,entitlementid:tsgnetgroupid_char,entitlement_glossary:company_char,lastscandate:modifyTimestamp_customDate--yyyyMMddHHmmss.SSS'Z',updatedate:modifyTimestamp_customDate--yyyyMMddHHmmss.SSS'Z',createdate:createTimestamp_customDate--yyyyMMddHHmmss.SSS'Z',displayName:cn_char,customProperty1:entryUUID_char,customProperty2:tsgbusiness_char,customProperty3:tsgnetgrouptype_char,customProperty4:tsgrecordowner_char,customProperty5:tsgservergroup_char,customProperty6:cn_char,RECONCILATION_FIELD:entitlementid",
    entitlementOwnerAttribute  = "managedBy",
    tableFieldAttribute        = "COMMENTS"
  })
  max_changenumber       = "1000"
  support_empty_string   = "TRUE"
  /*status_key_json = jsonencode({
    STATUS_ACTIVE = [
      "1", "ACTIVE", "true", "512", "544"
    ],
    STATUS_INACTIVE = [
      "0", "INACTIVE", "false", "546", "514"
    ]
  })*/
  status_threshold_config = jsonencode({
    statusAndThresholdConfig = {
      statusColumn                = "CUSTOMPROPERTY14",
      activeStatus                = ["A"],
      deleteLinks                 = false,
      accountThresholdValue       = 1000,
      correlateInactiveAccounts   = true,
      inactivateAccountsNotInFile = false,
      deleteAccEntForActiveAccounts = false
    }
  })
  /*disable_account_json = jsonencode({
    userAccountControl = "546",
    deleteAllGroups    = "No"
  })*/
  config_json = jsonencode({
    connectionTimeoutConfig = {
      connectionTimeout = 10,
      readTimeout       = 50,
      retryWait         = 2,
      retryCount        = 3
    }
  })
  read_operational_attributes = "FALSE"
  enforce_tree_deletion       = "FALSE"
  /*advance_filter_json = jsonencode({
    AdvanceFilter = {
      "OU=Employees,DC=domainname,DC=com" = [
        "(&(objectCategory=person)(objectClass=user)(department=PM))"
      ]
      "OU=Vendors,DC=domainname,DC=com" = [
        "(&(objectCategory=person)(objectClass=user)(department=Vendor))"
      ]
    }
  })*/
  enable_group_management = "TRUE"
  /*unlock_account_json = jsonencode(
    {
      lockoutTime = "0"
    }
  )*/
}

// Copyright (c) 2025 Saviynt Inc.
// SPDX-License-Identifier: MPL-2.0

terraform {
  required_providers {
    saviynt = {
      source  = "saviynt/saviynt"
      version = ">= 0.3.3"
    }
  }
}

# --- VARIABLES ---
variable "trigger_base_name" {
  description = "Base name for the job triggers (e.g., SAP_ERP_PROD). Will be suffixed with job type."
  type        = string
}

variable "security_system" {
  description = "The name of the security system in Saviynt"
  type        = string
}

variable "external_conn" {
  description = "The connection ID in Saviynt"
  type        = string
}

# --- RESOURCE ---
resource "saviynt_application_data_import_job_resource" "system_import_jobs" {
  jobs = [
    {
      # 1. Account Full Import
      trigger_name        = "${var.trigger_base_name}_Account_Full"
      job_group           = "DATA"
      cron_expression     = "0 0 1 * * ?" # Runs at 1:00 AM daily
      trigger_group       = "GRAILS_JOBS"
      security_system     = var.security_system
      accounts_or_access  = "accounts"
      external_conn       = var.external_conn
      full_or_incremental = "full"
    },
    {
      # 2. Access Full Import
      trigger_name        = "${var.trigger_base_name}_Access_Full"
      job_group           = "DATA"
      cron_expression     = "0 0 2 * * ?" # Runs at 2:00 AM daily
      trigger_group       = "GRAILS_JOBS"
      security_system     = var.security_system
      accounts_or_access  = "access"
      external_conn       = var.external_conn
      full_or_incremental = "full"
    },
    {
      # 3. Account Incremental Import
      trigger_name        = "${var.trigger_base_name}_Account_Inc"
      job_group           = "DATA"
      cron_expression     = "0 0 * * * ?" # Runs every hour on the hour
      trigger_group       = "GRAILS_JOBS"
      security_system     = var.security_system
      accounts_or_access  = "accounts"
      external_conn       = var.external_conn
      full_or_incremental = "incremental"
    },
    {
      # 4. Access Incremental Import
      trigger_name        = "${var.trigger_base_name}_Access_Inc"
      job_group           = "DATA"
      cron_expression     = "0 30 * * * ?" # Runs every hour at the 30-minute mark
      trigger_group       = "GRAILS_JOBS"
      security_system     = var.security_system
      accounts_or_access  = "access"
      external_conn       = var.external_conn
      full_or_incremental = "incremental"
    }
  ]
}
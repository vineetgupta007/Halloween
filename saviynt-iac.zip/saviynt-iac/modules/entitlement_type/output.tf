output "entitlement_name" {
  description = "Name of the created entitlement type"
  value       = saviynt_entitlement_type_resource.entitlement_type.entitlement_name
}

output "endpoint_name" {
  description = "Endpoint name associated with entitlement type"
  value       = saviynt_entitlement_type_resource.entitlement_type.endpoint_name
}

output "display_name" {
  description = "Display name of the entitlement type"
  value       = saviynt_entitlement_type_resource.entitlement_type.display_name
}
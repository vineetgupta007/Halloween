# Copyright (c) 2025 Saviynt Inc.
# SPDX-License-Identifier: MPL-2.0

terraform {
  required_providers {
    saviynt = {
      source  = "saviynt/saviynt"
      version = ">= 0.3.3"
    }
  }
}

resource "saviynt_entitlement_type_resource" "entitlement_type" {

  # ─────────────────────────────────────
  # Required
  # ─────────────────────────────────────
  entitlement_name = var.entitlement_name
  endpoint_name    = var.endpoint_name

  # ─────────────────────────────────────
  # General Optional
  # ─────────────────────────────────────
  display_name            = var.display_name
  entitlement_description = var.entitlement_description
  workflow                = var.workflow
  order_index             = var.order_index
  show_ent_type_on        = var.show_ent_type_on
  hierarchy_required      = var.hierarchy_required
  request_option          = var.request_option

  # ─────────────────────────────────────
  # Boolean Flags
  # ─────────────────────────────────────
  enable_entitlement_to_role_sync  = var.enable_entitlement_to_role_sync
  certifiable                      = var.certifiable
  recon                            = var.recon
  required_in_request              = var.required_in_request
  required_in_service_request      = var.required_in_service_request
  enable_provisioning_priority     = var.enable_provisioning_priority
  exclude_rule_assgn_ents_in_req   = var.exclude_rule_assgn_ents_in_req

  # ─────────────────────────────────────
  # Date Config
  # ─────────────────────────────────────
  start_date_in_revoke_request            = var.start_date_in_revoke_request
  start_end_date_in_request               = var.start_end_date_in_request
  allow_remove_all_entitlement_in_request = var.allow_remove_all_entitlement_in_request

  # ─────────────────────────────────────
  # Query Service Account
  # ─────────────────────────────────────
  available_query_service_account   = var.available_query_service_account
  selected_query_service_account    = var.selected_query_service_account
  ars_requestable_entitlement_query = var.ars_requestable_entitlement_query
  ars_selected_entitlement_query    = var.ars_selected_entitlement_query

  # ─────────────────────────────────────
  # Task Actions
  # ─────────────────────────────────────
  create_task_action = var.create_task_action

  # ─────────────────────────────────────
  # Request Dates Config JSON
  # ─────────────────────────────────────
  request_dates_conf_json = var.request_dates_conf_json

  # ─────────────────────────────────────
  # Custom Properties
  # ─────────────────────────────────────
  custom_property1 = var.custom_property1
  custom_property2 = var.custom_property2
  custom_property3 = var.custom_property3
  custom_property4 = var.custom_property4
  custom_property5 = var.custom_property5
}
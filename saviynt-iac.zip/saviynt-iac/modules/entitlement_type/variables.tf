# ─────────────────────────────────────
# Required Variables
# ─────────────────────────────────────
variable "entitlement_name" {
  description = "Name of the entitlement type"
  type        = string
}

variable "endpoint_name" {
  description = "Name of the endpoint this entitlement type belongs to"
  type        = string
}

# ─────────────────────────────────────
# Optional Variables
# ─────────────────────────────────────
variable "display_name" {
  description = "Display name of the entitlement type"
  type        = string
  default     = ""
}

variable "entitlement_description" {
  description = "Description of the entitlement type"
  type        = string
  default     = ""
}

variable "workflow" {
  description = "Workflow associated with entitlement type"
  type        = string
  default     = "Autoapprovalwf"
}

variable "order_index" {
  description = "Order index for display"
  type        = number
  default     = 1
}

variable "show_ent_type_on" {
  description = "Show entitlement type on"
  type        = string
  default     = "1"
}

variable "hierarchy_required" {
  description = "Whether hierarchy is required"
  type        = string
  default     = "0"
}

variable "request_option" {
  description = "Request option type"
  type        = string
  default     = "FREEFORMTEXT"
}

# ─────────────────────────────────────
# Boolean Variables
# ─────────────────────────────────────
variable "enable_entitlement_to_role_sync" {
  description = "Enable entitlement to role sync"
  type        = bool
  default     = false
}

variable "certifiable" {
  description = "Whether entitlement type is certifiable"
  type        = bool
  default     = true
}

variable "recon" {
  description = "Whether reconciliation is enabled"
  type        = bool
  default     = true
}

variable "required_in_request" {
  description = "Required in access request"
  type        = bool
  default     = false
}

variable "required_in_service_request" {
  description = "Required in service request"
  type        = bool
  default     = false
}

variable "enable_provisioning_priority" {
  description = "Enable provisioning priority"
  type        = bool
  default     = false
}

variable "exclude_rule_assgn_ents_in_req" {
  description = "Exclude rule assigned entitlements in request"
  type        = bool
  default     = false
}

# ─────────────────────────────────────
# Date Config Variables
# ─────────────────────────────────────
variable "start_date_in_revoke_request" {
  description = "Include start date in revoke request"
  type        = string
  default     = "false"
}

variable "start_end_date_in_request" {
  description = "Include start and end date in request"
  type        = string
  default     = "false"
}

variable "allow_remove_all_entitlement_in_request" {
  description = "Allow remove all entitlements in request"
  type        = string
  default     = "false"
}

# ─────────────────────────────────────
# Query Service Account Variables
# ─────────────────────────────────────
variable "available_query_service_account" {
  description = "Available query service account"
  type        = string
  default     = ""
}

variable "selected_query_service_account" {
  description = "Selected query service account"
  type        = string
  default     = ""
}

variable "ars_requestable_entitlement_query" {
  description = "ARS requestable entitlement query"
  type        = string
  default     = ""
}

variable "ars_selected_entitlement_query" {
  description = "ARS selected entitlement query"
  type        = string
  default     = ""
}

# ─────────────────────────────────────
# Task Action Variables
# ─────────────────────────────────────
variable "create_task_action" {
  description = "List of task actions"
  type        = list(string)
  default     = []
}

# ─────────────────────────────────────
# Request Dates Config Variables
# ─────────────────────────────────────
variable "request_date_start" {
  description = "Enable start date in request"
  type        = bool
  default     = false
}

variable "request_date_end" {
  description = "Enable end date in request"
  type        = bool
  default     = false
}

variable "request_date_justification" {
  description = "Enable justification in request"
  type        = bool
  default     = false
}

variable "request_dates_conf_json" {
  description = "Request dates config JSON — pre-encoded string"
  type        = string
  default     = "{}"
}

# ─────────────────────────────────────
# Custom Properties
# ─────────────────────────────────────
variable "custom_property1" {
  description = "Custom property 1"
  type        = string
  default     = ""
}

variable "custom_property2" {
  description = "Custom property 2"
  type        = string
  default     = ""
}

variable "custom_property3" {
  description = "Custom property 3"
  type        = string
  default     = ""
}

variable "custom_property4" {
  description = "Custom property 4"
  type        = string
  default     = ""
}

variable "custom_property5" {
  description = "Custom property 5"
  type        = string
  default     = ""
}

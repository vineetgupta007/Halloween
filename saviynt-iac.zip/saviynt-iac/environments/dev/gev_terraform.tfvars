saviynt_username   = "560066417"
saviynt_password   = "nUTg5Az_B2Odiu"
SAVIYNT_SERVER_URL = "gevernova-dev.saviyntcloud.com"

# ================================================
# AD Connection
# ================================================
AD_PASSWORD = "JqQWu13XXabt"

# ================================================
# LDAP Connection
# ================================================
LDAP_PASSWORD = "mapunix@userver415"

# ================================================
# REST Connection (PingDirectory OAuth2)
# ================================================
PING_OAUTH_CLIENT_ID     = "avc"
PING_OAUTH_CLIENT_SECRET = "awert"

# ================================================
# REST Connection (PingDirectory BasicAuth)
# ================================================
PING_ADMIN_ID     = "uid=DirectoryAdmin,ou=geworker,o=gevernova.com"
PING_ADMIN_PASSWORD = "FNr54c>3-KO"
# This file is maintained automatically by "terraform init".
# Manual edits may be lost in future updates.

provider "registry.terraform.io/saviynt/saviynt" {
  version     = "0.3.4"
  constraints = ">= 0.3.3"
  hashes = [
    "h1:fZiYy8UJXVJiCwy7AT9Ln/Ag8wy2mOQoAob6K03Fag0=",
    "zh:083915c22d74a0a6c80c68aab4b587dcc4b4b93f7f2781cf726bd6f5b5ad2e5a",
    "zh:4f681c37a9c855d043cdff59f80ae5cea7566563c5d454d1d5fc6f5ed341d33e",
    "zh:5d3471a3cecefb4d2a7716453deae2778b79a20577b3f6deac18e23f4a952c45",
    "zh:675cb08b3029c1641fcc14ad8ae7a96993deb068a8aeb381fee6812f1afe0b22",
    "zh:6c3463a31fc2e09b1471f1e519163b5c91519df8361522f485ccf782109a3a63",
    "zh:7370a5ee01f775107673f38c50acc43dca3d6abc51ebc4517c749a463152e3f6",
    "zh:7a85bca340ae8175ebc2af142fc84c2deef3b7f17e84eccde890de685bd5b55c",
    "zh:890df766e9b839623b1f0437355032a3c006226a6c200cd911e15ee1a9014e9f",
    "zh:8baa37f2471ab6160a30dc9bdd3bd7fd71f7a4efcaf7789f90f1d98f5ed092e9",
    "zh:954129b1ca7fdaba3cd6d4fe51e1527329410c6c6b1df210ba15e0a538a737b0",
    "zh:a6b13e3a45ae0f2b7311b1c0b736901ab6dcd0547f65b6bff16d0067769e1ec1",
    "zh:e1a8b334e2eeb3feff08a01bbbc2df41f23cf8544d59b94677e1100015955bdc",
    "zh:e643b0e7e9a01de7ffcee48515c4dccc8aace7074361465b867506f419a76e9d",
    "zh:f96feab0d623c82a68a5a4fbbf9b8ce1d6e595e30c36b9f54226640d4900273a",
  ]
}

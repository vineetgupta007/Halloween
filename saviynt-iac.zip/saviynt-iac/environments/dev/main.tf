terraform {
  required_providers {
    saviynt = {
      source  = "saviynt/saviynt"
      version = ">=0.3.3"
    }
  }
}

provider "saviynt" {
  # Use variables or environment variables for these!
  server_url = var.SAVIYNT_SERVER_URL
  username   = var.saviynt_username
  password   = var.saviynt_password
}

# ─────────────────────────────────────
# LOCALS — CSV DATA LOADING
# ─────────────────────────────────────
locals {
  sys_csv             = csvdecode(file("${path.module}/../data/inventory_systems.csv"))
  ep_csv              = csvdecode(file("${path.module}/../data/inventory_endpoints.csv"))
  ad_conn_csv         = csvdecode(file("${path.module}/../data/inventory_ad_connections.csv"))
  ldap_conn_csv       = csvdecode(file("${path.module}/../data/inventory_ldap_connections.csv"))
  rest_conn_csv       = csvdecode(file("${path.module}/../data/inventory_rest_connections.csv"))
  oauth_rest_conn_csv = csvdecode(file("${path.module}/../data/inventory_oauth_rest_connections.csv"))

  # Standard systems — unchanged
  std_systems = { for s in local.sys_csv : s.key => s if s.type != "SAP" }
  //sap_systems = { for s in local.sys_csv : s.key => s if s.type == "SAP" }
}

# ─────────────────────────────────────
# LOCALS — ENTITLEMENT TYPES
# 2 per oauth rest connection
# "Parent" and "Group"
# ─────────────────────────────────────
locals {
  entitlement_types = flatten([
    for conn in local.oauth_rest_conn_csv : [

      # ── Entitlement Type 1: Parent ──
      {
        key              = "${conn.key}_Parent"
        entitlement_name = "Parent"
        endpoint_name    = conn.endpoint_name
        display_name     = conn.ent_parent_display_name
        description      = "Parent entitlement type for ${conn.display_name}"
        workflow         = conn.workflow
        certifiable      = conn.certifiable
        recon            = conn.recon
        required_in_request             = conn.required_in_request
        enable_entitlement_to_role_sync = conn.enable_entitlement_to_role_sync
        order_index                     = 1
        request_option                  = conn.request_option
        custom_property1                = conn.custom_property1
        custom_property2                = conn.custom_property2
        # ── Date Config — Parent ──
        start_end_date_in_request               = "false"
        start_date_in_revoke_request            = "false"
        allow_remove_all_entitlement_in_request = "false"

        # ── Request Dates JSON — Parent ──
        request_date_start         = false
        request_date_end           = false
        request_date_justification = false
        request_dates_conf_json    = "{}"

        # ── ARS Query — Parent ──
        ars_requestable_entitlement_query = ""
      },

      # ── Entitlement Type 2: Group ──
      {
        key              = "${conn.key}_Group"
        entitlement_name = "Group"
        endpoint_name    = conn.endpoint_name
        display_name     = conn.ent_group_display_name
        description      = "Group entitlement type for ${conn.display_name}"
        workflow         = conn.workflow
        certifiable      = conn.certifiable
        recon            = conn.recon
        required_in_request             = conn.required_in_request
        enable_entitlement_to_role_sync = conn.enable_entitlement_to_role_sync
        order_index                     = 2
        request_option                  = conn.request_option
        custom_property1                = conn.custom_property1
        custom_property2                = conn.custom_property2
        # ── Date Config — Group ──
        start_end_date_in_request               = "true"
        start_date_in_revoke_request            = "true"
        allow_remove_all_entitlement_in_request = "false"

        # ── Request Dates JSON — Group ──
        request_date_start         = true
        request_date_end           = true
        request_date_justification = false
        request_dates_conf_json    = jsonencode({
          ENDDATEREQUIRED      = "1"
          DEFAULTTIMEFRAMEHRS  = "1"
          MAXTIMEFRAMEHRS      = "4"
        })

        # ── ARS Query — Group (placeholder) ──
        ars_requestable_entitlement_query = "PLACEHOLDER_QUERY"
      }
    ]
  ])
}


locals {
  # This merges the outputs of ALL your different connection modules into
  # a single map where the key is the connection name (from the CSV),
  # and the value is the Saviynt Connection ID.

  universal_connection_ids = merge(
    # 1. Grab all AD connection IDs
    { for key, conn in module.ad_connection : key => conn.connection_id },

    # 2. Grab all LDAP connection IDs (Even though LDAP jobs are separate, it's good practice to merge all)
    { for key, conn in module.ldap_connection : key => conn.connection_id },

    # 3. REST connection IDs
    { for key, conn in module.rest_connection : key => conn.connection_id },

    # 4. REST OAuth connection IDs
    { for key, conn in module.oauth_rest_connection : key => conn.connection_id },

    # FUTURE PROOFING: As you add REST, JDBC, etc., just add them here!
    # { for key, conn in module.rest_connections : key => conn.connection_id },
    # { for key, conn in module.jdbc_connections : key => conn.connection_id }
  )
}

locals {
  # ... (your existing sys_csv, ep_csv, conn_csv locals) ...

  # This creates a master dictionary mapping your CSV key to the Saviynt System ID
  # e.g., { "AD_PROD" = "1045", "SAP_PROD" = "1046" }
  universal_system_ids = merge(
    { for k, v in module.sec_system_std : k => v.security_system_resource_id }
    /*{ for k, v in module.sec_system_sap : k => v.security_system_resource_id }*/
  )
}

# 1. Connections (AD)
module "ad_connection" {
  # Use for_each to loop through each row of your connections CSV
  for_each = { for c in local.ad_conn_csv : c.key => c }

  source = "../../modules/connections/ad_connection"

  # Pass all required arguments directly to the module
  # ---
  # IMPORTANT: You must match the values on the right (e.g., each.value.host)
  # to the actual column names in your 'inventory_connections.csv' file.
  # ---
  ldap_connection_name = each.value.key
  LDAP_PROTOCOL        = each.value.LDAP_PROTOCOL # e.g., "ldaps", or from a CSV column
  LDAP_PORT            = each.value.LDAP_PORT
  IP_ADDRESS           = each.value.IP_ADDRESS    # Or the correct column, e.g., "ip_address"
  PASSWORD             = var.AD_PASSWORD
  BIND_USER            = each.value.BIND_USER        # Or the correct column from your CSV
  SAVE_IN_VAULT        = "false"

  # For these VAULT arguments, you need to decide if they are static
  # or also come from your CSV file.
  VAULT_CONNECTION = ""
  VAULT_CONFIG     = ""

}

# 2. Connections (LDAP)
module "ldap_connection" {
  # Use for_each to loop through each row of your connections CSV
  for_each = { for c in local.ldap_conn_csv : c.key => c }

  source = "../../modules/connections/ldap_connection"

  # Pass all required arguments directly to the module
  # ---
  # IMPORTANT: You must match the values on the right (e.g., each.value.host)
  # to the actual column names in your 'inventory_connections.csv' file.
  # ---
  ldap_connection_name = each.value.key
  LDAP_PROTOCOL        = each.value.LDAP_PROTOCOL # e.g., "ldaps", or from a CSV column
  LDAP_PORT            = each.value.LDAP_PORT
  IP_ADDRESS           = each.value.IP_ADDRESS    # Or the correct column, e.g., "ip_address"
  PASSWORD             = var.LDAP_PASSWORD
  BIND_USER            = each.value.BIND_USER        # Or the correct column from your CSV
  SAVE_IN_VAULT        = "false"

  # For these VAULT arguments, you need to decide if they are static
  # or also come from your CSV file.
  VAULT_CONNECTION = ""
  VAULT_CONFIG     = ""

}

# ================================================
# 3. Connections (REST)
# ================================================
module "rest_connection" {
  for_each = {for c in local.rest_conn_csv : c.key => c}
  source = "../../modules/connections/rest_connection"

  # Non-sensitive values from CSV
  rest_connection_name = each.value.key
  ping_host            = each.value.ping_host
  ping_base_dn         = each.value.ping_base_dn
  ping_users_dn        = each.value.ping_users_dn
  ping_groups_dn       = each.value.ping_groups_dn

  # Sensitive values from variables - never from CSV
  ping_admin_dn       = var.PING_ADMIN_ID
  ping_admin_password = var.PING_ADMIN_PASSWORD
}

# ─────────────────────────────────────
# 4. OAuth REST Connections (Ping SSO)
# ─────────────────────────────────────
module "oauth_rest_connection" {
  for_each = { for c in local.oauth_rest_conn_csv : c.key => c }

  source = "../../modules/connections/rest_oauth_connection"

  # Non-sensitive from CSV
  rest_oauth_connection_name = each.value.key
  ping_host                  = each.value.ping_host
  ping_base_dn               = each.value.ping_base_dn
  ping_users_dn              = each.value.ping_users_dn
  ping_groups_dn             = each.value.ping_groups_dn

  # Sensitive from variables — never from CSV
  ping_client_id     = var.PING_OAUTH_CLIENT_ID
  ping_client_secret = var.PING_OAUTH_CLIENT_SECRET
}

# 4. Standard Systems (AD, ADSI, etc.)
module "sec_system_std" {
  # Use for_each to loop through the map of standard systems
  for_each = local.std_systems

  source = "../../modules/security_systems_standard"

  # Pass variables directly, using the correct column names from your CSV
  # IMPORTANT: You may need to change "each.value.sys_name", etc.,
  # to match the actual column headers in your inventory_systems.csv file.
  security_system_name = each.value.security_system_name
  sec_display_name     = each.value.sec_display_name
  sec_description      = each.value.sec_description

  depends_on = [module.ad_connection, module.ldap_connection, module.oauth_rest_connection]
}

# 5. Endpoints (Universal)
module "endpoints" {
  source    = "../../modules/end_points"
  /*endpoints = {
    for e in local.ep_csv : e.key => merge(e, {
      # This looks up the CSV key (e.g., "AD_PROD") and grabs the Saviynt ID (e.g., "1045")
      security_system = local.universal_system_ids[e.associated_system]
    })
  }*/
  endpoints = { for e in local.ep_csv : e.key => e }
  # Ensure both system modules complete first
  depends_on = [module.sec_system_std]
}

# 6. Import Jobs (Standard Systems / AD / LDAP)
module "application_import_jobs" {
  for_each   = local.std_systems
  source     = "../../modules/application_import_jobs"

  trigger_base_name = each.value.trigger_base_name
  security_system   = each.value.security_system_name

  # DYNAMIC LOOKUP:
  # Terraform looks inside the merged dictionary for the connection key.
  # Whether it was created by the ADSI module or a REST module, it will find the ID.
  external_conn = local.universal_connection_ids[each.value.key]
  # IMPORTANT: Because we are using a merged local variable,
  # you should explicitly tell Terraform to wait for ALL connection modules to finish.
  depends_on = [module.sec_system_std, module.ad_connection, module.ldap_connection]
}

# 7. WS Retry Jobs (Standard Systems / AD / LDAP)
module "ws_retry_jobs_std" {
  for_each   = local.std_systems
  source     = "../../modules/ws_retry_jobs"

  # Pulling directly from your existing CSV columns
  trigger_base_name = each.value.trigger_base_name
  security_system   = each.value.security_system_name

  # Ensure the security system exists before attaching a retry job to it
  depends_on = [module.sec_system_std, module.ad_connection, module.ldap_connection]
}

# ─────────────────────────────────────
# 9. Entitlement Types
# 2 per oauth connection: Parent + Group
# ─────────────────────────────────────
module "entitlement_types" {
  for_each = { for ent in local.entitlement_types : ent.key => ent }

  source = "../../modules/entitlement_type"

  # Required
  entitlement_name = each.value.entitlement_name
  endpoint_name    = each.value.endpoint_name

  # General
  display_name            = each.value.display_name
  entitlement_description = each.value.description
  workflow                = each.value.workflow
  order_index             = each.value.order_index
  request_option          = each.value.request_option

  # Booleans — CSV stores as string, convert to bool
  certifiable                     = each.value.certifiable == "true"
  recon                           = each.value.recon == "true"
  required_in_request             = each.value.required_in_request == "true"
  enable_entitlement_to_role_sync = each.value.enable_entitlement_to_role_sync == "true"

  # Date Config — different per type
  start_end_date_in_request               = each.value.start_end_date_in_request
  start_date_in_revoke_request            = each.value.start_date_in_revoke_request
  allow_remove_all_entitlement_in_request = each.value.allow_remove_all_entitlement_in_request

  # Request Dates JSON — different per type
  request_dates_conf_json = each.value.request_dates_conf_json

  # ARS Query — different per type
  ars_requestable_entitlement_query = each.value.ars_requestable_entitlement_query

  # Custom Properties
  custom_property1 = each.value.custom_property1
  custom_property2 = each.value.custom_property2

  depends_on = [module.endpoints]
}


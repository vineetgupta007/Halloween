saviynt_username   = "partner_admin"
saviynt_password   = "Joker@123"
SAVIYNT_SERVER_URL = "ssm-kpmg.saviyntcloud.com"
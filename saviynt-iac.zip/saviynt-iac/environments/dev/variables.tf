variable "saviynt_password" {
  description = "The password for the Saviynt admin user."
  type        = string
  sensitive   = true # Mark as sensitive to prevent it from being shown in logs
}

variable "saviynt_username" {
  description = "The username for the Saviynt admin user."
  type        = string
  # A default can be provided if appropriate, otherwise it must be set in .tfvars
  # default     = "partner_admin" 
}

variable "SAVIYNT_SERVER_URL" {
  type        = string
  description = "Saviynt API Server URL (without https://)"
}

variable "AD_PASSWORD" {
  description = "An environment variable for AD Connection Password."
  type        = string
  sensitive   = true
}

variable "LDAP_PASSWORD" {
  description = "An environment variable for LDAP Connection Password."
  type        = string
  sensitive   = true
}

variable "PING_OAUTH_CLIENT_ID" {
  description = "OAuth2 Client ID for REST connections"
  type        = string
  sensitive   = true
}

variable "PING_OAUTH_CLIENT_SECRET" {
  description = "OAuth2 Client Secret for REST connections"
  type        = string
  sensitive   = true
}

variable "PING_ADMIN_ID" {
  description = "REST Admin ID for REST connections"
  type        = string
}

variable "PING_ADMIN_PASSWORD" {
  description = "REST Admin Password for REST connections"
  type        = string
  sensitive   = true
}
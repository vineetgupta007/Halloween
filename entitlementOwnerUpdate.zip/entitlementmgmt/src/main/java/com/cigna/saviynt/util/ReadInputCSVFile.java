package com.cigna.saviynt.util;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

public class ReadInputCSVFile {
	
	private static Logger log = LogManager.getLogger(ReadInputCSVFile.class);
	
	public static List<Entitlement> readFile(String filePath) {
		log.debug("reading the input CSV file - START");
		List<Entitlement> entitlementList = new ArrayList<Entitlement>();
		try {
			File file = new File(filePath);
			FileReader fileReader = new FileReader(file);
			CSVReader csvReader = new CSVReaderBuilder(fileReader).withSkipLines(1).build();
			List<String[]> allData = csvReader.readAll();
			for(String[] row:allData) {
				log.debug("*****************************************************");
				Entitlement entitlement = new Entitlement();
				int cnt=0;
				for(String cell:row) {
					switch(cnt) {
						case 0:
							entitlement.setAction(cell.trim());
							log.debug("Action = "+cell.trim());
							break;
						case 1:
							entitlement.setEndpoint(cell.trim());
							log.debug("Endpoint = "+cell.trim());
							break;
						case 2:
							entitlement.setEntitlementType(cell.trim());
							log.debug("Entitlement Type = "+cell.trim());
							break;
						case 3:
							entitlement.setEntitlementValue(cell.trim());
							log.debug("Entitlement Value = "+cell.trim());
							break;
						case 4:
							entitlement.setEntitlementOwner(cell.trim());
							log.debug("Entitlement Owner = "+cell.trim());
							break;
					}
					cnt++;	
				}
				log.debug("*****************************************************");
				entitlementList.add(entitlement);
			}
		}catch(Exception e) {
			log.error("exception occurred while reading input csv file");
			log.error(e);
		}
		log.debug("reading the input CSV file - END");
		return entitlementList;
	}

}

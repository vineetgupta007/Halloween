package com.cigna.saviynt.util;

import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class HttpClientSingleton {
	
	private static Logger log = LogManager.getLogger(HttpClientSingleton.class);
	private static HttpClientSingleton httpClientInstance = null;
	
	public CloseableHttpClient httpClient;
	
	private HttpClientSingleton() {
//		httpClient = HttpClients.createDefault();
		httpClient = HttpClients.custom()
				.setDefaultRequestConfig(RequestConfig.custom()
						.setCookieSpec(CookieSpecs.STANDARD).build())
				.build();
	}
	
	public static synchronized HttpClientSingleton getInstance() {
		if(httpClientInstance == null) {
			log.info("generating a new instance of HttpClientSingleton");
			httpClientInstance = new HttpClientSingleton();
		}
		return httpClientInstance;
	}

}

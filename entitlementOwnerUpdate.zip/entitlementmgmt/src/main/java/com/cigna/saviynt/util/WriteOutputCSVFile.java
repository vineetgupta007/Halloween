package com.cigna.saviynt.util;

import java.io.File;
import java.io.FileWriter;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.opencsv.CSVWriter;

public class WriteOutputCSVFile {
	
	private static Logger log = LogManager.getLogger(WriteOutputCSVFile.class);
	
	public static void writeCSVFile(String filePath, List<EntitlementResult> entitlementResults) {
		log.debug("writing the output CSV file - START");
		try {
			File outputFile = new File(filePath);
			FileWriter fileWriter = new FileWriter(outputFile);
			CSVWriter csvWriter = new CSVWriter(fileWriter);
			String[] header = {"Action","Endpoint","Entitlement Type","Entitlement Value","Entitlement Owner","Result"};
			csvWriter.writeNext(header);
			for(EntitlementResult entitlementResult:entitlementResults) {
				log.debug("*****************************************************");
				log.debug("Action = "+entitlementResult.getAction());
				log.debug("Endpoint = "+entitlementResult.getEndpoint());
				log.debug("Entitlement Type = "+entitlementResult.getEntitlementType());
				log.debug("Entitlement Value = "+entitlementResult.getEntitlementValue());
				log.debug("Entitlement Owner = "+entitlementResult.getEntitlementOwner());
				log.debug("Result = "+entitlementResult.getResult());
				String[] data = {entitlementResult.getAction(),entitlementResult.getEndpoint(),entitlementResult.getEntitlementType(),entitlementResult.getEntitlementValue(),entitlementResult.getEntitlementOwner(),entitlementResult.getResult()};
				csvWriter.writeNext(data);
				log.debug("*****************************************************");
			}
			csvWriter.close();
		}catch(Exception e) {
			log.error("exception occurred while writing output csv file");
			log.error(e);
		}
		log.debug("writing the output CSV file - END");
	}

}

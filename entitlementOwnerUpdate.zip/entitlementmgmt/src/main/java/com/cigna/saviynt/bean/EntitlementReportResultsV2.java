package com.cigna.saviynt.bean;

public class EntitlementReportResultsV2 {
	
	private String displaycount;
	private String msg;
	private String totalcount;
	private EntitlementData[] results;
	private String errorcode;
	
	
	public String getDisplaycount() {
		return displaycount;
	}
	public void setDisplaycount(String displaycount) {
		this.displaycount = displaycount;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getTotalcount() {
		return totalcount;
	}
	public void setTotalcount(String totalcount) {
		this.totalcount = totalcount;
	}
	public EntitlementData[] getResults() {
		return results;
	}
	public void setResults(EntitlementData[] results) {
		this.results = results;
	}
	public String getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}
	
}

package com.cigna.saviynt.bean;

public class EntOwners {
	
	private String ownerUName;
	private String ownerRank;
	
	public String getOwnerUName() {
		return ownerUName;
	}
	public void setOwnerUName(String ownerUName) {
		this.ownerUName = ownerUName;
	}
	public String getOwnerRank() {
		return ownerRank;
	}
	public void setOwnerRank(String ownerRank) {
		this.ownerRank = ownerRank;
	}
	
	public String toString() {
		return "Owner User Name: '" + this.ownerUName + "', Owner Rank: '" + this.ownerRank +"'";
	}
	
	@Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }

        if (obj.getClass() != this.getClass()) {
            return false;
        }

        final EntOwners other = (EntOwners) obj;
        if ((this.ownerUName == null) ? (other.ownerUName != null) : !this.ownerUName.equals(other.ownerUName)) {
            return false;
        }

        if (!this.ownerRank.equals(other.ownerRank)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 53 * hash + (this.ownerUName != null ? this.ownerUName.hashCode() : 0);
        hash = 53 * hash + (this.ownerRank != null ? this.ownerRank.hashCode() : 0);
        return hash;
    }

}

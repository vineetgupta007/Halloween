package com.cigna.saviynt.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Utils {
	
	private static Logger log = LogManager.getLogger(Utils.class);
	
	public static String readValueFromPropertiesFile(String propertyName) {
//		String propFileLocation = System.getProperty("prop.file.location");
		log.debug("property name = "+propertyName);
		Properties prop = new Properties();
		String propertyValue=null;
		try {
			InputStream inputStream = Utils.class.getClassLoader().getResourceAsStream("EntitlementOwnerUpdate.properties");
//			InputStream inputStream = Utils.class.getClassLoader().getResourceAsStream(propFileLocation);
			if(inputStream==null) {
				log.error("unable to find properties file");
			}
			prop.load(inputStream);
			propertyValue = prop.getProperty(propertyName);
			log.debug("property value = "+propertyValue);
		}catch(Exception e) {
			log.error("exception occurred while reading property from properties file");
			log.error(e);
		}
		return propertyValue;
	}
	
	public static String readValueFromPropertiesFileConfigLocation(String fileName, String propertyName) {
		
		log.debug("Prperties file from where all environemnt properties will be loaded "+fileName);
		log.debug("property name = "+propertyName);
		FileInputStream fis = null;
		Properties prop = null;
		String propertyValue=null;
		try {
			fis = new FileInputStream(fileName);
			prop = new Properties();
			prop.load(fis);
			propertyValue = prop.getProperty(propertyName);
			log.debug("property value = "+propertyValue);
		} catch (FileNotFoundException fnfe) {
			log.error("Properties file is not found at specified location... ", fnfe);
		} catch (IOException ioe) {
			log.error("Properties file is not readable at specified location... ", ioe);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {

			}
		}
		return propertyValue;
	}
	
	public static Properties readPropertiesFromConfigFileLocation(String fileName) {
		
		log.debug("Prperties file from where all environemnt properties will be loaded "+fileName);
		FileInputStream fis = null;
		Properties prop = null;
		try {
			fis = new FileInputStream(fileName);
			prop = new Properties();
			prop.load(fis);
		} catch (FileNotFoundException fnfe) {
			log.error("Properties file is not found at specified location... ", fnfe);
		} catch (IOException ioe) {
			log.error("Properties file is not readable at specified location... ", ioe);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {

			}
		}
		return prop;
	}
	
}

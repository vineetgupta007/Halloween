package com.cigna.saviynt.wscall;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.cigna.saviynt.bean.EntOwners;
import com.cigna.saviynt.bean.EntitlementDataToUpdate;
import com.cigna.saviynt.util.AccessTokenSingleton;
import com.cigna.saviynt.util.HttpClientSingleton;

public class EntitlementActions {
	
	private static Logger log = LogManager.getLogger(EntitlementActions.class);
	private Properties props;
	
	public EntitlementActions (Properties props) {
		this.props = props;
	}
	
	/*@SuppressWarnings("unchecked")
	public boolean addRemoveEntitlementOwner(Entitlement entitlement) {
		boolean isSuccessful = false;
		String action = entitlement.getAction();
		log.debug("action = "+action);
		try {
			HttpResponse response = sendCreateUpdateEntitlementRequest(entitlement);
			if(null!=response) {
				int statusCode = response.getStatusLine().getStatusCode();
				log.debug("http response code = "+statusCode);
				String responseBody = EntityUtils.toString(response.getEntity());
				log.debug("response body = "+responseBody);
				if(statusCode>=200 && statusCode<=299) {
					log.debug("request successful");
					isSuccessful = true;
				}else {
					log.debug("request unsuccessful");
				}
			}else {
				log.info("createUpdateEntitlement request failed. Unable to obtain response");
			}	
		}catch(Exception e) {
			log.error(e);
		}
		return isSuccessful;
	}
	
	public boolean updateEntitlementOwner(EntitlementDataToUpdate entitlement) {
		boolean isSuccessful = false;
		ArrayList<String> rank1EntitlementOwners = getRank1EntitlementOwners(entitlement);
		EntOwners[] ownerToUpdate = entitlement.getEntOwners();
		log.info("owner(s) to update = "+ownerToUpdate);
		if(null!=rank1EntitlementOwners && rank1EntitlementOwners.size()>0) {
			log.info("existing rank1 owner(s) to remove = "+rank1EntitlementOwners.toString());
			for (String rank1EntitlementOwner : rank1EntitlementOwners) {
				entitlement.setOwnerAction("Remove");
				entitlement.setEntitlementOwner(rank1EntitlementOwner);
				if(addRemoveEntitlementOwner(entitlement)) {
					log.info("existing rank 1 owner - "+rank1EntitlementOwner+" removed successfully");
				}else {
					log.info("unable to remove rank 1 owner - "+rank1EntitlementOwner);
				}
			}
		}
		entitlement.setAction("Add");
		entitlement.setEntitlementOwner(ownerToUpdate);
		if(addRemoveEntitlementOwner(entitlement)) {
			log.info("added owner - "+ownerToUpdate);
			isSuccessful = true;
		}else {
			log.info("unable to add owner - "+ownerToUpdate);
		}
		return isSuccessful;
	}*/
	
	@SuppressWarnings("unchecked")
	private HttpResponse sendCreateUpdateEntitlementRequest(EntitlementDataToUpdate entitlement, List<EntOwners>OwnertoRemove, List<EntOwners>ownerToAdd) {
		HttpResponse response=null;
		String url = this.props.getProperty("SAVIYNT_REST_API_BASE_URL") + "/" + this.props.getProperty("SAVIYNT_REST_API_CREATE_UPDATE_ENTITLEMENT_URI");
		HttpPost httpPost = new HttpPost(url);
		try {
			AccessTokenSingleton accessTokenInstance = AccessTokenSingleton.getInstance(this.props);
			String accessToken = accessTokenInstance.accessToken.getJwt();
			log.debug("URL for createUpdateEntitlement request = "+url);
			JSONObject createUpdateEntitlementJson = new JSONObject();
			log.debug("Endpoint = "+entitlement.getTarget_ep());
			createUpdateEntitlementJson.put("endpoint", entitlement.getTarget_ep());
			log.debug("Entitlement Type = "+entitlement.getEnt_type());
			createUpdateEntitlementJson.put("entitlementtype", entitlement.getEnt_type());
			log.debug("Entitlement Value = "+entitlement.getTarget_ev());
			createUpdateEntitlementJson.put("entitlement_value", entitlement.getTarget_ev());
			createUpdateEntitlementJson.put("customproperty5",entitlement.getPrevernt_oor());
			createUpdateEntitlementJson.put("customproperty6",entitlement.getRegulatory_class());
			createUpdateEntitlementJson.put("customproperty8",entitlement.getBuss_app_name());
			createUpdateEntitlementJson.put("customproperty10",entitlement.getElevated_priv());
			createUpdateEntitlementJson.put("customproperty11",entitlement.getBypass_bo_approval());
			createUpdateEntitlementJson.put("customproperty12",entitlement.getCyber_ark_ind());
			createUpdateEntitlementJson.put("customproperty13",entitlement.getCc_tag());
			log.debug("Iterating through all individual entitlement owners and formatting owner(s) information as JSONArray");
			JSONArray entitlementOwnersJSONArr = new JSONArray();
			for(EntOwners entitlementOwner:OwnertoRemove) {
				log.debug("Entitlement Owner to Remove = "+entitlementOwner);
				entitlementOwnersJSONArr.add(entitlementOwner.getOwnerUName()+"##remove");
			}
			
			for (EntOwners entOwnertoAdd : ownerToAdd) {
				log.debug("Entitlement Owner to Add = " + entOwnertoAdd.getOwnerUName());
				if (entOwnertoAdd.getOwnerUName() != null && !entOwnertoAdd.getOwnerUName().trim().equalsIgnoreCase(""))
					entitlementOwnersJSONArr.add(entOwnertoAdd.getOwnerUName() + "##add");
			}
			log.debug("Entitlement owner(s) JSON Array = "+entitlementOwnersJSONArr.toJSONString());
			createUpdateEntitlementJson.put("entitlementowner",entitlementOwnersJSONArr);
			HttpClientSingleton httpClientInstance = HttpClientSingleton.getInstance();
			CloseableHttpClient httpClient = httpClientInstance.httpClient;
			httpPost.addHeader("Authorization", "Bearer "+accessToken);
			httpPost.addHeader("Content-Type", "application/json");
			log.debug("request body::"+createUpdateEntitlementJson.toJSONString());
			StringEntity stringEntity = new StringEntity(createUpdateEntitlementJson.toJSONString());
			httpPost.setEntity(stringEntity);
			response = httpClient.execute(httpPost);
		}catch(Exception e) {
			log.error("exception occurred while sending createUpdateEntitlement request");
			log.error(e);
		}finally {
			if (httpPost != null) {
				httpPost.releaseConnection();
				httpPost = null;
			}
		}
		return response;
	}
	
	public void updateEntitlement(EntitlementDataToUpdate entitlement) {
		//boolean isSuccessful = false;
		EntOwners[] ownerToRemove = getRank1EntitlementOwners(entitlement);
		EntOwners[] ownerToAdd = entitlement.getEntOwners();
		log.info("owner(s) to Add = "+Arrays.toString(ownerToAdd));
		log.info("owner(s) to Remove = "+Arrays.toString(ownerToRemove));
		
		if (ownerToRemove == null)
			ownerToRemove = new EntOwners[0];
		if (ownerToAdd == null)
			ownerToAdd = new EntOwners[0];
		// Make the two lists
		List<EntOwners> remove_owners = new ArrayList<EntOwners>(Arrays.asList(ownerToRemove));
		List<EntOwners> add_owners = new ArrayList<EntOwners>(Arrays.asList(ownerToAdd));
		
		// Prepare an intersection
		List<EntOwners> intersection = new ArrayList<EntOwners>(remove_owners);
		intersection.retainAll(add_owners);
		
		// Subtract the intersection from the union
		remove_owners.removeAll(intersection);
		add_owners.removeAll(intersection);
		
		sendCreateUpdateEntitlementRequest(entitlement, remove_owners, add_owners);
		
	}
	
	@SuppressWarnings("unchecked")
	public EntOwners[] getRank1EntitlementOwners(EntitlementDataToUpdate entitlement) {
		HttpResponse response=null;
		String url = this.props.getProperty("SAVIYNT_REST_API_BASE_URL") + "/" + this.props.getProperty("SAVIYNT_REST_API_GET_ENTITLEMENTTS_URI");
		HttpPost httpPost = new HttpPost(url);
		EntOwners[] eoArr = null;
		try {
			AccessTokenSingleton accessTokenInstance = AccessTokenSingleton.getInstance(this.props);
			String accessToken = accessTokenInstance.accessToken.getJwt();
			log.debug("URL for getEntitlements request = "+url);
			JSONObject getEntitlementsJson = new JSONObject();
			log.debug("Endpoint = "+entitlement.getTarget_ep());
			getEntitlementsJson.put("endpoint", entitlement.getTarget_ep());
			log.debug("Entitlement Type = "+entitlement.getEnt_type());
			getEntitlementsJson.put("entitlementtype", entitlement.getEnt_type());
			JSONObject entitlementFilterCriteria = new JSONObject();
			log.debug("Entitlement Value = "+entitlement.getTarget_ev());
			entitlementFilterCriteria.put("entitlement_value", entitlement.getTarget_ev());
			getEntitlementsJson.put("entitlementfiltercriteria", entitlementFilterCriteria);
			getEntitlementsJson.put("entownerwithrank", "true");
			HttpClientSingleton httpClientInstance = HttpClientSingleton.getInstance();
			CloseableHttpClient httpClient = httpClientInstance.httpClient;
			httpPost.addHeader("Authorization", "Bearer "+accessToken);
			httpPost.addHeader("Content-Type", "application/json");
			log.debug("request body = "+getEntitlementsJson.toJSONString());
			StringEntity stringEntity = new StringEntity(getEntitlementsJson.toJSONString());
			httpPost.setEntity(stringEntity);
			response = httpClient.execute(httpPost);
			if(null!=response) {
				int statusCode = response.getStatusLine().getStatusCode();
				String responseBody = EntityUtils.toString(response.getEntity());
				log.debug("response = "+responseBody);
				if(statusCode>=200 && statusCode<=299) {
					log.debug("getEntitlements http response code = "+statusCode);
					log.debug("getEntitlements request successful");
					JSONParser jsonParser = new JSONParser();
					JSONObject jsonResponse = (JSONObject) jsonParser.parse(responseBody);
					JSONArray entitlementDetailsArr = (JSONArray) jsonResponse.get("Entitlementdetails");
					if(null!=entitlementDetailsArr) {
						JSONObject entitlementDetails = (JSONObject) entitlementDetailsArr.get(0);
						if(null!=entitlementDetails) {
							Object entitlementOwner_S = (Object) entitlementDetails.get("entitlementOwner");
							log.debug("Entitlement Owner String "+entitlementOwner_S);
							if(entitlementOwner_S != null && !entitlementOwner_S.toString().equalsIgnoreCase("")) {
								JSONObject entitlementOwner = (JSONObject) entitlementDetails.get("entitlementOwner");//start here
								if (null != entitlementOwner) {
									Set<String> ownerKeys = entitlementOwner.keySet();
									for (String rank : ownerKeys) {
										JSONArray entitlementOwnerArr = (JSONArray) entitlementOwner.get(rank);
										EntOwners[] currOwnerArray = new EntOwners[entitlementOwnerArr.size()];
										for (int i = 0; i < entitlementOwnerArr.size(); i++) {
											currOwnerArray[i] = new EntOwners();
											currOwnerArray[i].setOwnerUName(entitlementOwnerArr.get(i).toString());
											currOwnerArray[i]
													.setOwnerRank(rank.substring(rank.length() - 1, rank.length()));
										}
										// eoArr = currOwnerArray;
										eoArr = appendArrays(eoArr, currOwnerArray);
									}
								}else {//It should never come here
									log.info("There are not existing Entitlement Owners for Entitlement "+entitlement.getTarget_ev());
								}
							}else {
								log.info("There are not existing Entitlement Owners for Entitlement "+entitlement.getTarget_ev());
							}
						}else {
							log.info("There is not existing Entitlement with Ent_Value "+entitlement.getTarget_ev());
						}
					}else {
						log.info("did not find Entitlement details JSON Object in Entitlementdetails JSON Array");
					}	
				}else {
					log.info("getEntitlements request unsuccessful. http response code = "+statusCode);
				}
			}else {
				log.info("getEntitlements request failed. Unable to obtain response");
			}
		}catch(Exception e) {
			log.error("exception occurred while sending getEntitlements request");
			log.error(e);
			e.printStackTrace();
		} finally {
			if (httpPost != null) {
				httpPost.releaseConnection();
				httpPost = null;
			}
		}
		if (eoArr != null)
			log.info("existing entitlement owner(s) = " + Arrays.toString(eoArr));
		else
			log.info("No existing entitlement owner(s) were found ");
		
		return eoArr;
	}
	
	public static EntOwners[] appendArrays(EntOwners[] a, EntOwners[] b) {
		int aLen = 0;
		int bLen = 0;
		if (a != null)
			aLen = a.length;
		if (b != null)
			bLen = b.length;

		EntOwners[] c = new EntOwners[aLen + bLen];
		if (a != null)
			System.arraycopy(a, 0, c, 0, aLen);
		if (b != null)
			System.arraycopy(b, 0, c, aLen, bLen);
		return c;
	}

}

package com.cigna.saviynt.util;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.http.Consts;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.cigna.saviynt.bean.AccessToken;

public class AccessTokenSingleton {
	
	private static Logger log = LogManager.getLogger(AccessTokenSingleton.class);
	
	private static AccessTokenSingleton accessTokenInstance = null;
	
	public AccessToken accessToken;
	private static Properties props;
	
	private AccessTokenSingleton(Properties properties) {
		props = properties;
		accessToken = new AccessToken();
		String accessTokenJwt = generateAccessToken();
		accessToken.setJwt(accessTokenJwt);
		accessToken.setTokenCreationTimestamp(Instant.now());
	}
	
	public static synchronized AccessTokenSingleton getInstance(Properties properties) {
		if(accessTokenInstance==null || isAccessTokenExpired(accessTokenInstance.accessToken)) {
			log.info("generating a new instance of AccessTokenSingleton");
			accessTokenInstance = new AccessTokenSingleton(properties);
		}
		return accessTokenInstance;
	}
	
	private String generateAccessToken() {
		String url = props.getProperty("SAVIYNT_REST_API_AUTH_URL");
		log.debug("Url for generating access token = "+url);
		String encryptedRefreshToken = props.getProperty("SAVIYNT_REST_API_REFRESH_TOKEN");
		Encryption encryptionObj;
		String decryptedRefreshToken;
		String accessTokenJwt=null;
		try {
			encryptionObj = new Encryption();
			decryptedRefreshToken = encryptionObj.decrypt(encryptedRefreshToken);
			HttpClientSingleton httpClientInstance = HttpClientSingleton.getInstance();
			CloseableHttpClient httpClient = httpClientInstance.httpClient;
			HttpPost httpPost = new HttpPost(url);
			httpPost.addHeader("Content-Type", "application/x-www-form-urlencoded");
			List<NameValuePair> params = new ArrayList<NameValuePair>();
			params.add(new BasicNameValuePair("grant_type", "refresh_token"));
			params.add(new BasicNameValuePair("refresh_token", decryptedRefreshToken));
			UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params, Consts.UTF_8);
			httpPost.setEntity(entity);
			HttpResponse response = httpClient.execute(httpPost);
			int statusCode = response.getStatusLine().getStatusCode();
			log.debug("http response code for generating access token request = "+statusCode);
			String responseBody = EntityUtils.toString(response.getEntity());
			if(statusCode>=200 && statusCode<=299) {
				log.info("new access token generated successfully");
				JSONParser jsonParser = new JSONParser();
				JSONObject jsonResponse = (JSONObject) jsonParser.parse(responseBody);
				accessTokenJwt = jsonResponse.get("access_token").toString();				
			}else {
				log.info("request to generate new access token failed");
				log.info("response body = "+responseBody);
			}
		} catch (Exception e) {
			log.error("exception occurred while generating access token");
			log.error(e);
		}
		return accessTokenJwt;
	}
	
	private static boolean isAccessTokenExpired(AccessToken accessToken) {
		boolean isExpired = false;
		Instant accessTokenCreationTime = accessToken.getTokenCreationTimestamp();
		Instant currentTime = Instant.now();
		Duration timeElapsed = Duration.between(accessTokenCreationTime, currentTime);
		long minutesElapsed = timeElapsed.toMinutes();
		if(minutesElapsed>50) {
			log.info("access token expired. token was created more than 50 minutes ago. should create a new access token");
			isExpired = true;
		}else {
			log.debug("access token not expired. token was created less than 50 minutes ago");
		}
		return isExpired;
	}

}

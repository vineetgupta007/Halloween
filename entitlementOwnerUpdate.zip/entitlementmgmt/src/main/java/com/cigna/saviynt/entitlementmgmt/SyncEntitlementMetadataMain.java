package com.cigna.saviynt.entitlementmgmt;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cigna.saviynt.bean.EntitlementDataToUpdate;
import com.cigna.saviynt.util.Utils;
import com.cigna.saviynt.wscall.EntitlementActions;
import com.cigna.saviynt.wscall.ExecuteAnalyticsV2;

/**
 * Hello world!
 *
 */
public class SyncEntitlementMetadataMain 
{
	private static Logger log = LogManager.getLogger(SyncEntitlementMetadataMain.class);

	public static void main(String[] args) {
		log.info("START PROGRAM");
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			String environment = null;
			String configDirectoryLocation = null;

			if (args.length < 2) {
				// Reading data using readLine
				try {
					System.out.println(
							"Please enter the environment where this utility will be run: Dev|QA|Prod, for Dev environemnt just press Enter");
					System.out.println("If no input is provided, this utility will run in Dev environment");
					environment = reader.readLine();
					
					environment = whatsTheEnvironment(environment);
					
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				int i = 0;
				String arg;
				while (i < args.length && args[i].startsWith("-")) {
					arg = args[i++];
					if (arg.equals("-environment")) {
						environment = args[i++];
						System.out.println("Environment is provided as " + environment);
					}
				}
				environment = whatsTheEnvironment(environment);
			}
			configDirectoryLocation = Paths.get(".").toAbsolutePath().normalize().toString().concat(File.separator).concat("config");
			Path path = Paths.get(configDirectoryLocation).toAbsolutePath();
			path.getParent().toString().concat(File.separator).concat("output");
			String configFileLocation = new StringBuilder(configDirectoryLocation).append(File.separator).append("config_").append(environment)
					.append(".properties").toString();
			log.info("Config file location = "+configFileLocation);
			Properties configProps = Utils.readPropertiesFromConfigFileLocation(configFileLocation);
			String inputCSVFilePath = configProps.getProperty("INPUT_FILE_LOCATION");
			log.info("Input CSV file path = "+inputCSVFilePath);
			ExecuteAnalyticsV2 executeAnalytics = new ExecuteAnalyticsV2(configProps);
			executeAnalytics.runAnalyticsReport();
			List<EntitlementDataToUpdate> finalList = executeAnalytics.getEntitlementRecordList();
			printFinalList(finalList);
			EntitlementActions eoa = new EntitlementActions(configProps);
			log.debug("iterating through all the records in the CSV file and performing add/remove/update operations");
			for(EntitlementDataToUpdate entitlement: finalList) {
				eoa.updateEntitlement(entitlement);
			}
			
		}catch(Exception e) {
			log.error(e);
		}
		log.info("END PROGRAM");
	}
	
	public static String whatsTheEnvironment(String environmentFromInput) {
		if (environmentFromInput == null || environmentFromInput.trim().length() == 0)
			environmentFromInput = "DEV";
		else {
			if (environmentFromInput.trim().equalsIgnoreCase("Dev"))
				environmentFromInput = "DEV";
			else if (environmentFromInput.trim().equalsIgnoreCase("QA"))
				environmentFromInput = "QA";
			else if (environmentFromInput.trim().equalsIgnoreCase("Prod"))
				environmentFromInput = "Prod";
			else
				environmentFromInput = "DEV";
		}
		
		return environmentFromInput;
	}
	
	private static void printFinalList(List<EntitlementDataToUpdate> entitlementRecordList) {

		// find the user application role record
		int i = 1;
		for (EntitlementDataToUpdate tmpEDarr : entitlementRecordList) {
			log.info("Printing Entitlement details for Entitlemet # "+i);
			log.info(tmpEDarr.toString());
			i++;
		}

	}
}

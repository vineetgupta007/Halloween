package com.cigna.saviynt.wscall;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;

import com.cigna.saviynt.bean.EntOwners;
import com.cigna.saviynt.bean.EntitlementData;
import com.cigna.saviynt.bean.EntitlementDataToUpdate;
import com.cigna.saviynt.bean.EntitlementReportResultsV2;
import com.cigna.saviynt.util.AccessTokenSingleton;
import com.cigna.saviynt.util.HttpClientSingleton;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ExecuteAnalyticsV2 {
	
	private static Logger log = LogManager.getLogger(ExecuteAnalyticsV2.class);
	private Properties props;
	
	private ArrayList<EntitlementDataToUpdate> entitlementRecordList = new ArrayList<EntitlementDataToUpdate>();
	
	public ExecuteAnalyticsV2 (Properties props) {
		this.props = props;
	}
	
	@SuppressWarnings("unchecked")
	public void runAnalyticsReport() {
		HttpResponse response=null;
		try {
			AccessTokenSingleton accessTokenInstance = AccessTokenSingleton.getInstance(this.props);
			String accessToken = accessTokenInstance.accessToken.getJwt();
			int totalReportResults = -1;
			int batchSize = 500; // Batch size for pagination
			int offset = 0;
            boolean hasMoreData = true;
			String url = this.props.getProperty("SAVIYNT_REST_API_BASE_URL") + "/" + this.props.getProperty("SAVIYNT_REST_API_RUN_ANALYTICS_URI")+ "?offset=" + offset + "&max=" + batchSize;
			log.debug("URL for createUpdateEntitlement request = "+url);
			JSONObject runtimeanalyticsV2 = new JSONObject();
			runtimeanalyticsV2.put("requestor", "admin");
			runtimeanalyticsV2.put("analyticsname", "CignaAndESI_EntitlementMetaData_And_Owner_Details");
			HttpClientSingleton httpClientInstance = HttpClientSingleton.getInstance();
			CloseableHttpClient httpClient = httpClientInstance.httpClient;
			HttpPost httpPost = new HttpPost(url);
			httpPost.addHeader("Authorization", "Bearer "+accessToken);
			httpPost.addHeader("Content-Type", "application/json");
			log.debug("request body::"+runtimeanalyticsV2.toJSONString());
			StringEntity stringEntity = new StringEntity(runtimeanalyticsV2.toJSONString());
			httpPost.setEntity(stringEntity);
			while (hasMoreData) {
				response = httpClient.execute(httpPost);
				if(null!=response) {
					int statusCode = response.getStatusLine().getStatusCode();
					log.debug("http response code = "+statusCode);
					String responseBody = EntityUtils.toString(response.getEntity());
					log.debug("response body = "+responseBody);
					if(statusCode>=200 && statusCode<=299) {
						log.debug("request successful");
						int totalResults = processAnalyticsResult(responseBody);
						if (totalResults > 0)
							totalReportResults = totalResults;
						offset += batchSize; // Increment offset for next batch
						if (offset >= totalReportResults)
							hasMoreData = false;
						else {
							url = this.props.getProperty("SAVIYNT_REST_API_BASE_URL") + "/" + this.props.getProperty("SAVIYNT_REST_API_RUN_ANALYTICS_URI")+ "?offset=" + offset + "&max=" + batchSize;
							log.debug("URL for createUpdateEntitlement request = "+url);
							httpPost = new HttpPost(url);
							httpPost.addHeader("Authorization", "Bearer "+accessToken);
							httpPost.addHeader("Content-Type", "application/json");
							stringEntity = new StringEntity(runtimeanalyticsV2.toJSONString());
							httpPost.setEntity(stringEntity);
							continue;
						}
					}else {
						log.debug("request unsuccessful");
						hasMoreData = false;
					}
				}else {
					log.info("runAnalyticsReport request failed. Unable to obtain response");
					hasMoreData = false;
				}
			}
		}catch(Exception e) {
			log.error("exception occurred while sending createUpdateEntitlement request");
			log.error(e);
		}
		//return response;
	}
	
	public int processAnalyticsResult(String responseBody) {
		
		ObjectMapper objectMapper = new ObjectMapper();
		int totalResults = -1;
		try {
			EntitlementReportResultsV2 entReportResults = objectMapper.readValue(responseBody, EntitlementReportResultsV2.class);
			totalResults = Integer.parseInt(entReportResults.getTotalcount());
			EntitlementData[] entData = entReportResults.getResults();
			for(EntitlementData individualRecord : entData) {
				process(individualRecord);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return totalResults;
	}
	
	private void process(EntitlementData entRecord) {

		EntitlementDataToUpdate toProcess = null;

		if (entitlementRecordList == null || entitlementRecordList.isEmpty()) {
			toProcess = new EntitlementDataToUpdate();
			toProcess.setSource_ev(entRecord.getSource_ev());
			toProcess.setBypass_bo_approval(entRecord.getBypass_bo_approval());
			toProcess.setBuss_app_name(entRecord.getBuss_app_name());
			toProcess.setCc_tag(entRecord.getCc_tag());
			toProcess.setCyber_ark_ind(entRecord.getCyber_ark_ind());
			toProcess.setElevated_priv(entRecord.getElevated_priv());
			toProcess.setRegulatory_class(entRecord.getRegulatory_class());
			toProcess.setPrevernt_oor(entRecord.getPrevernt_oor());
			toProcess.setSource_ep(entRecord.getSource_ep());
			toProcess.setTarget_ev(entRecord.getTarget_ev());
			toProcess.setTarget_ep(entRecord.getTarget_ep());
			toProcess.setEnt_type(entRecord.getSource_etype());
			if (entRecord.getEnt_Owner() != null) {
				EntOwners eo = new EntOwners();
				eo.setOwnerUName(entRecord.getEnt_Owner());
				eo.setOwnerRank(entRecord.getOwner_rank());
				EntOwners[] eoArr = new EntOwners[] { eo };
				toProcess.setEntOwners(eoArr);
			}
			entitlementRecordList.add(toProcess);
			return;
		}

		// find the Entitlement Record with same change field
		for (EntitlementDataToUpdate tmpEntRecord : entitlementRecordList) {
			if (tmpEntRecord.getSource_ev().equalsIgnoreCase(entRecord.getSource_ev())
					&& tmpEntRecord.getSource_ep().equalsIgnoreCase(entRecord.getSource_ep())) {
				toProcess = tmpEntRecord;
				EntOwners[] eoArr = tmpEntRecord.getEntOwners();
				if (entRecord.getEnt_Owner() != null) {
					EntOwners eo = new EntOwners();
					eo.setOwnerUName(entRecord.getEnt_Owner());
					eo.setOwnerRank(entRecord.getOwner_rank());
					EntOwners[] eoArrNew = new EntOwners[] { eo };
					eoArr = appendArrays(eoArr, eoArrNew);
					toProcess.setEntOwners(eoArr);
				}
				break;
			}

		}

		if (toProcess == null) {

			toProcess = new EntitlementDataToUpdate();
			toProcess.setSource_ev(entRecord.getSource_ev());
			toProcess.setBypass_bo_approval(entRecord.getBypass_bo_approval());
			toProcess.setBuss_app_name(entRecord.getBuss_app_name());
			toProcess.setCc_tag(entRecord.getCc_tag());
			toProcess.setCyber_ark_ind(entRecord.getCyber_ark_ind());
			toProcess.setElevated_priv(entRecord.getElevated_priv());
			toProcess.setRegulatory_class(entRecord.getRegulatory_class());
			toProcess.setPrevernt_oor(entRecord.getPrevernt_oor());
			toProcess.setSource_ep(entRecord.getSource_ep());
			toProcess.setTarget_ev(entRecord.getTarget_ev());
			toProcess.setTarget_ep(entRecord.getTarget_ep());
			toProcess.setEnt_type(entRecord.getSource_etype());
			if (entRecord.getEnt_Owner() != null) {
				EntOwners eo = new EntOwners();
				eo.setOwnerUName(entRecord.getEnt_Owner());
				eo.setOwnerRank(entRecord.getOwner_rank());
				EntOwners[] eoArr = new EntOwners[] { eo };
				toProcess.setEntOwners(eoArr);
			}
			entitlementRecordList.add(toProcess);
			return;

		}
	}

	public ArrayList<EntitlementDataToUpdate> getEntitlementRecordList() {
		return entitlementRecordList;
	}

	public void setEntitlementRecordList(ArrayList<EntitlementDataToUpdate> entitlementRecordList) {
		this.entitlementRecordList = entitlementRecordList;
	}
	
	public EntOwners[] appendArrays(EntOwners[] a, EntOwners[] b) {
		int aLen = 0;
		int bLen = 0;
		if (a != null)
			aLen = a.length;
		if (b != null)
			bLen = b.length;

		EntOwners[] c = new EntOwners[aLen + bLen];
		if (a != null)
			System.arraycopy(a, 0, c, 0, aLen);
		if (b != null)
			System.arraycopy(b, 0, c, aLen, bLen);
		return c;
	}

}

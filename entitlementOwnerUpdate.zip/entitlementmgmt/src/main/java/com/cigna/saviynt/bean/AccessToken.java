package com.cigna.saviynt.bean;

import java.time.Instant;

public class AccessToken {
	
	private String jwt;
	private Instant tokenCreationTimestamp;
	
	public String getJwt() {
		return jwt;
	}
	
	public void setJwt(String jwt) {
		this.jwt = jwt;
	}
	
	public Instant getTokenCreationTimestamp() {
		return tokenCreationTimestamp;
	}
	
	public void setTokenCreationTimestamp(Instant tokenCreationTimestamp) {
		this.tokenCreationTimestamp = tokenCreationTimestamp;
	}

}

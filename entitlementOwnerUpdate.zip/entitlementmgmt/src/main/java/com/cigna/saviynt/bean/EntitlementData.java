package com.cigna.saviynt.bean;

public class EntitlementData {
	
	private String source_ev;
	private String ent_Owner;
	private String bypass_bo_approval;
	private String elevated_priv;
	private String cyber_ark_ind;
	private String buss_app_name;
	private String cc_tag;
	private String source_ep;
	private String regulatory_class;
	private String target_ev;
	private String owner_rank;
	private String prevernt_oor;
	private String source_etype;
	private String target_ep;
	
	public String getSource_ev() {
		return source_ev;
	}
	public void setSource_ev(String source_ev) {
		this.source_ev = source_ev;
	}
	public String getEnt_Owner() {
		return ent_Owner;
	}
	public void setEnt_Owner(String ent_Owner) {
		this.ent_Owner = ent_Owner;
	}
	public String getBypass_bo_approval() {
		return bypass_bo_approval;
	}
	public void setBypass_bo_approval(String bypass_bo_approval) {
		this.bypass_bo_approval = bypass_bo_approval;
	}
	public String getElevated_priv() {
		return elevated_priv;
	}
	public void setElevated_priv(String elevated_priv) {
		this.elevated_priv = elevated_priv;
	}
	public String getCyber_ark_ind() {
		return cyber_ark_ind;
	}
	public void setCyber_ark_ind(String cyber_ark_ind) {
		this.cyber_ark_ind = cyber_ark_ind;
	}
	public String getBuss_app_name() {
		return buss_app_name;
	}
	public void setBuss_app_name(String buss_app_name) {
		this.buss_app_name = buss_app_name;
	}
	public String getCc_tag() {
		return cc_tag;
	}
	public void setCc_tag(String cc_tag) {
		this.cc_tag = cc_tag;
	}
	public String getSource_ep() {
		return source_ep;
	}
	public void setSource_ep(String source_ep) {
		this.source_ep = source_ep;
	}
	public String getRegulatory_class() {
		return regulatory_class;
	}
	public void setRegulatory_class(String regulatory_class) {
		this.regulatory_class = regulatory_class;
	}
	public String getTarget_ev() {
		return target_ev;
	}
	public void setTarget_ev(String target_ev) {
		this.target_ev = target_ev;
	}
	public String getOwner_rank() {
		return owner_rank;
	}
	public void setOwner_rank(String owner_rank) {
		this.owner_rank = owner_rank;
	}
	public String getPrevernt_oor() {
		return prevernt_oor;
	}
	public void setPrevernt_oor(String prevernt_oor) {
		this.prevernt_oor = prevernt_oor;
	}
	public String getSource_etype() {
		return source_etype;
	}
	public void setSource_etype(String source_etype) {
		this.source_etype = source_etype;
	}
	public String getTarget_ep() {
		return target_ep;
	}
	public void setTarget_ep(String target_ep) {
		this.target_ep = target_ep;
	}
	
}

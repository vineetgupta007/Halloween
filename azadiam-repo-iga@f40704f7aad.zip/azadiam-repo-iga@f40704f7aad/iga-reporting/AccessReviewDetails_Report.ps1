$servicePrincipalConnection = Get-AutomationConnection -Name 'Azure-SPN-Connect'
Connect-AzureAD –TenantId $servicePrincipalConnection.TenantId –ApplicationId $servicePrincipalConnection.ApplicationId –CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
Write-Output " AzureAD Connected!"
Connect-AzAccount -ServicePrincipal -Tenant $servicePrincipalConnection.TenantID -ApplicationId $servicePrincipalConnection.ApplicationID -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
Write-Output " AzAccount Connected!"
$storageAccountRG = Get-AutomationVariable -Name "storageAccountRG"
$storageContainerName= Get-AutomationVariable -Name "storageContainerName"
$storageAccountName= Get-AutomationVariable -Name "storageAccountName"
$fileName= "AccessReviewDetailsReport.csv"
Write-Output "Start!"
Connect-MgGraph -ClientID $servicePrincipalConnection.ApplicationId -TenantId $servicePrincipalConnection.TenantId -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
Select-MgProfile -Name "beta"
$businessTemplate=Get-MgBusinessFlowTemplate -All
$resultsarray =@()
ForEach ($template in $businessTemplate){
	$tempID = $template.Id
    $accessReviews =  Get-MgAccessReview -Filter "businessFlowTemplateId eq '$($tempID)'" 
	ForEach ($accessReview in $accessReviews){
		$accessReviewDecision = Get-MgAccessReviewDecision -AccessReviewId $accessReview.Id
		ForEach ($decision in $accessReviewDecision){
		   $Obj = new-object PSObject
		   $Obj | add-member  -membertype NoteProperty -name "Access Review Name" -Value $accessReview.DisplayName
		   $Obj | add-member  -membertype NoteProperty -name "ReviewedEntity" -Value $accessReview.ReviewedEntity.DisplayName
		   $Obj | add-member  -membertype NoteProperty -name "AccessRecommendation" -Value $decision.AccessRecommendation
		   $Obj | add-member  -membertype NoteProperty -name "ReviewResult" -Value $decision.ReviewResult
		   $Obj | add-member  -membertype NoteProperty -name "Reviewer Name" -Value $decision.ReviewedBy.DisplayName
		   $Obj | add-member  -membertype NoteProperty -name "Resource Name" -Value $decision.AdditionalProperties.userDisplayName
		   if($null -ne $accessReview.StartDateTime){
			   $startDate = ($accessReview.StartDateTime).ToShortDateString()
			}
		   else{
			   $startDate = $null
			}
		   $Obj | add-member  -membertype NoteProperty -name "StartDate" -Value $startDate
		   if($null -ne $accessReview.EndDateTime){
			   $endDate = ($accessReview.EndDateTime).ToShortDateString()
			}
		   else{
				$endDate = $null
			}
		   $Obj | add-member  -membertype NoteProperty -name "EndDate" -Value $endDate
		   $resultsarray += $Obj
		}
	}
}
Write-Output "resultsarray created"

$resultsarray | Export-Csv -Encoding UTF8  -Delimiter "," -Path $fileName -NoTypeInformation 
Write-Output "CSV exported!"
try {
            $LASTEXITCODE = 1
			$storageAccount = Get-AzStorageAccount -ResourceGroupName $storageAccountRG -Name $storageAccountName
                if ($storageAccount) {
                    $key = (Get-AzStorageAccountKey -ResourceGroupName $storageAccountRG -AccountName $storageAccountName).Value[0]
                    $storageContext = New-AzStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $key
					$storageContainer = Get-AzStorageContainer -Context $storageContext -Name $storageContainerName
                    if ($storageContainer) {
                        Write-Output "Storage Container '$storageContainerName' exist"
						$upload = Set-AzStorageBlobContent -Container $storageContainerName -File $fileName -Context $storageContext -Force
                    }else{
						Write-Error "Storage container does not exist in resource group"
					}
					
				}else{
					Write-Error "Storage account does not exist in resource group"
				}
			}catch [System.Exception] {
				$ErrorMessage = $_.Exception.Message
				Write-Error $ErrorMessage
			}

Write-Output "End!"

$servicePrincipalConnection = Get-AutomationConnection -Name 'Azure-SPN-Connect'
Connect-AzureAD –TenantId $servicePrincipalConnection.TenantId –ApplicationId $servicePrincipalConnection.ApplicationId –CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
Write-Output " AzureAD Connected!"
Connect-AzAccount -ServicePrincipal -Tenant $servicePrincipalConnection.TenantID -ApplicationId $servicePrincipalConnection.ApplicationID -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
Write-Output " AzAccount Connected!"
$storageAccountRG = Get-AutomationVariable -Name "storageAccountRG"
$storageContainerName= Get-AutomationVariable -Name "storageContainerName"
$storageAccountName= Get-AutomationVariable -Name "storageAccountName"
$daysInterval= Get-AutomationVariable -Name "daysInterval"
$fileName= "SignInLogsReport.csv"

Write-Output "Start!"
Connect-MgGraph -ClientID $servicePrincipalConnection.ApplicationId -TenantId $servicePrincipalConnection.TenantId -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
Select-MgProfile -Name "beta"
$startDate = ((Get-Date).addDays(-1*$daysInterval)).ToString("yyyy-MM-dd")
$signInLogs = Get-MgAuditLogSignIn -filter "createdDateTime ge $startDate" -All:$true
$resultsarray =@()
ForEach ($log in $signInLogs){
	   $Obj = new-object PSObject
	   $Obj | add-member  -membertype NoteProperty -name "SignIn Date" -Value $log.CreatedDateTime.ToShortDateString()
	   $Obj | add-member  -membertype NoteProperty -name "SignIn Time" -Value $log.CreatedDateTime.ToShortTimeString()
       $Obj | add-member  -membertype NoteProperty -name "AppDisplay Name" -Value $log.AppDisplayName
       $Obj | add-member  -membertype NoteProperty -name "ClientAppUsed" -Value $log.ClientAppUsed
	   $Obj | add-member  -membertype NoteProperty -name "ConditionalAccess Status" -Value $log.ConditionalAccessStatus
	   if(0 -eq ($log.Status.ErrorCode)){
			   $Obj | add-member  -membertype NoteProperty -name "Status" -Value "Success"
			   $Obj | add-member  -membertype NoteProperty -name "FailureReason" -Value ""
			}
		   else{
			   $Obj | add-member  -membertype NoteProperty -name "Status" -Value "Failure"
			   $Obj | add-member  -membertype NoteProperty -name "FailureReason" -Value $log.Status.FailureReason
			}
	   
	   $Obj | add-member  -membertype NoteProperty -name "UserDisplay Name" -Value $log.UserDisplayName
	   $Obj | add-member  -membertype NoteProperty -name "UserPrincipal Name" -Value $log.UserPrincipalName
	    $resultsarray += $Obj
    }

$resultsarray | Export-Csv -Encoding UTF8  -Delimiter "," -Path $fileName -NoTypeInformation 
Write-Output "CSV exported!"
try {
            $LASTEXITCODE = 1
			$storageAccount = Get-AzStorageAccount -ResourceGroupName $storageAccountRG -Name $storageAccountName
                if ($storageAccount) {
                    $key = (Get-AzStorageAccountKey -ResourceGroupName $storageAccountRG -AccountName $storageAccountName).Value[0]
                    $storageContext = New-AzStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $key
					$storageContainer = Get-AzStorageContainer -Context $storageContext -Name $storageContainerName
                    if ($storageContainer) {
                        Write-Output "Storage Container '$storageContainerName' exist"
						$upload = Set-AzStorageBlobContent -Container $storageContainerName -File $fileName -Context $storageContext -Force
                    }else{
						Write-Error "Storage container does not exist in resource group"
					}
					
				}else{
					Write-Error "Storage account does not exist in resource group"
				}
			}catch [System.Exception] {
				$ErrorMessage = $_.Exception.Message
				Write-Error $ErrorMessage
			}

Write-Output "End!"

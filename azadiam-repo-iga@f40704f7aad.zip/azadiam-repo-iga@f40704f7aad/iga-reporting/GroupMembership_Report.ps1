$servicePrincipalConnection = Get-AutomationConnection -Name 'Azure-SPN-Connect'
Connect-AzureAD –TenantId $servicePrincipalConnection.TenantId –ApplicationId $servicePrincipalConnection.ApplicationId –CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
Write-Output " AzureAD Connected!"
Connect-AzAccount -ServicePrincipal -Tenant $servicePrincipalConnection.TenantID -ApplicationId $servicePrincipalConnection.ApplicationID -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
Write-Output " AzAccount Connected!"
$storageAccountRG = Get-AutomationVariable -Name "storageAccountRG"
$storageContainerName= Get-AutomationVariable -Name "storageContainerName"
$storageAccountName= Get-AutomationVariable -Name "storageAccountName"
$fileName= "groupMembershipReport.csv"
Write-Output "storageAccountRG : $storageAccountRG"
Write-Output "storageContainerName : $storageContainerName"
Write-Output "storageAccountName : $storageAccountName"

Write-Output "Start!"
$groups=Get-AzureADGroup -All $true
Write-Output "AzureADGroup Loaded, Now Iterating.."
$resultsarray =@()
ForEach ($group in $groups){
    $members = Get-AzureADGroupMember -ObjectId $group.ObjectId -All $true
	ForEach ($member in $members){
       $UserObject = new-object PSObject
       $UserObject | add-member  -membertype NoteProperty -name "Group Name" -Value $group.DisplayName
       $UserObject | add-member  -membertype NoteProperty -name "Member Name" -Value $member.DisplayName
       $UserObject | add-member  -membertype NoteProperty -name "ObjType" -Value $member.ObjectType
       $UserObject | add-member  -membertype NoteProperty -name "UserType" -Value $member.UserType
       $UserObject | add-member  -membertype NoteProperty -name "UserPrinicpalName" -Value $member.UserPrincipalName
       $resultsarray += $UserObject
    }
}
Write-Output "resultsarray created"

$resultsarray | Export-Csv -Encoding UTF8  -Delimiter "," -Path $fileName -NoTypeInformation 
Write-Output "CSV exported!"
try {
            $LASTEXITCODE = 1
			$storageAccount = Get-AzStorageAccount -ResourceGroupName $storageAccountRG -Name $storageAccountName
                if ($storageAccount) {
                    $key = (Get-AzStorageAccountKey -ResourceGroupName $storageAccountRG -AccountName $storageAccountName).Value[0]
                    $storageContext = New-AzStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $key
					$storageContainer = Get-AzStorageContainer -Context $storageContext -Name $storageContainerName
                    if ($storageContainer) {
                        Write-Output "Storage Container '$storageContainerName' exist"
						$upload = Set-AzStorageBlobContent -Container $storageContainerName -File $fileName -Context $storageContext -Force
                    }else{
						Write-Error "Storage container does not exist in resource group"
					}
					
				}else{
					Write-Error "Storage account does not exist in resource group"
				}
			}catch [System.Exception] {
				$ErrorMessage = $_.Exception.Message
				Write-Error $ErrorMessage
			}

Write-Output "End!"

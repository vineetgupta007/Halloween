$servicePrincipalConnection = Get-AutomationConnection -Name 'Azure-SPN-Connect'
Connect-AzureAD –TenantId $servicePrincipalConnection.TenantId –ApplicationId $servicePrincipalConnection.ApplicationId –CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
Write-Output " AzureAD Connected!"
Connect-AzAccount -ServicePrincipal -Tenant $servicePrincipalConnection.TenantID -ApplicationId $servicePrincipalConnection.ApplicationID -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
Write-Output " AzAccount Connected!"
$storageAccountRG = Get-AutomationVariable -Name "storageAccountRG"
$storageContainerName= Get-AutomationVariable -Name "storageContainerName"
$storageAccountName= Get-AutomationVariable -Name "storageAccountName"
$daysInterval= Get-AutomationVariable -Name "daysInterval"
$fileName= "ProvisioningLogsReport.csv"

Write-Output "Start!"
Connect-MgGraph -ClientID $servicePrincipalConnection.ApplicationId -TenantId $servicePrincipalConnection.TenantId -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
Select-MgProfile -Name "beta"
$startDate = ((Get-Date).addDays(-1*$daysInterval)).ToString("yyyy-MM-dd")
$provisioningLogs = Get-MgAuditLogProvisioning -filter "ActivityDateTime ge $startDate"
$resultsarray =@()
ForEach ($log in $provisioningLogs){
	   $Obj = new-object PSObject
	   $Obj | add-member  -membertype NoteProperty -name "ActivityDateTime" -Value $log.ActivityDateTime
       $Obj | add-member  -membertype NoteProperty -name "InitiatedBy" -Value $log.InitiatedBy.DisplayName
       $Obj | add-member  -membertype NoteProperty -name "ProvisioningAction" -Value $log.ProvisioningAction
	   $Obj | add-member  -membertype NoteProperty -name "Status" -Value $log.ProvisioningStatusInfo.Status
	   $Obj | add-member  -membertype NoteProperty -name "SourceIdentity" -Value $log.SourceIdentity.DisplayName
	   $Obj | add-member  -membertype NoteProperty -name "IdentityType" -Value $log.SourceIdentity.IdentityType
	   $Obj | add-member  -membertype NoteProperty -name "TargetSystem" -Value $log.TargetSystem.DisplayName
	    $resultsarray += $Obj
    }

$resultsarray | Export-Csv -Encoding UTF8  -Delimiter "," -Path $fileName -NoTypeInformation 
Write-Output "CSV exported!"
try {
            $LASTEXITCODE = 1
			$storageAccount = Get-AzStorageAccount -ResourceGroupName $storageAccountRG -Name $storageAccountName
                if ($storageAccount) {
                    $key = (Get-AzStorageAccountKey -ResourceGroupName $storageAccountRG -AccountName $storageAccountName).Value[0]
                    $storageContext = New-AzStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $key
					$storageContainer = Get-AzStorageContainer -Context $storageContext -Name $storageContainerName
                    if ($storageContainer) {
                        Write-Output "Storage Container '$storageContainerName' exist"
						$upload = Set-AzStorageBlobContent -Container $storageContainerName -File $fileName -Context $storageContext -Force
                    }else{
						Write-Error "Storage container does not exist in resource group"
					}
					
				}else{
					Write-Error "Storage account does not exist in resource group"
				}
			}catch [System.Exception] {
				$ErrorMessage = $_.Exception.Message
				Write-Error $ErrorMessage
			}

Write-Output "End!"

package com.initechdemo.mycompanyapp;

public class TPAndroidConstants {
    final static String WEB_SERVICE_URL = "https://secretapi-azureadidmdev.msappproxy.net/tpapi/product";
    final static String UNAUTH_WEBSERVICE_ACCESS_ERROR = "You are not authorized to use this application at this time. Please Contact your System Administrator";
    final static String PRODUCT_NAME="product_name";
    final static String PRODUCT_PRICE="product_price";
    final static String PRODUCT_ID="product_id";
    final static String MAIN_FRG_TAG="MAIN_FRAGMENT";
    final static String PRODUCT_OPS_ERR_MSG="Empty Product name or product price";
    final static String WELCOME_STR="Welcome ";
    final static String SCOPE_USER_IMPERSONATION="https://secretapi-azureadidmdev.msappproxy.net/tpapi//user_impersonation";
    final static String OAUTH_URL="https://login.microsoftonline.com/bfda942f-a624-4636-9b1b-c4c13e93dfee/oauth2/v2.0";
    final static String RESP_DISPLAY_NAME="displayName";
    final static String WELCOME_APP_MSG="Welcome To TP Android Price Check Tool. Click Here to Login";
    final static String SIGN_OUT_MSG="Signed Out.";
    final static String PKG_APP="com.initechdemo.mycompanyapp";
    final static String USERPROFILE_DISPNAME="displayName";
    final static String USERPROFILE_BUSINESSPHONE="businessPhones";
    final static String USERPROFILE_JOBTITLE="jobTitle";
    final static String USERPROFILE_UPN="userPrincipalName";
    final static String USERPROFILE_GIVENNAME="givenName";
    final static String USERPROFILE_MAIL="mail";
    final static String USERPROFILE_CELLPHONE="mobilePhone";
    final static String USERPROFILE_SURNAME="surname";
    final static String USERPROFILE_OFFLOC="officeLocation";
    final static String USERPROF_FRG_TAG="USER_PROFILE_FRAGMENT";
}

# TPAndroid Application 

This is the source code for building TPAndroid application which is one of the many demo applications of Azure Active Directory/Identity and Access Management project.

## Pre-reqs

### JDK 
    1. Navigate to https://www.oracle.com/java/technologies/javase-jdk14-downloads.html
    2. Download the Windows x64 Compressed Archive 
    3. Unzip the file at a specific location like `C:\Users\%USERNAME%\Applications\`
    4. Ensure that JDK bin folder is in location `C:\Users\%USERNAME%\Applications\jdk-14.0.1\bin`

### Android SDK

1. Navigate to https://developer.android.com/studio and scroll down to section "Command line tools only"
2. Download the latest version for Windows and store it at appropriate location
3. Create the following folder `C:\Users\%USERNAME%\Applications\AndroidSDK\cmdline-tools` (This is needed to ensure that SDK has specific directory structure needed to operate)
4. Unzip the downloaded file into the folder such that location of Android SDK bin folder is `C:\Users\%USERNAME%\Applications\AndroidSDK\cmdline-tools\tools\bin`
5. Open a command prompt (CMD) and set the following environment variable
      ```
      $ set PATH=C:\Users\%USERNAME%\Applications\AndroidSDK\cmdline-tools\tools\bin;C:\Users\%USERNAME%\Applications\jdk-14.0.1\bin;%PATH%
      ```
6. Accept all the licenses before starting build process 
      ```
      $ sdkmanager.bat --licenses
      ```

## Build
The following process must be followed to build the code

1. Checkout the source code and store it C:\Users\%USERNAME%\projects\azuread directory. It will create `azadiam-repo` directory at this location
    ```
    $ git clone https://code.deliverybackbone.amr.kpmg.com/scm/azadiam/azadiam-repo.git
    ```
2. Update the SDK Directory location in the `C:\Users\%USERNAME%\projects\azuread\azadiam-repo\demoapps\TPAndroidApp\local.properties` file. Replace `%USERNAME%` with applicable value.
    ```
    sdk.dir=C\:\\Users\\%USERNAME%\\Applications\\AndroidSDK
    ```
3.  Open a command prompt (CMD) and start build process
    ```
    $ set PATH=C:\Users\%USERNAME%\Applications\AndroidSDK\cmdline-tools\tools\bin;C:\Users\%USERNAME%\Applications\jdk-14.0.1\bin;%PATH%
    $ cd C:\Users\%USERNAME%\projects\azuread\azadiam-repo\demoapps\TPAndroidApp\
    $ gradlew.bat assemble
    ```
4.  Confirm the application has been created in `C:\Users\%USERNAME%\projects\azuread\azadiam-repo\demoapps\TPAndroidApp\app\build\outputs\apk\release\app-release-unsigned.apk`

## Run

1.  Before running, ensure that the following components are installed and licenses accepted.
    ```
    > set PATH=C:\Users\%USERNAME%\Applications\AndroidSDK\emulator;C:\Users\%USERNAME%\Applications\AndroidSDK\cmdline-tools\tools\bin;C:\Users\%USERNAME%\Applications\jdk-14.0.1\bin;%PATH%
    > sdkmanager --list
    Installed packages:=====================] 100% Computing updates...
       Path                 | Version | Description                    | Location
       -------              | ------- | -------                        | -------
       build-tools;29.0.3   | 29.0.3  | Android SDK Build-Tools 29.0.3 | build-tools\29.0.3\
       emulator             | 30.0.12 | Android Emulator               | emulator\
       patcher;v4           | 1       | SDK Patch Applier v4           | patcher\v4\
       platform-tools       | 30.0.2  | Android SDK Platform-Tools     | platform-tools\
       platforms;android-29 | 4       | Android SDK Platform 29        | platforms\android-29\
    > sdkmanager --licenses
    ```

2. Install a system image of Android-29 with Google Playstore enabled for x86 platform.
    ```
    sdkmanager --install "system-images;android-29;google_apis_playstore;x86_64" "extras;intel;Hardware_Accelerated_Execution_Manager"
    sdkmanager --licenses
    ```
3. Install the Hardware Accelerated component by running `intelhaxm-android.exe` available in `C:\Users\%USERNAME%\Applications\AndroidSDK\extras\intel\Hardware_Accelerated_Execution_Manager`. Please note that this step would need administrator access to complete the installation.
4. Configure Android Virtual Device (AVD) using following command
    ```
    avdmanager create avd --name "AndroidPhone"  --abi "x86_64" --package "system-images;android-29;google_apis_playstore;x86_64"
    ```
5. Start the AVD using emulator
    ```
    emulator @AndroidPhone -dns-server 8.8.8.8
    ```
6. Emulator starts running and then you need to complete the setup.
7. Start google play store, login and install "Microsoft Authenticator" Application
8. Install the APK. You can also run `gradlew.bat installDebug` to install the apk
    ```
    adb install app\build\outputs\apk\debug\app-debug.apk 
    ```
9. On the emulator drag the list of available application from the bottom of screen using mouse. Click on "MyCompanyApp" (android face on green circle) to lauch the application..

Please go to this link for a detailed instructions on the build guide.
https://deliverybackbone.amr.kpmg.com/collaboration/display/AZADIAM/TPAndroid+Mobile+App


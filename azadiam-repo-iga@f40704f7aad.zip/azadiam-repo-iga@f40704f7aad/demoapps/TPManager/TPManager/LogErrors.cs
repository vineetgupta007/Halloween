﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;

namespace TPManager
{
    /// <summary>
    /// Capturing error logs
    /// </summary>
    public class LogErrors
    {
        //Method to write exceptions into Error Logs
        public void Write(Exception ex,string ErrorLog)
        {
            //string ErrorLog = Server.MapPath("~\\App_Data\\ErrorLog.txt");
            string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;
            message += string.Format("Message: {0}", ex.Message);
            message += Environment.NewLine;
            message += string.Format("Source: {0}", ex.Source);
            message += Environment.NewLine;
            message += string.Format("StackTrace: {0}", ex.StackTrace);
            message += Environment.NewLine;
            message += string.Format("TargetSite: {0}", ex.TargetSite.ToString());
            message += Environment.NewLine;
            message += string.Format("InnerException: {0}", ex.InnerException);
            message += Environment.NewLine;
            message += string.Format("HelpLink : {0}", ex.HelpLink);
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;
            using (StreamWriter writer = new StreamWriter(ErrorLog, true))
            {
                writer.WriteLine(message);
                writer.Close();
            }
        }
    }
}
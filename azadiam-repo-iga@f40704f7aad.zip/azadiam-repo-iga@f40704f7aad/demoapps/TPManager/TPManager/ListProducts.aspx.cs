﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Serialization;
namespace TPManager
{
    /// <summary>
    /// List existing product details
    /// </summary>///
    public partial class ListProducts : Page
    {
        //Variable declaration
        List<ProductEntity> lstProduct = new List<ProductEntity>();
        string constr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        string ErrorLog = HttpContext.Current.ApplicationInstance.Server.MapPath("~/App_Data/ErrorLog.txt");
        string xmlPath = HttpContext.Current.ApplicationInstance.Server.MapPath("~/App_Data/ProductDetails.xml");

        LogErrors le = new LogErrors();
        MySQLHelper msh = new MySQLHelper();
        //string ErrorLog = ConfigurationManager.AppSettings["ErrorLog"].ToString();

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                if (!IsPostBack)
                {

                    //BindGrid();
                    BindGridView();
                }
            }
            catch (Exception ex)
            {
                le.Write(ex, ErrorLog);
            }
        }


        /// <summary>
        /// Method to bind values to gridview
        /// </summary>
        protected void BindGridView()
        {
            try
            {
                /*
                XmlSerializer deserializer = new XmlSerializer(typeof(Products));
                TextReader reader = new StreamReader(xmlPath);
                object obj = deserializer.Deserialize(reader);
                Products XmlData = (Products)obj;
                reader.Close();
                
                lstProduct = XmlData.Product.ToList();
                */

                lstProduct = msh.GetProductList(constr);

                if (lstProduct != null)
                {

                    gvProduct.DataSource = lstProduct;
                    gvProduct.DataBind();
                }
                else
                {
                    gvProduct.DataSource = null;
                    gvProduct.DataBind();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

       
    }
}
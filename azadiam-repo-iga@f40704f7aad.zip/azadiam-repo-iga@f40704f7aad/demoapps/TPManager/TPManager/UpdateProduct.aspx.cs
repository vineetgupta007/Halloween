﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace TPManager
{
    /// <summary>
    /// Update existing product details
    /// </summary>
    public partial class UpdateProduct : Page
    {
        //Variable declaration
        List<ProductEntity> lstProduct = new List<ProductEntity>();
        string ErrorLog = HttpContext.Current.ApplicationInstance.Server.MapPath("~/App_Data/ErrorLog.txt");
        string xmlPath = HttpContext.Current.ApplicationInstance.Server.MapPath("~/App_Data/ProductDetails.xml");
        string constr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        LogErrors le = new LogErrors();
        MySQLHelper msh = new MySQLHelper();

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!this.IsPostBack)
                {
                    //Populate product details to gridvew
                    this.BindGridView();
                }
            }
            catch (Exception ex)
            {
                le.Write(ex, ErrorLog);
            }

        }

        /// <summary>
        /// Method to bind values to gridview
        /// </summary>
        protected void BindGridView()
        {
            try
            {
                lstProduct = msh.GetProductList(constr);
                if (lstProduct != null)
                {

                    gvProduct.DataSource = lstProduct;
                    gvProduct.DataBind();
                }
                else
                {
                    gvProduct.DataSource = null;
                    gvProduct.DataBind();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// gvProduct_RowEditing event on editing the existing products 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvProduct_RowEditing(object sender, GridViewEditEventArgs e)
        {
            try
            {
                gvProduct.EditIndex = e.NewEditIndex;
                this.BindGridView();
            }
            catch (Exception ex)
            {
                le.Write(ex, ErrorLog);
            }
        }

        /// <summary>
        /// gvProduct_RowUpdating event on persisting the changes back to xml
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvProduct_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            try
            {
                decimal amount;
                bool flag;

                GridViewRow row = gvProduct.Rows[e.RowIndex];
                int productID = Convert.ToInt32(gvProduct.DataKeys[e.RowIndex]["product_id"]);
                TextBox txtProductName = row.FindControl("txtProductName") as TextBox;
                TextBox txtProductPrice = row.FindControl("txtProductPrice") as TextBox;

                if ((txtProductName != null) && (txtProductPrice != null))
                {
                    ProductEntity product = this.Products.Find(c => c.product_id == productID);
                    product.product_name = txtProductName.Text.Trim();
                    flag = decimal.TryParse(txtProductPrice.Text, out amount);
                    product.product_price = amount;

                    gvProduct.EditIndex = -1;
                    //UpdateXML(product);
                    msh.UpdateProduct(constr, product);
                    this.BindGridView();
                }
            }
            catch (Exception ex)
            {
                le.Write(ex, ErrorLog);
            }
        }

        /// <summary>
        /// gvProduct_RowCancelingEdit event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvProduct_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            try
            {
                //Reset the edit index.
                gvProduct.EditIndex = -1;
                //Bind data to the GridView control.
                this.BindGridView();
            }
            catch (Exception ex)
            {
                le.Write(ex, ErrorLog);
            }
        }

        protected void gvProduct_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            
            GridViewRow row = (GridViewRow)gvProduct.Rows[e.RowIndex];
            int productID = Convert.ToInt32(gvProduct.DataKeys[e.RowIndex]["product_id"]);
            msh.DeleteProduct(constr, productID);
            this.BindGridView();
        }


        /// <summary>
        /// Method to bind the viewstate
        /// </summary>
        private List<ProductEntity> Products
        {
            get
            {
                if (this.ViewState["ProductEntity"] == null)
                    this.ViewState["ProductEntity"] = msh.GetProductList(constr);

                return this.ViewState["ProductEntity"] as List<ProductEntity>;
            }
        }

    }
}
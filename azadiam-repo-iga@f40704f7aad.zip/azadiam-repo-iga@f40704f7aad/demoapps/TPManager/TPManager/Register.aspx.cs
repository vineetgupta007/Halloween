﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace TPManager
{
    /// <summary>
    /// Register new product details
    /// </summary>
    public partial class Register : Page
    {
        //Variable declaration
        List<ProductEntity> lstProduct = new List<ProductEntity>();
        LogErrors le = new LogErrors();
        string constr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        string ErrorLog = HttpContext.Current.ApplicationInstance.Server.MapPath("~/App_Data/ErrorLog.txt");        
        MySQLHelper msh = new MySQLHelper();

        
        /// <summary>
        /// Page_Load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                if (!this.IsPostBack)
                {
                    //Populate product details to gridvew
                    this.BindGridView();
                }
            }
            catch (Exception ex)
            {
                le.Write(ex, ErrorLog);
            }

        }

        /// <summary>
        /// Method to bind values to gridview
        /// </summary>
        protected void BindGridView()
        {
            try
            {
                lstProduct = msh.GetProductList(constr);
                if (lstProduct != null)
                {
                    gvProduct.DataSource = lstProduct;
                    gvProduct.DataBind();
                }
                else
                {
                    gvProduct.DataSource = null;
                    gvProduct.DataBind();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// gvProduct_RowCommand event on Adding new product
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void gvProduct_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {

                decimal amount;
                bool flag;

                if (e.CommandName == "Insert")
                {
                    flag = decimal.TryParse(((TextBox)gvProduct.FooterRow.FindControl("txtProductPrice")).Text, out amount);
                    ProductEntity product = new ProductEntity
                    {
                        product_id = int.Parse(((TextBox)gvProduct.FooterRow.FindControl("txtProductID")).Text),
                        product_name = ((TextBox)gvProduct.FooterRow.FindControl("txtProductName")).Text,
                        product_price = amount
                    };

                    msh.RegisterProduct(constr, product);
                    BindGridView();
                    //UpdateXML(product);


                }
            }
            catch (Exception ex)
            {
                le.Write(ex, ErrorLog);
            }

        }

        /// <summary>
        /// Method to bind the viewstate
        /// </summary>
        private List<ProductEntity> Products
        {
            get
            {
                if (this.ViewState["ProductEntity"] == null)
                    this.ViewState["ProductEntity"] = msh.GetProductList(constr);

                return this.ViewState["ProductEntity"] as List<ProductEntity>;
            }


        }
    }
}
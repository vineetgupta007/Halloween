﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Web;

namespace TPManager
{
    [Serializable]
    public class ProductEntity
    {
        public int product_id { get; set; }
        public string product_name { get; set; }
        public decimal product_price { get; set; }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Security.Principal;
using System.Configuration;

namespace TPManager
{
    /// <summary>
    /// The main SiteMaster class    
    /// </summary>
    public partial class SiteMaster : MasterPage
    {
        /// <summary>
        /// Page_Load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            // Fetch the logged in user display name
            LogErrors le = new LogErrors();
            string ErrorLog = HttpContext.Current.ApplicationInstance.Server.MapPath("~/App_Data/ErrorLog.txt");            
            try
            {
                // Code to get the displayname from Active Directory
                LoginName str = Lname;
                UserPrincipal userPrincipal = GetActiveDirectoryUser(Environment.UserName);      
	  if(userPrincipal !=null)          
                	Lname.FormatString = userPrincipal.DisplayName;               
            }
            catch (Exception ex)
            {
                le.Write(ex, ErrorLog);
            }
        }

        /// <summary>
        /// Method to get User details from AD
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        private UserPrincipal GetActiveDirectoryUser(string userName)
        {
            using (var ctx = new PrincipalContext(ContextType.Domain))
            using (var user = new UserPrincipal(ctx) { SamAccountName = userName })
            using (var searcher = new PrincipalSearcher(user))
            {
                return searcher.FindOne() as UserPrincipal;
            }
        }
    }
}
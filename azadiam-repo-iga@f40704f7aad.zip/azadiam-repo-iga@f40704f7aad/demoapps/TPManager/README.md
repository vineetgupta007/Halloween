# TPManager Application

This application is used to simulate Integrated Windows Authentication enabled authentication process for validation Azure Application Proxy capability.

## Pre-requisite

The following pre-requisites must be met

### MySQL
The installation process is as follows

1. Install mysql and enter y when prompted.
    ```
    rpm -Uvh https://repo.mysql.com/mysql80-community-release-el7-3.noarch.rpm 
    sed -i 's/enabled=1/enabled=0/' /etc/yum.repos.d/mysql-community.repo
    yum --enablerepo=mysql80-community install mysql-community-server 
    ```
2. Start service and locate temporary password
    ```
    service mysqld start
    grep "A temporary password" /var/log/mysqld.log
    ```
3. Initiate secure installation and provide temporary password from previous step. Provide new password. For the first prompt specify "N" and then provide "y" for all other prompts
    ```
    mysql_secure_installation 
    ```
4. Restart service, enable auto-restart and disable firewall
    ```
    service mysqld restart
    chkconfig mysqld on
    sudo systemctl stop firewalld
    ```
5. Connect to database
    ```
    mysql -u root -p
    ```
6. Create new database and initialize table.
    ```
    CREATE DATABASE initechdemo_db; 
    use initechdemo_db;
    CREATE TABLE products (product_id INT, product_name VARCHAR(50), product_price DECIMAL(10,2), CONSTRAINT products_pk PRIMARY KEY (product_id));
    SHOW TABLES;INSERT INTO products VALUES(1,"iPhone","60000");
    INSERT INTO products VALUES(1,"iPhone","60000");
    INSERT INTO products VALUES(2,"iPad","580.00");
    SELECT * FROM products;
    ```
7. Create new user with password (Replace **** with valid password)
    ```
    CREATE USER 'initechAdmin'@'localhost' IDENTIFIED BY '*********';
    GRANT ALL PRIVILEGES ON *.* TO 'initechAdmin'@'localhost' WITH GRANT OPTION;
    CREATE USER 'initechAdmin'@'%' IDENTIFIED BY '*********';
    GRANT ALL PRIVILEGES ON *.* TO 'initechAdmin'@'%' WITH GRANT OPTION;
    exit
    ```
### Active Directory

#### Group
The following groups have been created in us.initechdemo.com domain 

1. GBL-US_TPManager_Admin
2. GBL-US_TPManager_Users

#### Users
The following users have been created and assigned to given groups

|      User ID        |   Password     |    Group Name           |
|---------------------|----------------|-------------------------|
|tpmanageruser01      | Passworld123!  | GBL-US_TPManager_Users  |
|tpmanageradminuser01 | Passworld123!  | GBL-US_TPManager_Admin  |

### .NET 4.5
All the development and deployment servers must have .NET 4.5+ installed
```
if ( (Get-ItemProperty -Path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" -Name Release).Release -gt 378389 ) { 'Installed' } else {'Not Installed'}
```
### IIS (Deployment)

Install IIS and web management service as follows
```
Install-WindowsFeature -name Web-Server -IncludeManagementTools
Install-WindowsFeature  Web-Mgmt-Service
Set-ItemProperty -Path  HKLM:\SOFTWARE\Microsoft\WebManagement\Server -Name EnableRemoteManagement  -Value 1
Set-Service -name WMSVC  -StartupType Automatic
Enable-NetFirewallRule -DisplayName "Windows Remote Management - Compatibility Mode (HTTP-In)"
Enable-WindowsOptionalFeature -Online -FeatureName IIS-BasicAuthentication
Enable-WindowsOptionalFeature -Online -FeatureName IIS-WindowsAuthentication
Enable-WindowsOptionalFeature -Online -FeatureName IIS-ASPNET45 -All
set-webconfiguration //security/authentication/windowsAuthentication MACHINE/WEBROOT/APPHOST -metadata overrideMode -value Allow
Set-WebConfigurationProperty -Filter "/system.webServer/security/authentication/windowsAuthentication" -Name Enabled -Value True -PSPath "IIS:\Sites\Default Web Site"
Start-service WMSVC
```

### Web Deploy (Deployment)

1. Download and install Web Platform Installer available at https://www.microsoft.com/web/downloads/platform.aspx
2. Run the Platform installer and select and install "Web Deploy 3.6 for Hosting Server"

### Tools for Visual Studio 2019 (Development)

1. Download and install the Tools from https://visualstudio.microsoft.com/thank-you-downloading-visual-studio/?sku=BuildTools&rel=16 
2. Install the following components
    1. MSBuild Tools (selected by default)
    2. .NET Framework 4.6.1 targeting pack
    3. WebDeploy

## Deploy
The following process must be executed to complete the deployment of the product

### Configure
The deployment package is available in $PROJECT_GIT_HOME/azadiam-repo/configuration-scripts/KPMG.Net-Utils/ folder. The directory consists of following files

|         File Name        |             Description                                                             |
|--------------------------|-------------------------------------------------------------------------------------|
| config/properties.txt	   | A property file. It holds the configuration parameters for script execution. Note: Before executing the script validate properties.txt file with relevant values |
| bin/Utils.ps1	           | A utility/common script with helper functions. It has the supporting functions that are used in deploy-tpmanager script. It'll be further expanded as more common functions are identified and developed.    |
| bin/deploy-tpmanager	   | An orchestration script to execute build and publish TPManager application to remote Windows Server IIS. It supports executions from a remote machine. |

Configure the properties.txt file in config/ directory as defined below

|      Property            |            Description                                                              |
|--------------------------|-------------------------------------------------------------------------------------|
| nuGetURL                 | URL to download nuget.exe 								 |
| nuGetPath	           | Path to download nuget.exe								 |
| msBuildPath	           | Path to MSBuild.exe								 |
| projectpath	           | Reference path for TPManager source						 |
| solutionname             | Reference path for TPManager solution (TPManager.sln) file.                         |
| projectname	           | Reference path for TPManager project (TPManager.csproj) file.                       |
| webConfig	           | Reference path for TPManager web.config file                                        |
| mysqlhost		   | Hostname of MySQLserver.								 |
| mysqlusername		   | Username for MySQL connection.							 |
| mysqlpassword	           | User's password for MySQL connection 						 |
| mysqlport		   | Port to be used to connect to MySQL.						 |
| mysqlDBname		   | Database name for initechdemo in MySQL.						 |


Update deployment details in TPManager\Properties\PublishProfiles\CustomProfile.pubxml
```
<SiteUrlToLaunchAfterPublish>http://172.16.14.35/TPManagerApp</SiteUrlToLaunchAfterPublish>
<MSDeployServiceURL>172.16.14.35</MSDeployServiceURL>
<DeployIisAppPath>Default Web Site\TPManagerApp</DeployIisAppPath>
<UserName>administrator</UserName>
<Password>Password123!</Password>
```

### Deploy
1. Start powershell and navigate to the following folder 
    ```
    cd $PROJECT_GIT_HOME\azadiam-repo\configuration-scripts\KPMG.Net-Utils\bin
    ```
2. Run the script
    ```
    $ .\deploy-tpmanager.ps1
    ```
3. Validate the application is running by navigating to http://<hostname>/TPManagerApp.

# References

1. How to implement windows authentication and authorization in ASP.NET
2. Integrated windows authentication
3. Publish an application to IIS by importing publish settings in Visual Studio
4. mysql Setup



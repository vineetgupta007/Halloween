package com.kpmg.advcyber.frontline.security;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.kpmg.advcyber.frontline.utils.Constants;

public class CustomUserDetailsService implements UserDetailsService {
	
	Logger logger = LoggerFactory.getLogger(CustomUserDetailsService.class);
	
	public UserDetails loadUserByUsername(String username)
	        throws UsernameNotFoundException, DataAccessException {
		logger.info("Entering loadUserByUsername");
		logger.debug("username recieved :: " + username);
		
		String userRole = "";				
		RequestAttributes attribs = RequestContextHolder.getRequestAttributes();
		if (RequestContextHolder.getRequestAttributes() != null) {
		    HttpServletRequest request = ((ServletRequestAttributes) attribs).getRequest();
		    userRole = request.getHeader(Constants.USERROLE);		    
		}
		
		logger.debug("role recieved :: " + userRole);
		
		ArrayList<GrantedAuthority> authoritiesList = new ArrayList<GrantedAuthority>();
		authoritiesList.add(new SimpleGrantedAuthority(Constants.ROLE_PREFIX+userRole.toUpperCase()));
				
		UserDetails user = new User(username, "password", authoritiesList);
		
		logger.info("Exiting loadUserByUsername");
		return user;
    }
}

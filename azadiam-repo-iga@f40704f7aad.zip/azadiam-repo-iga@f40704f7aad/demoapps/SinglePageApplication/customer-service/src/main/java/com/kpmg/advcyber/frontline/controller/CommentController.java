package com.kpmg.advcyber.frontline.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kpmg.advcyber.frontline.entity.Comment;
import com.kpmg.advcyber.frontline.entity.Data;
import com.kpmg.advcyber.frontline.repository.CommentRepository;

@RestController
@RequestMapping(path = "/comment")
public class CommentController {
	Logger logger = LoggerFactory.getLogger(CommentController.class);

	//private final UserRepository userRepository;
	private final CommentRepository commentRepository;

	@Autowired
	public CommentController(CommentRepository commentRepository) {
		this.commentRepository = commentRepository;
	}

	@GetMapping(value="/.search",
			produces = { "application/json"})
	// @CrossOrigin(origins = "https://frontlinemsal1-azureadidmdev.msappproxy.net")
	public ResponseEntity findComments(@RequestParam(value="customerId") Integer customerId ) {
		logger.info("Entering findComments");
		try {
			List<Comment> commentList = commentRepository.findByCustomerId(customerId);

			Data data = new Data();        
			data.setData(commentList);

			logger.info("Exiting findComments");
			return new ResponseEntity<Data>(data, HttpStatus.OK);
		} catch ( Exception ex ) {
			logger.error("Exception occurred: "+ex.getMessage(),ex);
			return new ResponseEntity(ex.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping
	// @CrossOrigin(origins = "https://frontlinemsal1-azureadidmdev.msappproxy.net")
	public ResponseEntity createComment( @RequestBody Comment comment ) {
		logger.info("Entering createComment");
		try {
			Comment createdComment = commentRepository.save(comment);

			Data data = new Data();        
			data.setData(createdComment);

			logger.info("Exiting createComment");
			return new ResponseEntity<Data>(data, HttpStatus.OK);    
		} catch ( Exception ex ) {
			logger.error("Exception occurred: "+ex.getMessage(),ex);
			return new ResponseEntity(ex.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}		
}

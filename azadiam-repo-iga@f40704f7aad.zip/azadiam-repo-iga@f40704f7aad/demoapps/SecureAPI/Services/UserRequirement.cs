﻿using Microsoft.AspNetCore.Authorization;

namespace SecureAPI.Services
{
    /// <summary>
    /// 
    /// </summary>
    public class UserRequirement : IAuthorizationRequirement
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="group"></param>
        public UserRequirement(string group)
        {
            AllowedGroup = group;
            //AllowedGroup2 = g2;
        }

        /// <summary>
        /// 
        /// </summary>
        protected string AllowedGroup { get; set; }

        //protected string AllowedGroup2 { get; set; }
    }
}
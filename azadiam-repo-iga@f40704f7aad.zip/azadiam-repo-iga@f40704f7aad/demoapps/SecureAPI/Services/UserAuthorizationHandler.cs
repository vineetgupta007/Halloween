﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace SecureAPI.Services
{
    public class UserAuthorizationHandler : AuthorizationHandler<UserRequirement>
    {
        /// <summary>
        /// 
        /// </summary>
        IHttpContextAccessor _httpContextAccessor = null;
        public IConfiguration Configuration { get; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        /// <param name="iConfig"></param>
        public UserAuthorizationHandler(IHttpContextAccessor httpContextAccessor, IConfiguration iConfig)
        {
            _httpContextAccessor = httpContextAccessor;
            Configuration = iConfig;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="requirement"></param>
        /// <returns></returns>
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, UserRequirement requirement)
        {
            string adminGroup = Configuration.GetValue<string>("Group:StandardAccess");
            string userGroup = Configuration.GetValue<string>("Group:AdminAccess");

            HttpContext httpContext = _httpContextAccessor.HttpContext;

            StringValues adminRole = "";
            StringValues userRole = "";

            httpContext.Request.Headers.TryGetValue("meroles", out userRole);
            if (!String.IsNullOrEmpty(userRole) && userRole == "AdminAccessValue" || userRole == "StandardAccessValue")
                context.Succeed(requirement);

            //else if (requirement.ToString() == "Admin")
            //{
            //    httpContext.Request.Headers.TryGetValue("meroles", out adminRole);
            //    if (!String.IsNullOrEmpty(adminRole) && userRole == adminGroup)
            //        context.Succeed(requirement);
            //}

            //if (!String.IsNullOrEmpty(userRole) || !String.IsNullOrEmpty(adminRole))
            //    context.Succeed(requirement);          

            return Task.FromResult(0);

        }
    }
}


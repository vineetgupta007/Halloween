﻿using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace SecureAPI.Models
{
    public class ProductQuery
    {
        /// <summary>
        /// 
        /// </summary>
        public AppDb Db { get; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="db"></param>
        public ProductQuery(AppDb db)
        {
            Db = db;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<Product> FindOneAsync(int id)
        {
            var cmd = Db.Connection.CreateCommand();
            cmd.CommandText = @"SELECT product_id, product_name,product_price FROM products WHERE product_id = @product_id";
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@product_id",
                DbType = DbType.Int32,
                Value = id,
            });
            var result = await ReadAllAsync(await cmd.ExecuteReaderAsync());
            return result.Count > 0 ? result[0] : null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<List<Product>> LatestPostsAsync()
        {
            var cmd = Db.Connection.CreateCommand();
            cmd.CommandText = @"SELECT product_id, product_name,product_price FROM products ORDER BY product_id";
            return await ReadAllAsync(await cmd.ExecuteReaderAsync());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task DeleteAllAsync()
        {
            var txn = await Db.Connection.BeginTransactionAsync();
            var cmd = Db.Connection.CreateCommand();
            cmd.CommandText = @"DELETE FROM 'Products'";
            await cmd.ExecuteNonQueryAsync();
            await txn.CommitAsync();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        private async Task<List<Product>> ReadAllAsync(DbDataReader reader)
        {
            var posts = new List<Product>();
            using (reader)
            {
                while (await reader.ReadAsync())
                {
                    var post = new Product(Db)
                    {
                        product_id = reader.GetInt32(0),
                        product_name = reader.GetString(1),
                        product_price = reader.GetDecimal(2),
                    };
                    posts.Add(post);
                }
            }
            return posts;
        }
    }
}

﻿using System.Data;
using System.Threading.Tasks;
using SecureAPI;
using MySql.Data.MySqlClient;

namespace SecureAPI.Models
{
    /// <summary>
    /// The main Product class
    /// Contains all methods for performing MySQL functions
    /// </summary>
    public class Product
    {
        public int product_id { get; set; }
        public string product_name { get; set; }
        public decimal product_price { get; set; }

        internal AppDb Db { get; set; }        

        public Product()
        {

        }

        internal Product(AppDb db)
        {
            Db = db;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task InsertAsync()
        {
            var cmd = Db.Connection.CreateCommand();
            cmd.CommandText = @"INSERT INTO products (product_id, product_name, product_price) VALUES (@product_id, @product_name, @product_price);";
            BindParams(cmd);
            BindId(cmd);
            await cmd.ExecuteNonQueryAsync();
            product_id = (int)cmd.LastInsertedId;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task UpdateAsync()
        {
            var cmd = Db.Connection.CreateCommand();
            cmd.CommandText = @"UPDATE products SET product_name = @product_name, product_price = @product_price WHERE product_id = @product_id;";
            BindParams(cmd);
            BindId(cmd);
            await cmd.ExecuteNonQueryAsync();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task DeleteAsync()
        {
            var cmd = Db.Connection.CreateCommand();
            cmd.CommandText = @"DELETE FROM products WHERE product_id = @product_id;";
            BindId(cmd);
            await cmd.ExecuteNonQueryAsync();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cmd"></param>
        private void BindId(MySqlCommand cmd)
        {
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@product_id",
                DbType = DbType.Int32,
                Value = product_id,
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cmd"></param>
        private void BindParams(MySqlCommand cmd)
        {
           
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@product_name",
                DbType = DbType.String,
                Value = product_name,
            });
            cmd.Parameters.Add(new MySqlParameter
            {
                ParameterName = "@product_price",
                DbType = DbType.Decimal,
                Value = product_price,
            });
        }
    }
}
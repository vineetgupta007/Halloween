﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Primitives;
using SecureAPI.Services;

namespace SecureAPI
{
    public class Startup
    {
        /// <summary>
        /// Variable declarations
        /// </summary>
        public string message = "";
        public StringValues role = "";

        /// <summary>
        /// Constructor with input parameter IConfiguration
        /// </summary>
        /// <param name="configuration"></param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. 
        // Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<AppDb>(_ => new AppDb(Configuration["ConnectionStrings:DefaultConnection"]));
            //services.AddAuthentication();

            //services.AddAuthentication();
            services.AddAuthorization(options =>
            {
                //options.AddPolicy("Admin",
                //    policy => policy.RequireClaim("AdminAccessValue"));

                //options.AddPolicy("Standard",
                //    policy => policy.RequireClaim("StandardAccessValue"));
                
                options.AddPolicy("Admin",
                    policy => policy.Requirements.Add(new AdminRequirement("Admin")));
                options.AddPolicy("Standard",
                    policy => policy.Requirements.Add(new UserRequirement("Standard")));
            });
            services.AddHttpContextAccessor();

            services.AddSingleton<IAuthorizationHandler, UserAuthorizationHandler>();
            services.AddSingleton<IAuthorizationHandler, AdminAuthorizationHandler>();

            services.AddControllers();


        }

        //This method gets called by the runtime. 
        //Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }

    }
}

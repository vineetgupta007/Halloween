This directory will store nuget.exe which will be downloaded at run time

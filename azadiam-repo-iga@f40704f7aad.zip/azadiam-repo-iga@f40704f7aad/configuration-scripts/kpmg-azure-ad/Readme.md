Module: kpmg-azure-ad
This module contains scripts associated with Azure Active Directory setup and configuration.

---

## Before you begin

## Configuration file

The script uses a common configuration file available in `$SCRIPTHOME\configuration-scripts\kpmg-azure-ad\config\config.json`.
The configuration file must be updated with appropriate configuration before running the script.

The configuration file consists of different configuration sets corresponding to each component of AzureAD, associated application proxy, users & groups and policy suite configuration.

---

------------------------------------------------------------
# Automation: Azure AD Application Proxy Connector Setup
------------------------------------------------------------
This module includes scripts to set up Azure AD Application Proxy Connector on remote server.
For remote server set up refer "Automation: Deployment on remote server" in this document.

## The Application Proxy installation script is designed to address below operations -

## Verify Pre-requisites
```
Verify AAD license, user role, remote server OS version, machine fqdn & dns, registry settings, outbound access to 80 & 443 ports, download & copy required binaries to remote server, validate if remote server has Application proxy connector already installed, verify if remote server has AAD Password Protection Proxy service
```
## Setup Application Proxy Connector
```
Install Application Proxy Connector on remote server and & Register it with AAD
```
## Validate Application Proxy Connector setup
```
Verify service status on remote server and connector status in AAD
```

---

# Azure Active Directory Application Proxy Setup :: Configuration file


***NOTE***

DO NOT change the value below config key in config.json's config key 'azuread-appproxy-config'

---

|     Parameter           |    Description    											|
|-------------------------|-------------------------------------------------------------|
| NameofAADFile			  |	Name of the exe file										|
| PortTestMSURL           |	Host name for testing the outbound port						|
| tlsv12				  |	Registry path to tlsv12 key									|
| dotnetfw				  |	Registry path to dot net framework key						|
| winhttp				  |	Registry path to winhttp key								|
| AADProxyPath			  | Path to application proxy exe                               |
| AADProgramPath		  | Path to Application Proxy Connector							|
| Services				  | Names of AAD Application Proxy Connector Services			|
| ServicesPPP			  | Names of AAD Password Protection Proxy Services				|
| OutboundPort			  | List of outbound ports required								|
| WinVersion			  | Windows version on required on remote server				|

---

The configuration contains the following parameters for the Application Proxy Connector Service setup:

|     Parameter          |Mandatory/Optional (Default Value) |    Description    								      										    |
|------------------------|-----------------------------------|--------------------------------------------------------------------------------------------------|
| AADConnector           | Mandatory                   		 | Machine FQDN name									  											|
| AADConnectorGroup      | Mandatory                   		 | Name of the connector group to which connector needs to be added 								|
| AADLicense        	 | Mandatory (AAD_PREMIUM_P2)  		 | Name of Azure AD License    							  											|
| ipAddress          	 | Mandatory 				  		 | IP Address of remote machine							  											|
| remoteusername      	 | Mandatory 				  		 | domain\\username for remote machine login  			  											|
| remotepassword       	 | Mandatory 				  		 | User password for remote machine login				  											|
| destinationPath      	 | Mandatory 				  		 | Path to executable on destination machine  		  						      			        |
| Waitconstant         	 | Mandatory (5)  					 | Sleep time in seconds between installation and register for azure ad application proxy connector |
| AADRole				 | Mandatory						 | Array of user assigned Role. User should have role with minimum permissions equivalent to Application Administrator Role or Company Administrator i.e. Global Administrator Role |

---
**NOTE**

Remove all the comments, if present, from the configuration file. These are indicated by `//` at the start of the line.

---

## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The domain controller setup script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-azure-ad\bin` folder
3. Run script
    ```powershell
    $ .\InstallAzureADAppProxy.ps1 -ConfigToLoad "azuread-appproxy-config" -AADAction "All"
    ```
    This will install and configure application proxy connector service on remote server, following which it will create the relevant connector and connector group in AzureAD.

### Examples
1. To setup application-proxy with Debug logs on console
    ```powershell
	$ .\InstallAzureADAppProxy.ps1 -ConfigToLoad "azuread-appproxy-config" -LogLevel "Debug" -AADAction "All"
	```
2. To setup application-proxy with Debug logs in file
    ```powershell
	$ .\InstallAzureADAppProxy.ps1 -ConfigToLoad "azuread-appproxy-config" -LogLevel "Debug" -Type "File" -FileName "CustomAADAPPPROXYLogger" -AADAction "All"
	```
3. To setup application-proxy with Warning logs on console
    ```powershell
	$ .\InstallAzureADAppProxy.ps1 -ConfigToLoad "azuread-appproxy-config" -LogLevel "Warn" -AADAction "All"
	```
4. To check pre-requisite for application-proxy with Debug logs in file
    ```powershell
	$ .\InstallAzureADAppProxy.ps1 -ConfigToLoad "azuread-appproxy-config" -LogLevel "Debug" -Type "File" -FileName "CustomAADAPPPROXYLogger" -AADAction "PreCheck"
	```
5. To setup application-proxy with Debug logs in file
    ```powershell
	$ .\InstallAzureADAppProxy.ps1 -ConfigToLoad "azuread-appproxy-config" -LogLevel "Debug" -Type "File" -FileName "CustomAADAPPPROXYLogger" -AADAction "Setup"
	```
6. To validate application-proxy set up with Debug logs in file
    ```powershell
	$ .\InstallAzureADAppProxy.ps1 -ConfigToLoad "azuread-appproxy-config" -LogLevel "Debug" -Type "File" -FileName "CustomAADAPPPROXYLogger" -AADAction "Validate"
	```
	
---

-------------------------------------------------------------------
# Automation: Azure Conditional Access Policy 
-------------------------------------------------------------------
This module includes scripts to create conditional access policies

---

# Azure Conditional Access Policy  :: Configuration file

***NOTE***

DO NOT change the values of below config key in config.json's config key 'conditional-policy' under 'azure-conditional-policy':

|     Parameter           |Mandatory/Optional (Default Value)|    Description    										   |
|-------------------------|----------------------------------|-------------------------------------------------------------|
| policyTemplateName	  |Mandatory                         | Name of conditional-policy template                         | 
| csvFileName			  |Mandatory						 | Name of CSV File								               |
| jsonPath                |Mandatory						 | Location of Policy Templates								   |	
| csvPath				  |Mandatory						 | Location of CSV File                                        |
| AADLicense              |Mandatory						 | Name of AzureAD License                                     |
| AADRole				  |Mandatory						 | Array of user assigned Roles. User should have role with    |
|                         |                                  | minimum permissions equivalent to "Security Administrator", |
|                         |                                  | "Company Administrator","Conditional Access administrator"  |


DO NOT change the values of below config key in config.json's config key 'conditional-policy-parameters' under 'azure-conditional-policy':

|     Parameter           |Mandatory/Optional (Default Value)|    Description    										     |
|-------------------------|----------------------------------|---------------------------------------------------------------|
| isBulkLoad 	          |Mandatory                         | Toggle button. To create policies in bulk set this key to     |
|                         |                                  | "Yes", else set it as "No" to create a single Policy          |  
| builtInControls		  |Mandatory						 | List of allowed values available to be configured for this key|
| RiskLevels              |Mandatory						 | List of allowed values available to be configured for this key|	
| SigninRiskLevels		  |Mandatory						 | List of allowed values available to be configured for this key|                                       
| clientAppTypes          |Mandatory						 | List of allowed values available to be configured for this key|                                    
| Platforms				  |Mandatory						 | List of allowed values available to be configured for this key|
| DeviceStates            |Mandatory                         | List of allowed values available to be configured for this key|
| signInFrequency         |Mandatory                         | List of allowed values available to be configured for this key|
| cloudAppSecurityType	  |Mandatory						 | List of allowed values available to be configured for this key|
| includeUserActions      |Mandatory						 | List of allowed value available to be configured for this key |
| mandatory		          |Mandatory						 | List of mandatory key attributes 							 |


DO NOT change the values of below config key in config.json's config key 'policy-graph-properties' under 'azure-conditional-policy'

|     Parameter          |Mandatory/Optional (Default Value) |    Description                                     |
|------------------------|-----------------------------------|----------------------------------------------------|
| grant_Type		     | Mandatory                         |Type of credential to be provided for graph API call|    														
| scope		             | Mandatory                   		 |It requests a token with the scopes on Microsoft    |
|                        |                                   |Graph that the application has registered for in the| 
|					     |									 |Azure portal   									  |					 
| clientId               | Mandatory                   		 |Client ID of app in Azure AD                        |    														
| clientSecret           | Mandatory                   		 |Client secret of app in AZ AD                       | 															 
| tenantName        	 | Mandatory                		 |TenantID of AZAD Subscription                       |
| getAPI				 | Mandatory					     |API to get the conditional access policy            |
| getLocAPI              | Mandatory                         |API to get the named location ID                    |
| postAPI				 | Mandatory					     | API to create the conditional access policy        |


Parameter Allowed Values Table -
Mandatory/Optional config key in config.json's config key 'conditional-policy-config' under 'azure-conditional-policy'

|     Parameter          |Mandatory/Optional|    Description                          | Allowed Values                                                                             |
|------------------------|------------------|---------------------------------------- |--------------------------------------------------------------------------------------------|
| displayName            | Mandatory        |Display name of policy                   | Any text in plain English
| state        	         | Mandatory        |Enable policy state                      | enabled / disabled / enabledForReportingButNotEnforced
| userRiskLevels	     | Optional         |Configure user risk levels needed for    | high + medium + low
|                        |                  |policy to be enforced.                   |    														 
| signInRiskLevels       | Optional         |Likelihood that the sign-in is coming    | high + medium + low + none
|                        |                  |from someone other than the user.        |
|                        |                  |Risk level can be high, medium or low.   |
|						 |					|**Requires Azure AD Premium 2 license.** |   
| clientAppTypes	     | Mandatory        |Software the user is employing to access | exchangeActiveSync + browser + mobileAppsAndDesktopClients + other
|                        |                  |the cloud app. For example, 'Browser'    | 
| includePlatforms       | Optional         |Platform the user is signing in from.    | all / android + iOS + windows + windowsPhone + macOS
| excludePlatforms       | Optional         |Platform to be excluded                  | android + iOS + windows + windowsPhone + macOS
| includeLocations       | Optional         |Location the user is signing in from.    | All / AllTrusted / <Named Location Name>
| excludeLocations	     | Optional         |Location to be excluded from signing in. | AllTrusted / <Named Location Name> 
| includeDeviceStates	 | Optional         |Device the user is signing in from.      | All   														 
| excludeDeviceStates    | Optional         |Device to be excluded                    | Compliant + DomainJoined 
| includeApplications	 | Mandatory        |Apps to be included in policy            | None / All / <app Names> Eg.tppartner
| excludeApplications    | Optional         |Apps to be excluded in policy            | <app Names> 
| includeGroups        	 | Optional         |Groups in the directory that the policy  | <Group Names>
|                        |                  |applies to.                              | 
| excludeGroups          | Optional         |Groups to be excluded from the policy    | <Group Names>
| includeRoles	         | Optional         |Roles in the directory that the policy   | <Role Names>
|                        |                  |applies to.	                          |										
| excludeRoles	         | Optional         |Roles to be excluded from the policy     | <Role Names> 											            
| includeUserActions	 | Mandatory        |Register security information            | urn:user:registersecurityinfo   														 
| includeUsers           | Mandatory        |Users to be included in policy           | GuestsOrExternalUsers + UPN / All/ None
|  						 |					|			                              | (*UPN - User Principal Name )	
| excludeUsers           | Optional         |Users to be included in policy           | GuestsOrExternalUsers + UPN 
| builtInControls	     | Mandatory        |Block access or select additional require| block/ mfa + compliantDevice + domainJoinedDevice + approvedApplication + compliantApplication
|                        |                  |ments which need to be satisfied to allow| 
|						 |					|access.                                  |														 
| signInFrequency        | Optional         |Time period before asked to sign-in again| 0 is invalid. Any value between 1 and 2
| cloudAppSecurityType   | Optional         |This control works for various cloud apps| mcasConfigured / monitorOnly / blockDownloads
| signInFrequency type   | Optional         |Time period before user asked to sign-in | hours / days
|                        |                  |again.                                   | 															                           
|------------------------|------------------|-----------------------------------------|--------------------------------------------------------------------------------------------|


*FAQs -
How configuration key values needs to be updated in config.json's config key 'conditional-policy-config' ?
1) isBulkLoad:
				"Yes" => For Bulk Policy creation, reads configuration key values from CSV file line by line
			    "No"  => For Single Policy creation, reads configuration key values from config.json file

2) Use pipe character '|' to provide multiple values in configuration keys:
   - For updating the key values in config.json’s file, enclosed the values is double quotes ("")
   - For updating the key values of policy in CSV file, directly provide the values.
     
	 Examples for multi-valued input : 
    "excludeGroups": "All Company|DirectoryAdmin"  => in config.json’s file
	 excludeGroups : All Company|DirectoryAdmin  => in CSV file
	 
	 Example For single value input-
	 "excludeGroups": "DirectoryAdmin" => in config.json’s file
	  excludeGroups : DirectoryAdmin => in CSV file
	 
	 Example For empty input value -
	 "excludeGroups": ""   => in config.json’s file
      excludeGroups :      => leave it blank in CSV file

3) Use semi-colon (;) to separate the configuration values for below keys:  
   a) platforms 
		Syntax-    platforms :  <includePlatforms;excludePlatforms> 
		Example - 
		   "platforms" : "windows;android|iOS"  => in config.json’s file
			platforms  :  windows;android|iOS   => in CSV file	
			
   b) locations
		Syntax-    locations :  <includeLocations;excludeLocations> 
		Example -
		   "locations" : "Atlanta Lab|US;KPMG USA"  => in config.json’s file
			locations  :  Atlanta Lab|US;KPMG USA   => in CSV file  
			
   c) devices 
		Syntax-    devices :  <includeDeviceStates;excludeDeviceStates>
		Example -
		   "devices" : "All;Compliant|DomainJoined"  => in config.json’s file
			devices	 :	All;Compliant|DomainJoined   => in CSV file
			
   d) sessionControls 
		Syntax-    sessionControls :  <cloudAppSecurityType;signInFrequency;signInFrequencyType>   
		Example -
		   "sessionControls" : "mcasConfigured;3;days"  => in config.json’s file
			sessionControls	 :	mcasConfigured;3;days   => in CSV file
   	    

**NOTE**

1) Don't alter the configuration key parameters names. Just key in the allowed configuration values based on type of file - CSV/JSON
2) Mandatory values are required to create a policy
3) In 'Parameter Allowed Values Table' => '/' indicates only one of those values are allowed
   In 'Parameter Allowed Values Table  => '+' indicates combination of those values are allowed 
4) Don't provide value for both the configuration keys - 'includeApplications' and 'includeUserActions'. Only one value is allowed
5) MAM policy(builtin-controls: "approvedApplication" / "compliantApplication") can only be applied to Android or iOS client platforms
6) These Allowed values are *CASE-SENSITIVE* 

## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The azure policy suite script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-azure-ad\bin` folder
3. Run script

### Examples
 1. To Execute the script to create conditional access policy in AZ AD
	```powershell
	$ .\CreateConditionalPolicy.ps1 -ConfigFile "config.json" -ConfigToLoad "azure-conditional-policy" -LogLevel "Debug" -Type "File" -FileName "conditionalpolicyLogger"
	```
	
---
	
------------------------------------------------------------
# Automation: ECMA Connector Setup
------------------------------------------------------------
This module includes scripts to set up ECMA connector on remote server.
For remote server set up refer "Automation: Deployment on remote server" in this document.

## The AzureAD ECMA Connector Host installation script is designed to address below operations -

## Verify Pre-requisites
```
Verify AAD license, remote server RAM, remote server OS version, remote server .Net framework
```
## Install AzureAD ECMA Connector Host
```
Install AzureAD ECMA Connector Host on remote server
```
## Validate AzureAD ECMA Connector Host
```
Verify service status of AzureAD ECMA Connector Host on remote server
```

---

# AzureAD ECMA Connector Host Installation :: Configuration file

***NOTE***

DO NOT change the value below config key in config.json's config key 'install-ecma-config'

---

|     Parameter           |    Description    											|
|-------------------------|-------------------------------------------------------------|
| type					  |	Type of credentials											| 
| applicationname		  |	Name of the ECMA connector host service						| 
| ECMAfilename			  |	Name of the msi file										|

---

The configuration contains the following parameters for the installation of Azure AD ECMA Connector Host:

|     Parameter          |Mandatory/Optional (Default Value) |    Description    								      										    |
|------------------------|-----------------------------------|--------------------------------------------------------------------------------------------------|
| username		         | Mandatory                   		 | Username to be used to connect to Azure AD		  												|
| password		         | Mandatory                   		 | Password for user     								  											|
| AADLicense        	 | Mandatory (AAD_PREMIUM_P2)  		 | Name of Azure AD License    							  											|
| ipAddress          	 | Mandatory 				  		 | IP Address of remote machine							  											|
| remoteusername      	 | Mandatory 				  		 | domain\username for remote machine login  			  											|
| remotepassword       	 | Mandatory 				  		 | User password for remote machine login				  											|
| destinationPath      	 | Mandatory 				  		 | Path to executable on destination machine  		  						      			        |
| windowsversion       	 | Mandatory	  					 | Windows server version required 																	|
| windowsram			 | Mandatory						 | Minimum physical RAM required in GB																|
| netframework			 | Mandatory						 | Minimum .NET framework required in release version												|
| localfilepath			 | Mandatory						 | File path for msi file on local server															|

---
**NOTE**

Remove all the comments, if present, from the configuration file. These are indicated by `//` at the start of the line.

---

## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The ECMA connector setup script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-azure-ad\bin` folder
3. Run script
    ```powershell
    $ .\InstallECMA.ps1 -ConfigToLoad "install-ecma-config"
    ```
    This will install Azure AD ECMA Connector Host on remote server.

### Examples
1. To install Azure AD ECMA Connector Host with Debug logs on console
    ```powershell
	$ .\InstallECMA.ps1 -ConfigToLoad "install-ecma-config" -LogLevel "Debug"
	```
2. To install Azure AD ECMA Connector Host with Debug logs in file
    ```powershell
	$ .\InstallECMA.ps1 -ConfigToLoad "install-ecma-config" -LogLevel "Debug" -Type "File" -FileName "ECMAInstallLogger"
	```
3. To install Azure AD ECMA Connector Host with Warning logs on console
    ```powershell
	$ .\InstallECMA.ps1 -ConfigToLoad "install-ecma-config" -LogLevel "Warn"
	```
4. To check pre-requisite for Azure AD ECMA Connector Host with Debug logs in file
    ```powershell
	$ .\InstallECMA.ps1 -ConfigToLoad "install-ecma-config" -LogLevel "Debug" -Type "File" -FileName "ECMAInstallLogger" -ECMAAction "PreCheck" 
	```
5. To install Azure AD ECMA Connector Host with Debug logs in file
    ```powershell
	$ .\InstallECMA.ps1 -ConfigToLoad "install-ecma-config" -LogLevel "Debug" -Type "File" -FileName "ECMAInstallLogger" -ECMAAction "Install"
	```
6. To validate Azure AD ECMA Connector Host installation with Debug logs in file
    ```powershell
	$ .\InstallECMA.ps1 -ConfigToLoad "install-ecma-config" -LogLevel "Debug" -Type "File" -FileName "ECMAInstallLogger" -ECMAAction "Validate"
	```

---
	
------------------------------------------------------------
# Automation: Azure Dashboard and Reporting
------------------------------------------------------------
This module contains scripts associated with Dashboard Pre-Requisite check, and if not exist then create it.
Additionally, this script is setting up the Azure Active Directory(AAD) diagnostic setting for sending the Sign-in and Audit logs to Log Analytics Workspace(LAWS) so that KQL can be written on to it to get the graph for identified KPIs.
Also, this script posting the logs from AAD to LAWS to create the custom table so that KQL can be written on to it to get the graph for identified KPIs.

## Azure Dashboard and Reporting :: Configuration file

***NOTE***

- DO NOT change the value below config key in config.json's config key 'azure-dashboard-config'

|     Parameter           |    Description    											|
|-------------------------|-------------------------------------------------------------|
| urial					  |	Graph API url to get Application List    					|
| psGroup				  |	PowerShell Azure API to fetch All Azure AD Groups			|
| psGroupType			  |	PowerShell Azure API to fetch All Azure AD Groups with type	|
| psRoleAssign			  |	PowerShell Azure API to fetch All Azure AD Role Details   	|
| psUser    			  |	PowerShell Azure API to fetch All Azure AD users       		|
| psGroupMember 		  |	PowerShell Azure API to fetch Group Members       			|
| psUserManager 		  |	PowerShell Azure API to fetch User Manager       			|
| type					  |	Type of credentials											| 
| grantType				  |	Type of credentials to access graph api						| 

The configuration contains the following parameters for the Application Proxy Connector Service setup:

|     Parameter          |Mandatory/Optional (Default Value) |    Description    							                                        |
|------------------------|-----------------------------------|--------------------------------------------------------------------------------------|
| resourceGroupName		 |	Mandatory       				 | Name of resource group to load log analytics                                         |
| createResource		 |	Mandatory       				 | Flag for creating new resourec group and workspace e.g. value should be true or false|
| WorkspaceName		     |	Mandatory       				 | Name of workspace to load log analytics          									|
| workbookName		     |	Mandatory       				 | Name of workbook to load KPIs to log analytics    									|
| DashboardName		     |	Mandatory       				 | Name of Dashboard to load all the custom graphs									|
| username		         |  Mandatory                   	 | Username to be used for app proxy registration		  								|
| password		         |  Mandatory                   	 | Password for user     								  								|
| clientId               |  Mandatory                   	 | Client ID of app in Azure AD 														|
| clientSecret           |  Mandatory                   	 | Client Secret of app in Azure AD 													|
| tenantId               |  Mandatory                   	 | Tenant ID of an Azure AD Instance 													|
| logTypeGM              |  Mandatory                   	 | Logs table name to load all group membership data into log analytics					|
| logTypeAL              |  Mandatory                   	 | Logs table name to load all application list data into log analytics					|
| logTypeAllGrp          |  Mandatory                        | Logs table name to load all Azure AD group data into log analytics					|
| logTypeAllUsers        |  Mandatory                   	 | Logs table name to load all user data into log analytics								|
| logTypeRoleAssignment  |  Mandatory                   	 | Logs table name to load all role assigned data into log analytics					|
| logTypeUsersManager    |  Mandatory                   	 | Logs table name to all users with or without manager data into log analytics			|
| logTypeAllGrpType      |  Mandatory                   	 | Logs table name to load all groups with type data into log analytics					|
| ruleName               | Mandatory                         | Name of the diagnostic rule															|
| resourceGroupLocation | Mandatory						 | Location to create resource groups     |
| workspaceLocation | Mandatory						 | Location to create log analytics workspace     |

## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The dashboard and reporting script for log analytics in azure can be executed as follows:
1. Start PowerShell
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-azure-ad\bin` folder
3. Run script
   ```powershell
   $ .\CreateDashboard.ps1 -ConfigFile "config.json" -ConfigToLoad "azure-dashboard-config" -LogLevel "Debug" -Type "File" -FileName "CustomADLogger"
   ```
   
### Examples
1. To setup dashboard pre-req and post logs LAWS with logs
	```powershell
    $ .\CreateDashboard.ps1 -ConfigFile "config.json" -ConfigToLoad "azure-dashboard-config" -LogLevel "Debug"
	```
2. To setup specific forest with Debug logs in file
    ```powershell
    $ .\CreateDashboard.ps1 -ConfigFile "config.json" -ConfigToLoad "azure-dashboard-config" -LogLevel "Debug"
      -Type "File" -FileName "CustomADLogger"
	```

### Manual steps

Once the Dashboard creation is successfully completed. 
Please login to Azure Portal -> Search Log Analytics workspace -> Click on $WorkspaceName -> Go to Workspace Data Sources ->  Select Azure Activity log -> Click on Log Analytics Connection 'Disconnected' -> Click Connect"

---

------------------------------------------------------------
# Automation: Validate Cloud Provisioning Agent Setup
------------------------------------------------------------
This module contains the script to automate the pre-requisites and post-installation steps for Azure AD Cloud provisioning agent server.

## The ValidateCloudProvAgent script is designed to address below operations -

## Pre-Requisites Validation for Agent Installation
```
Check server OS version and .NET version. Set correct PowerShell execution policy scope. Check firewall for connectivity with  hosts "login.windows.net,login.microsoftonline.com,mscrl.microsoft.com,crl.microsoft.com,ocsp.msocsp.com,www.microsoft.com". Create required windows registry.
```
## Post-Installation Validation
```
Check that AzureADConnectAgentUpdater and AADConnectProvisioningAgent services are installed. Start the services if not running. Restart the server on successful validation.
```
---

# ValidateCloudProvAgent script setup :: Configuration file
The cloud provisioning agent validation configuration is available in config.json file under 'aad-provagent-config' key.
The configuration should not be edited as the default values are sufficient for validation.

---

## Execute Script
Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The validation automation script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-azure-ad\bin` folder
3. Run script
    ```powershell
    $ .\ValidateCloudProvAgent.ps1 <PreReq or PostInstall> -ConfigToLoad "aad-provagent-config"
    ```
---

### Examples
1. To perform pre-requisites validation
    ```powershell
	$ .\ValidateCloudProvAgent.ps1 "PreReq" -ConfigToLoad "aad-provagent-config"
	```
2. To perform post installation validation
    ```powershell
	$ .\ValidateCloudProvAgent.ps1 "PostInstall" -ConfigToLoad "aad-provagent-config"
	```
---
	
------------------------------------------------------------
# Automation: Guest Invitations to Azure AD Tenant
------------------------------------------------------------
This module contains the script to automate Azure AD invitations to Guest users.

## The AzureAD Guest Invitation script is designed to address below operations -

## Pull users from on-premise Active Directory
```
Connect to AD as Domain Admin. Search for users based on AD Filter or Group Membership. All AD users will be in-scope if no search Criteria is configured.
```
## Create invitation for Azure AD guests
```
Check if guest user/invitation already exists in Azure AD. If not, then create a new guest invitation for user.
```
---

# Guest invitation script setup :: Configuration file

The guest invitation configuration is available in config.json file under 'invite-guests-config' key.
The configuration contains the following parameters to run the automation script:

|     Parameter          |Mandatory/Optional (Default Value) |    Description    								      										    |
|------------------------|-----------------------------------|--------------------------------------------------------------------------------------------------|
| domain		         | Mandatory                   		 | Fully qualified on-premise AD domain name		  												|
| domainAdminUser        | Mandatory                   		 | AD domain administrator's username       			  											|
| domainAdminPassword  	 | Mandatory                		 | Password for AD domain administrator user			  											|
| clientId          	 | Mandatory 				  		 | Client ID for the Azure AD service principal used for Azure REST API calls   					|
| clientSecret      	 | Mandatory 				  		 | Client Secret for the Azure AD service principal used for Azure REST API calls   				|
| tenantId          	 | Mandatory 				  		 | Azure AD Tenant Id                                                                               |
| inviteRedirectUrl    	 | Mandatory 				  		 | Landing application url for guests after they accept the invitation                              |
| sendInvitationMessage	 | Mandatory	  					 | Boolean flag to control the invitation email to guests                                           |
| customizedMessageBody	 | Optional 						 | Custom guest welcome message     																|
| adUserAttributes		 | Mandatory						 | AD attributes to include in AD users search. MUST have displayName,samaccountname, and mail		|
| searchCriteria:type	 | Optional 						 | Search criteria type for AD users. Supported types: 'group' and 'filter'							|
| searchCriteria:value	 | Optional 						 | Search criteria value based on type in field above. Group name or valid AD Filter.               |

### search Criteria Examples
1. To invite guests with a specific AD group membership:
        "searchCriteria":{
            "type":"group",
            "value":"<Group's samaccountname>"
        }
2. To invite guests with a valid AD Filter:
        "searchCriteria":{
            "type":"filter",
            "value":"<valid AD Filter without enclosing curly braces {}>"
        }
	For more details on AD Filters, refer to https://docs.microsoft.com/en-us/powershell/module/addsadministration/get-aduser
3. To invite all AD users as guests, do not include searchCriteria in configuration. Behavior is same even if you configure empty searchCriteria.
        "searchCriteria":{}

---
**NOTE**

Remove all the comments, if present, from the configuration file. These are indicated by `//` at the start of the line.

---

## Execute Script

---
**NOTE**

The guest invitation script can be executed from the domain controller servers or a domain joined client as long as Get-ADUser command is available.

---

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The guest invitation automation script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-azure-ad\bin` folder
3. Run script
    ```powershell
    $ .\InviteGuestsInAzureAD.ps1.ps1 -ConfigToLoad "invite-guests-config"
    ```
    This will create guest invites for on-premise AD users that are in-scope of configured searchCriteria in config.json file.

### Examples
1. To invite guests with Debug logs on console
    ```powershell
	$ .\InviteGuestsInAzureAD.ps1.ps1 -ConfigToLoad "invite-guests-config" -LogLevel "Debug"
	```
2. To invite guests with Debug logs in file
    ```powershell
	$ .\InviteGuestsInAzureAD.ps1.ps1 -ConfigToLoad "invite-guests-config" -LogLevel "Debug" -Type "File" -FileName "GuestInvitationsLogger"
	```
3. To invite guests with Warning logs on console
    ```powershell
	$ .\InviteGuestsInAzureAD.ps1.ps1 -ConfigToLoad "invite-guests-config" -LogLevel "Warn"
	```
---

------------------------------------------------------------
# Automation: Register Custom Domain
------------------------------------------------------------
This module includes scripts to create custom domain in Azure AD

---

# Azure AD Register Custom Domain :: Configuration file

***NOTE***

Parameter Allowed Values Table -
Mandatory config key in config.json's config key 'custom-domain-register'

|     Parameter  |Mandatory/Optional|    Description                                      | Allowed Values 				 |
|----------------|------------------|-----------------------------------------------------|------------------------------|
| customDomain   | Mandatory        | Name of the custom domain to be created in Azure AD |	Any text in plain English    |
| AADRole		 | Mandatory		| Array of user assigned Roles 						  | Default value. Do not change |
| AADLicense	 | Mandatory        | Name of AzureAD License							  | Default value. Do not change |

**NOTE**

*1) Don't alter the configuration template. Just key in the config values
2) Mandatory values need to be provided to create a custom domain

---

## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The custom domain creation script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-azure-ad\bin` folder
3. Run script
    ```powershell
    $ .\RegisterCustomDomain.ps1 -ConfigToLoad "azure-ad-config"
    ```
This script will create custom domain in Azure AD.

    ### Examples
1. To create custom domain with Debug logs on console
    ```powershell
	$ .\RegisterCustomDomain.ps1 -ConfigToLoad "azure-ad-config" -LogLevel "Debug"
	```
2. To create custom domain with Debug logs on console
    ```powershell
	$ .\RegisterCustomDomain.ps1 -ConfigToLoad "azure-ad-config" -LogLevel "Debug" -Type "File" -FileName "CustomAZDomainLogger"
	```
3. To create custom domain with Debug logs on console
    ```powershell
	$ .\RegisterCustomDomain.ps1 -ConfigToLoad "azure-ad-config" -LogLevel "Warn"
	```

---

------------------------------------------------------------
# Automation: Group Management
------------------------------------------------------------
This module includes scripts for group management (create dynamic groups/create azure ad groups)

---

# Azure AD Dynamic Groups :: Configuration file

***NOTE***

DO NOT change the value below config key in config.json's config key 'group-management'

Parameter Allowed Values Table -
The configuration contains the following parameters for the Azure login:

Mandatory config key in config.json's config key 'create-dynamic-group'

|     Parameter                       							|Mandatory/Optional						|    Description                                   					| Allowed Values				|
|---------------------------------------------------------------|---------------------------------------|-------------------------------------------------------------------|-------------------------------|
| isBulkLoad						  							| Mandatory								| Flag to check whether groups should be created in bulk 			| true/false					|
| isDynamicGroup												| Mandatory								| Flag to check whether group(s) getting created are dynamic groups | true/false					|
| AADRole														| Mandatory								| Array of user assigned Roles 					   					| Default value. Do not change	|
| AADLicense													| Mandatory								| Name of AzureAD License 						   					| Default value. Do not change	|
| group-definition->displayName									| Mandatory is isDynamicGroup is false	| Specifies a display name for the group 		   					| Any text in plain English		|
| group-definition->description									| Mandatory is isDynamicGroup is false	| Specifies a description for the group 		   					| Any text in plain English		|
| group-definition->mailEnabled									| Mandatory is isDynamicGroup is false	| Specifies whether this group is mail enabled     					| true/false					|
| group-definition->securityEnabled								| Mandatory is isDynamicGroup is false	| Specifies whether the group is security enabled  					| true/false					|
| group-definition->mailNickName								| Mandatory is isDynamicGroup is false	| Specifies a mail nickname for the group 		   					| Any text in plain English		|
| dynamic-group-definition->dymgrp_displayName                  | Mandatory is isDynamicGroup is true   | Specifies a display name for the group           					| Any text in plain English		|
| dynamic-group-definition->dymgrp_description                  | Mandatory is isDynamicGroup is true   | Specifies a description for the group            					| Any text in plain English		|
| dynamic-group-definition->dymgrp_MailEnabled                  | Mandatory is isDynamicGroup is true   | Specifies whether this group is mail enabled     					| true/false					|
| dynamic-group-definition->dymgrp_MailNickName                 | Mandatory is isDynamicGroup is true   | Specifies a mail nickname for the group          					| Any text in plain English		|
| dynamic-group-definition->dymgrp_SecurityEnabled              | Mandatory is isDynamicGroup is true   | Specifies whether the group is security enabled  					| true/false					|
| dynamic-group-definition->dymgrp_GroupTypes                   | Mandatory is isDynamicGroup is true   | Specifies group type      					   					| Default value. Do not change	|
| dynamic-group-definition->dymgrp_membershipRule               | Mandatory is isDynamicGroup is true   | Specifies the membership rule for a dynamic group					| Membership Rule				|
| dynamic-group-definition->dymgrp_membershipRuleProcessingState| Mandatory is isDynamicGroup is true   | Specifies the rule processing state              					| On/Off						|

**NOTE**

*1) Don't alter the configuration template. Just key in the config values
2) Mandatory values need to be provided to create a dynamic group
3) Do not change any default values

---

## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The dynamic group creation script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-azure-ad\bin` folder
3. Run script
    ```powershell
    $ .\GroupManagement.ps1 -ConfigToLoad "group-management"
    ```
This script will create dynamic group in Azure AD.

    ### Examples
1. To create custom domain with Debug logs on console
    ```powershell
	$ .\GroupManagement.ps1 -ConfigToLoad "group-management" -LogLevel "Debug"
	```
2. To create custom domain with Debug logs on console
    ```powershell
	$ .\GroupManagement.ps1 -ConfigToLoad "group-management" -LogLevel "Debug" -Type "File" -FileName "CustomAZGrpLogger"
	```
3. To create custom domain with Debug logs on console
    ```powershell
	$ .\GroupManagement.ps1 -ConfigToLoad "group-management" -LogLevel "Warn"
	```
---

------------------------------------------------------------
# Automation: Deployment on remote server
------------------------------------------------------------
Below is the pre-requisite which needs to be configured on server to perform remote server deployment of the component.
```
From the list of above modules below script execution will need it as pre-requisite before execution of scripts.
1. Automation: Azure AD Application Proxy Connector Setup
2. Automation: ECMA Connector Setup
```

### Enable Windows RM (Server)

The scripts leverage WindowsRM capability to install and configure the domain controllers. Before starting the installation
and configuration process, the WindowsRM must be enabled and configured on both the Windows server and powershell client
being used to invoke the script.

The following script with appropriate configuration for the machine can be used to configure the remote access
```
$LocalIPAddress = '<IP address of client machine e.g. 172.16.251.4>'
Enable-PSRemoting -Force;
Set-Item WSMan:\localhost\Client\TrustedHosts -Concatenate -Value '$LocalIPAddress' -Force;
Get-Item WSMan:\localhost\Client\TrustedHosts;
winrm quickconfig -quiet;
Restart-Service WinRM;
```

## Enable Windows RM (Client)

In case Trusted Host is being used for authentication, the same must be enabled on the local machine before running the script.
```
$ServerIPAddress = '<IP Address of server>'
Set-Item WSMan:\localhost\Client\TrustedHosts -Concatenate -Value '$ServerIPAddress' -Force;
```

-------------------------------------------------------------------
# Automation: Access Package 
-------------------------------------------------------------------
This module includes scripts to create catalog, access package, access policy, add resource to catalog and add resource scope

---
# Azure Access Package  :: Configuration file

***NOTE***
DO NOT change the values of below config key in config.json's config key 'access-pkg-management':

|     Parameter           |Mandatory/Optional (Default Value)|    Description    										   |
|-------------------------|----------------------------------|-------------------------------------------------------------|
| catalog-definition	  |Mandatory                         | Catalog creation properties		                           | 
| package-definition	  |Mandatory						 | Access Package and access policy properties	               |
| resource-definition     |Mandatory						 | Properties to add resource to catalog					   |	
| resource-role-definition|Mandatory						 | Properties to add resource role scope                       |
| AADLicense              |Mandatory						 | Name of AzureAD License                                     |
| AADRole				  |Mandatory						 | Array of user assigned Roles. User should have role with    |
|                         |                                  | minimum permissions equivalent to "Security Administrator", |
|                         |                                  | "Company Administrator","Conditional Access administrator"  |


Parameter Allowed Values Table -
Mandatory/Optional config key in config.json's config key 'catalog-definition' under 'access-pkg-management'

|     Parameter          	 |Mandatory/Optional|    Description                          		| Allowed Values                         |
|----------------------------|------------------|-----------------------------------------------|----------------------------------------|
| create-catalog         	 | Mandatory        |Flag to check whether catalog should be created| true/false
| access-pkg-catalog-rest-api| Mandatory        |REST API call for catalog operations 			| Default value: Please do not update

Mandatory/Optional config key in config.json's config key 'catalog-config' under 'catalog-definition'. This configuration is mandatory is catalog creation step should be executed

|     Parameter          	 |Mandatory/Optional|    Description                          													 | Allowed Values                         |
|----------------------------|------------------|--------------------------------------------------------------------------------------------|----------------------------------------|
| catalog-name         	 	 | Mandatory        |The display name of the access package catalog 											 | Any text in plain English
| description                | Mandatory        |The description of the access package catalog 												 | Any text in plain English
| isExternallyVisible        | Mandatory		|Whether the access packages in this catalog can be requested by users outside of the tenant | true/false

Mandatory/Optional config key in config.json's config key 'package-definition' under 'access-pkg-management'

|     Parameter          	 |Mandatory/Optional|    Description                          		              | Allowed Values                         |
|----------------------------|------------------|-------------------------------------------------------------|----------------------------------------|
| access-pkg-ops         	 | Mandatory        |Flag to check whether package ooperations should be executed | true/false
| access-pkg-rest-api		 | Mandatory        |REST API call for access package operations				  | Default value: Please do not update
| access-policy-rest-api	 | Mandatory		|REST API call for access policy operations					  | Default value: Please do not update

Mandatory/Optional config key in config.json's config key 'access-package-config' under 'package-definition'. This configuration is mandatory if access package operations should be executed

|     Parameter          	 |Mandatory/Optional|    Description                          				 | Allowed Values              |
|----------------------------|------------------|--------------------------------------------------------|-----------------------------|
| create-package         	 | Mandatory        |Flag to check whether access package should be created	 | true/false
| catalog-name               | Mandatory        |Access package catalog referencing this access package  | Any text in plain English
| package-name        		 | Mandatory		|The display name of the access package 				 | Any text in plain English
| description				 | Mandatory		|The description of the access package					 | Any text in plain English
| isRoleScopesVisible		 | Mandatory		|Indicates whether role scopes are visible				 | true/false

Mandatory/Optional config key in config.json's config key 'access-policy-config' under 'access-package-config'

|     Parameter            |Mandatory/Optional							   |    Description                          				 																				 | Allowed Values              |
|--------------------------|-----------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
| create-policy            | Mandatory                                     |Flag to check whether access policy should be created	 																				 | true/false
| policy-name              | Mandatory                                     |The display name of the policy  																										 | Any text in plain English
| description        	   | Mandatory		                               |The description of the policy 				 																							 | Any text in plain English
| canExtend				   | Mandatory		                               |Indicates whether a user can extend the access package assignment duration after approval					 							 | true/false
| durationInDays		   | Mandatory		                               |The number of days in which assignments from this policy last until they are expired				 									 | Integer value from 0-365
| shouldAccessPolicyExpire | Mandatory		                               |Flag to check whether policy should expire																								 | true/false
| expirationDateTime	   | Mandatory if shouldAccessPolicyExpire is true |The expiration date for assignments created in this policy                                                                               |The Timestamp type represents date and time information using ISO 8601 format and is always in UTC time. For example, midnight UTC on Jan 1, 2014 would look like this: '2014-01-01T00:00:00Z'
| accessReviewSettings	   | Mandatory	                                   |Who must review, and how often, the assignments to the access package from this policy. This property is null if reviews are not required| assignmentReviewSettings resource type. Refer to https://docs.microsoft.com/en-us/graph/api/resources/assignmentreviewsettings?view=graph-rest-beta

Mandatory/Optional config key in config.json's config key 'requestorSettings' under 'access-policy-config'. This configuration is mandatory if access policy should be executed. If there are multiple groups requesting the access package, provide comma seperated allowedRequestors json objects

|     Parameter       |Mandatory/Optional |    Description                          				 																	| Allowed Values              |
|---------------------|-------------------|-----------------------------------------------------------------------------------------------------------------------------|-----------------------------|
| scopeType           | Mandatory         |Who can request	 																				 							| NoSubjects, SpecificDirectorySubjects, SpecificConnectedOrganizationSubjects, AllExistingConnectedOrganizationSubjects, AllExistingDirectoryMemberUsers, AllExistingDirectorySubjects or AllExternalSubjects
| acceptRequests      | Mandatory         |Indicates whether new requests are accepted on this policy  																	| true/false
| allowedRequestors   | Mandatory		  |The users who are allowed to request on this policy, which can be singleUser, groupMembers, and connectedOrganizationMembers | Any text in plain English

Mandatory/Optional config key in config.json's config key 'requestApprovalSettings' under 'access-policy-config'. This configuration is mandatory if access policy should be executed. If there are multiple approval stages for the access package, provide comma seperated approvalStages json objects

|     Parameter       							  |Mandatory/Optional 										  |    Description                          				 																												 | Allowed Values              																						   |
|-------------------------------------------------|-----------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------|
| isApprovalRequired           					  | Mandatory         										  |Indicates whether approval is required for requests in this policy	 																				 					 | true/false
| isApprovalRequiredForExtension      			  | Mandatory         										  |Indicates whether approval is required for a user who already has an assignment to extend  																				 | true/false
| isRequestorJustificationRequired   			  | Mandatory		  										  |Indicates whether the requestor is required to supply a justification in their request 																					 | true/false	
| approvalMode									  | Mandatory												  |Approval Mode for the policy																																				 | NoApprval/SingleStage/Serial
| is-multi-stage-approval						  | Mandatory												  |Flag to check whether policy requires multi stage approval											  																     | true/false
| approvalStages->approvalStageTimeOutInDays	  | Mandatory if approvalMode is set to SingleStage or Serial |The number of days that a request can be pending a response before it is automatically denied																			 | Integer
| approvalStages->isApproverJustificationRequired | Mandatory if approvalMode is set to SingleStage or Serial |Indicates whether the approver is required to provide a justification for approving a request																			 | true/false
| approvalStages->isEscalationEnabled			  | Mandatory if approvalMode is set to SingleStage or Serial |Indicates whether escalation approvers are configured for the approval stage																								 | true/false
| approvalStages->escalationTimeInMinutes		  | Mandatory if approvalMode is set to SingleStage or Serial |If escalation is required, the time a request can be pending a response from a primary approve																			 | Integer
| approvalStages->primaryApprovers				  | Mandatory if approvalMode is set to SingleStage or Serial |The users who will be asked to approve requests. A collection of singleUser, groupMembers, requestorManager, internalSponsors and externalSponsors						 | userSet collection. Please refer https://docs.microsoft.com/en-us/graph/api/resources/userset?view=graph-rest-beta
| approvalStages->escalationApprovers			  | Mandatory if approvalMode is set to SingleStage or Serial |If escalation is enabled and the primary approvers do not respond before the escalation time, the escalationApprovers are the users who will be asked to approve requests | userSet collection. Please refer https://docs.microsoft.com/en-us/graph/api/resources/userset?view=graph-rest-beta

Mandatory/Optional config key in config.json's config key 'resource-definition' under 'access-pkg-management'. The configurations are mandatory if resources should be added to catalog. If multiple resources should be added to a single catalog, provide comma seperated accessPackageResource json objects. If resources should be added to multiple catalog, provide comma seperated resource-config json objects. 

|     Parameter          	           |Mandatory/Optional|    Description                          				 										  | Allowed Values              		   |
|--------------------------------------|------------------|---------------------------------------------------------------------------------------------------|----------------------------------------|
| add-resource-to-catalog         	   | Mandatory        |Flag to check whether resources should be added to catalog 										  | true/false
| group-mgmt-rest-api                  | Mandatory        |REST API call for group operations  																  | Default value. Do not change
| app-mgmt-rest-api        		       | Mandatory		  |REST API call for application management operations 				 								  | Default value. Do not change
| access-pkg-res-req-rest-api		   | Mandatory		  |REST API call for resource request operations					 								  | Default value. Do not change
| resource-config->catalog-name		   | Mandatory		  |Name of catalog in which resources should be added				 								  | Any text in plain English
| resource-config->requestType         | Mandatory        |Use AdminAdd to add a resource, if the caller is an administrator or resource owner 				  | Default value: AdminAdd. Do not change
| jresource-config->justification	   | Mandatory        |The requestor's justification for adding the resource											  | Any text in plain English
| accessPackageResource->resource-name | Mandatory        |The display name of the resource, such as the application name, group name or site name 			  | Any text in plain English
| accessPackageResource->description   | Mandatory        |A description for the resource 																	  | Any text in plain English
| accessPackageResource->url		   | Optional         |A unique resource locator for the resource, such as the URL for signing a user into an application | URL site
| accessPackageResource->resourceType  | Mandatory        |The type of the resource 																		  | Application/Security Group
| accessPackageResource->originSystem  | Mandatory        |The type of the resource in the origin system 													  | AadApplication/AadGroup

Mandatory/Optional config key in config.json's config key 'resource-role-definition' under 'access-pkg-management'. The configurations are mandatory if access package should be updated with resource role scopes. If multiple packages should be updated with resource roles, provide comma seperated resource-scope-config json objects. 

|     Parameter          	           |Mandatory/Optional					  |    Description                          				 						  Allowed Values        				  |
|--------------------------------------|--------------------------------------|----------------------------------------------------------------------------------|----------------------------------------|
| add-resource-role         	   	   | Mandatory        					  |Flag to check whether resources role scope should be updated in access package 	 | true/false
| resource-scope-config->catalog-name  | Mandatory        					  |Catalog Name  																  	 | Any text in plain English
| resource-scope-config->package-name  | Mandatory		  					  |Package Name				 								  						 | Any text in plain English
| resource-scope-config->resource-name | Mandatory		  					  |Application/Group Name					 								  		 | Any text in plain English
| resource-scope-config->isOwner	   | Mandatory		  					  |Flag to check whether the users from this package should be Owner of the group    | true/false				 								  
| resource-scope-config->displayName   | Mandatory if isOwner is set to False |The display name of the resource role such as the role defined by the application | Default value: AdminAdd. Do not change
| resource-scope-config->description   | Mandatory if isOwner is set to False |A description for the resource role											     | Any text in plain English



**NOTE**

1) Don't alter the configuration key parameters names. Just key in the allowed configuration values
2) Mandatory values are required
3) In 'Parameter Allowed Values Table' => '/' indicates only one of those values are allowed

## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The azure policy suite script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-azure-ad\bin` folder
3. Run script

### Examples
 1. To Execute the script to create build access package in AZ AD
	```powershell
	$ .\BuildAccessPkg.ps1 -ConfigFile "config.json" -ConfigToLoad "access-pkg-management" -LogLevel "Debug" -Type "File" -FileName "accessPackageLogger"
	```
	
---

-------------------------------------------------------------------
# Automation: Create Azure Policy
-------------------------------------------------------------------
This module includes scripts to assign azure policies

---

# Create Azure Policy :: Configuration file

***NOTE***

Parameter Allowed Values Table -
Mandatory/Optional config key in config.json's config key 'custom-policy' under 'azure-custom-policy'

|     Parameter          		|Mandatory/Optional|    Description                          | Allowed Values                                                                             |
|-------------------------------|------------------|---------------------------------------- |--------------------------------------------------------------------------------------------|
| policyName		       		| Mandatory        |Name of policy definition templates      | <policy template name>
| jsonPath						| Mandatory        |CSV path for azure policy definition     | Path of CSV file on script running server
|                        		|                  |templates.				                 |    														 



*FAQs -
How configuration key values needs to be updated in config.json's config key 'custom-policy-assignment' ?
1) isBulkLoad:
				"Yes" => For Bulk Policy creation, reads configuration key values from CSV file line by line
			    "No"  => For Single Policy creation, reads configuration key values from config.json file

2) Use semicolon character ';' to provide multiple values in policyName:
   - For updating the key values in config.json’s file, enclosed the values is double quotes ("")
   	    
**NOTE**

1) Mandatory values are required to create a policy
2) These Allowed values are *CASE-SENSITIVE* 

## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The azure policy suite script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-azure-ad\bin` folder
3. Run script

### Examples
 1. To Execute the script to create Azure policy in AZ
	```powershell
	$ .\CreateCustomPolicy.ps1 -ConfigFile "config.json" -ConfigToLoad "azure-custom-policy" -LogLevel "Debug" -Type "File" -FileName "custompolicyLogger"
	```

---

-------------------------------------------------------------------
# Automation: Azure Policy Assignment
-------------------------------------------------------------------
This module includes scripts to assign azure policies

---

# Azure Policy Assignment :: Configuration file

***NOTE***

Parameter Allowed Values Table -
Mandatory/Optional config key in config.json's config key 'custom-policy-assignment' under 'azure-custom-policy'

|     Parameter          		|Mandatory/Optional|    Description                          | Allowed Values                                                                             |
|-------------------------------|------------------|---------------------------------------- |--------------------------------------------------------------------------------------------|
| SubscriptionName       		| Mandatory        |Name of subscription                     | <Subscription name>
| isBulkLoad   	         		| Mandatory        |Flag for bulk policy assignment          | Yes / No
| BulkPolicyAssignmentCSVPath	| Optional         |CSV path for bulk policy assignment if   | Path of CSV file on script running server
|                        		|                  |isBulkLoad is 'Yes'.                     |    														 
| BulkPolicyAssignmentCSVFile	| Optional         |CSV file name for bulk policy assinment  | CSV file name on script running server
|                        		|                  |if isBulkLoad is 'Yes'.                  | (Without .csv extension)
| scopeType			     		| Optional         |Scope level at which policy will be 	 | ManagementGroup / Subscription / ResourceGroup / Resource
|                        		|                  |assigned.							     | 
| scopeValue		       		| Optional         |Scope at which policy will be assigned   | <Scope Name> (if scopeType is subscription then subscription name)
| notInScopeResourceGroups 		| Optional         |Resource groups to be excluded from      | <Resource group name in azure>
|								|				   |policy assignment.     					 |
| notInScopeResources      		| Optional         |Resource groups to be excluded from    	 | <Resource name in azure>
|								|				   |policy assignment.						 |
| policyName		     		| Optional         |Name of policy definition to be assigned | <Policy definition Name> 
| policyDisplayname		 		| Optional         |Policy assignment display name      	 | Any text in plain English   														 
| parameterType		    		| Optional         |Data type of parameter (some policy      | String / Array 
|								|				   |definitions have mandatory parameters)   |
| parameters			 		| Mandatory        |Parameters for policy assignment         | <policy parameters>
| description				    | Optional         |Policy assignment description            | Any text in plain English 
| enforcementMode				| Optional         |To create enabled/disabled policy   	 | default / DoNotEnforce
|                    		    |                  |assignment applies to.                   | 
| createManagedIdentity         | Optional         |Policy assignment needs to create     	 | Yes / No
|								|				   |managed identity or not.				 |
| managedIdentityLocation       | Optional         |Managed Identity location			     | <named location>



*FAQs -
How configuration key values needs to be updated in config.json's config key 'custom-policy-assignment' ?
1) isBulkLoad:
				"Yes" => For Bulk Policy creation, reads configuration key values from CSV file line by line
			    "No"  => For Single Policy creation, reads configuration key values from config.json file

2) Use semicolon character ';' to provide multiple values in csv:
   - For updating the key values in config.json’s file, enclosed the values is double quotes ("")
   - For updating the key values of policy in CSV file, directly provide the values.
   	    
**NOTE**

1) Don't alter the configuration key parameters names in CSV
2) Mandatory values are required to create a policy
3) These Allowed values are *CASE-SENSITIVE* 

## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The azure policy suite script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-azure-ad\bin` folder
3. Run script

### Examples
 1. To Execute the script to assign azure policy in AZ
	```powershell
	$ .\AssignCustomPolicy.ps1 -ConfigFile "config.json" -ConfigToLoad "azure-custom-policy" -LogLevel "Debug" -Type "File" -FileName "custompolicyAssignmentLogger"
	```

---
-------------------------------------------------------------------
# Automation: Disconnected Provisioning 
-------------------------------------------------------------------
This module includes scripts to create enterprise applications, logic applications, alerts and access packages

---
# Disconnected Provisioning  :: disconnected-provisioning-management

***NOTE***
DO NOT change the values of below config key in config.json's config key 'disconnected-provisioning-management':

|     Parameter                   |Mandatory/Optional (Default Value)|    Description    										    |
|---------------------------------|----------------------------------|--------------------------------------------------------------|
| enterprise-application-stage	  |Mandatory                         | JSON configurations for Enterprise application creation stage| 
| logic-application-stage	      |Mandatory						 | JSON configurations for Logic Application creation stage	    |
| access-package-stage            |Mandatory						 | JSON configurations for Access Package creation stage	    |	
| azure-alerts-stage              |Mandatory						 | JSON configurations for Azure alerts creation stage          |
| AADLicense                      |Mandatory						 | Name of AzureAD License                                      |
| AADRole				          |Mandatory						 | Array of user assigned Roles. User should have role with minimum permissions equivalent to "Security Administrator", "Company Administrator","Conditional Access administrator"|


# Disconnected Provisioning  :: enterprise-application-stage

|     Parameter                      |Mandatory/Optional (Default Value)|    Description    										   |
|------------------------------------|----------------------------------|--------------------------------------------------------------|
| isDeploy                  	     |Mandatory                         | Flag that indicates whether Enterprise Application creation stage needs to be executed |
| enterprise-application-script-file |Mandatory			 				| The script that needs to be called to execute the enterprise application creation stage | 
| enterprise-application-management  |Mandatory			 				| Parent element of Enterprise app creation configuration	   |	
| enterprise-application-config      |Mandatory				 			| JSON array to store configurations of multiple applications  |
| displayName                        |Mandatory						 	| Display name of Enterprise application                       |             |
| externalUrl				         |Mandatory						 	| Application proxy external url    						   |
| internalUrl                        |Mandatory                         | Application proxy internal url  							   |
| connectorGroupId                   |Mandatory                         | Application proxy connector group id                         |
| application-role-config			 |Mandatory						    | Array containing JSON configuration of application roles     |
| displayName						 |Mandatory							| Display name of application role							   |
| isEnabled							 |Mandatory							| Flag that indicates if the app is to be enabled/disabled	   |
| description						 |Mandatory							| Description of the application role						   |
| allowedMemberTypes				 |Mandatory							| Allowed member types (User/Application)					   |


# Disconnected Provisioning  :: logic-application-stage

|     Parameter                      |Mandatory/Optional (Default Value)|    Description    										   |
|------------------------------------|----------------------------------|--------------------------------------------------------------|
| isDeploy                  	     |Mandatory                         | Flag that indicates whether Logic Application creation stage needs to be executed |
| logic-application-script-file      |Mandatory			 				| The script that needs to be called to execute the logic application creation stage | 
| logic-application-management       |Mandatory			 				| Parent element of Logic app creation configuration	       |	
| logic-apps-config                  |Mandatory				 			| JSON array to store configurations of multiple logic apps    |
| resourceGroupName                  |Mandatory						 	| Resource group within which the logic app needs to be created|
| logicAppName				         |Mandatory						 	| Name of the logic application      						   |
| templateFile                       |Mandatory                         | ARM template file location    							   |
| parameterFile                      |Mandatory                         | ARM template parameters file location                        |
| isServicePrincipal			     |Mandatory						    | Flag to enabled managed identity for logic app (true/false)  |
| servicePrincipalPermissions		 |Mandatory							| List of Graph API permissions that need to be assigned to the managed identity							   |

# Disconnected Provisioning  :: access-package-stage

|     Parameter                      |Mandatory/Optional (Default Value)|    Description    										   |
|------------------------------------|----------------------------------|--------------------------------------------------------------|
| isDeploy                  	     |Mandatory                         | Flag that indicates whether Access Package creation stage needs to be executed |
| access-package-script-file         |Mandatory			 				| The script that needs to be called to execute the access package creation stage |
| config-to-load                     |Mandatory							| This configuration points to another section within config.json file that contains the configurations of access package creation|


# Disconnected Provisioning  :: azure-alerts-stage

|     Parameter                      |Mandatory/Optional (Default Value)|    Description    										   |
|------------------------------------|----------------------------------|--------------------------------------------------------------|
| isDeploy                  	     |Mandatory                         | Flag that indicates whether Azure Alerts creation stage needs to be executed |
| azure-alerts-script-file           |Mandatory			 				| The script that needs to be called to execute the azure alerts creation stage | 
| azure-alerts-management            |Mandatory			 				| JSON array that can store configurations of multiple azure alerts|
| alertName							 |Mandatory							| Name of the alert rule									   |
| alertDescription					 |Mandatory							| Description of the alert rule								   |
| isEnabled							 |Mandatory							| Flag that indicates whether the alert rule is to be enabled/disabled |
| alertResourceGroup				 |Mandatory							| Resource Group in which the alert rule is to be created      |
| workspaceName						 |Mandatory							| Log Analytics workspace where Azure AD logs are being sent   |
| workspaceResourceGroup             |Mandatory							| Resource Group name of the above Log Analytics workspace     |
| action-group-config                |Mandatory							| JSON containing configuration of the Action Group            |
| actionGroupName					 |Mandatory						    | Name of the Action Group									   |
| actionGroupShortName				 |Mandatory							| Short name of the Action Group							   |
| resourceGroupName					 |Mandatory							| Resource Group within which the Action Group needs to be created |
| logicAppName						 |Mandatory							| Name of the logic application that will be invoked when the alert is triggered|
| receiverName						 |Mandatory							| Name of the Receiver of type Logic App					   |
| useCommonAlertSchema				 |Mandatory							| Flag that indicates whether the common alert schema is to be used while sending audit JSON data to the logic application|
| scheduled-query-rules-config       |Mandatory							| JSON containing configuration of the Scheduled Query Rule	   |
| query								 |Mandatory							| Query that is executed against the Log Analytics workspace   |
| queryType							 |Mandatory							| Type of query (ResultCount)								   |
| frequencyInMinutes				 |Mandatory							| Frequency with which the query is executed				   |
| queryWindow						 |Mandatory							| Time span in the past over which the query is to be executed |
| alerting-action-config			 |Mandatory							| JSON containing configuration Alerting Action Configuration  |
| thresholdOperator					 |Mandatory							| Operator that will be used while determining threshold       |
| thresholdValue					 |Mandatory							| Value against which the threshold will be compared		   |
| severity							 |Mandatory							| Severity level of the alert								   |


## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The azure policy suite script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\kpmg-azure-ad\bin` folder
3. Run script

### Examples
 1. To Execute the script to create disconnected provisioning package in AZ AD
	```powershell
	$ .\DisconnectedProvisioningDeployment.ps1 -ConfigToLoad "disconnected-provisioning-management" -LogLevel "Debug" -Type "File" -FileName "disconnectedProvisioning"
	```
	
---
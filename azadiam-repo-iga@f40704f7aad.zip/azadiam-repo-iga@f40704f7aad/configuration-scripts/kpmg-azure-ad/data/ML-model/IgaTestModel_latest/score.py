import os
import json

import numpy as np
import pickle
from sklearn.linear_model import Ridge
from azureml.core.model import Model
from inference_schema.schema_decorators import input_schema, output_schema
from inference_schema.parameter_types.numpy_parameter_type import NumpyParameterType

from azureml.studio.core.io.model_directory import ModelDirectory
from pathlib import Path
from azureml.studio.modules.ml.score.score_generic_module.score_generic_module import ScoreModelModule
from azureml.designer.serving.dagengine.converter import create_dfd_from_dict
from collections import defaultdict
from azureml.designer.serving.dagengine.utils import decode_nan
from azureml.studio.common.datatable.data_table import DataTable

from pathlib import Path

def init():
    global model
    global schema_data
    
    #with open("../../../config/config.json", "r") as f:
    #    config = json.load(f)

    #model_name = config["ML-CLI"]["Register-deploy"]["model_register_name"]
    model_path = Model.get_model_path('testCliModelv3-Prakhar')
    
    learner_model_path= Path(model_path)/'data.ilearner'
    with open(learner_model_path, 'rb') as file:
        model = pickle.load(file)
    
    schema_file_path = Path(model_path)/'_schema.json'
    with open(schema_file_path) as fp:
        schema_data = json.load(fp)

def run(data):
    data = json.loads(data)
    input_entry = defaultdict(list)
    for row in data:
        for key, val in row.items():
            input_entry[key].append(decode_nan(val))

    data_frame_directory = create_dfd_from_dict(input_entry, schema_data)
    score_module = ScoreModelModule()
    result, = score_module.run(
        learner=model,
        test_data=DataTable.from_dfd(data_frame_directory),
        append_or_result_only=True)
    
    data1 = json.dumps({"data":[{"result": result.data_frame.values.tolist()},{"columns": result.data_frame.columns.values.tolist()}]})
    jsondata = json.loads(data1)
    
    inputlist = jsondata["data"][0]["result"][0]

    columnlist = jsondata["data"][1]["columns"]
    
    leng = len(inputlist)
    
    desiredRole = "Desired Role"
    newjson={}
    newprobs={}
    
    for x in range(leng):
        newjson[columnlist[x]]=inputlist[x]
        if "Scored Labels" in columnlist[x]:
            newprobs[columnlist[x]]=inputlist[x]
        if "Scored Probabilities" in columnlist[x] and inputlist[x]>0:
            newprobs[columnlist[x]]=inputlist[x]
    
    if (newjson[desiredRole]).strip() != "" :
        newprobs["RISK LEVEL"] = "LOW"
        for x in range(leng):    
            if newjson[desiredRole] != newjson["Scored Labels"]:
                desiredProbl = (newjson["Scored Probabilities_"+newjson[desiredRole]])*100
                if (desiredProbl)>=60:
                    newprobs["RISK LEVEL"] = "LOW"
                if (desiredProbl)<60 and (desiredProbl)>=40:
                    newprobs["RISK LEVEL"] = "MEDIUM"
                if (desiredProbl)<40:
                    newprobs["RISK LEVEL"] = "HIGH"
    
    response = newprobs
    return (response)
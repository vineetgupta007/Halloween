Import-Module KPMG.Common-Utils

#Get public and private function definition files.
$Public = @( Get-ChildItem -Path $PSScriptRoot\public\*.ps1 -ErrorAction SilentlyContinue )
$Private = @( Get-ChildItem -Path $PSScriptRoot\private\*.ps1 -ErrorAction SilentlyContinue )

#Load module source files
Foreach ($import in @($Public + $Private)) {
    try {
        . $import.fullname
    }
    catch {
        Write-Error -Message "Failed to import function $($import.fullname): $_"
    }
}

Set-Variable -Name SCRIPT_PATH -Value (Split-Path (Resolve-Path $myInvocation.MyCommand.Path)) -Scope local
Set-Variable -Name FULL_SCRIPT_PATH -Value (Resolve-Path $myInvocation.MyCommand.Path) -Scope local
Set-Variable -Name CURRENT_PATH -Value ((Get-Location).Path) -Scope local

#Export login util functions
Export-ModuleMember -Function Connection-IPPSSession
Export-ModuleMember -Function Get-ConnectionIPP
Export-ModuleMember -Function Connection-MSOL
Export-ModuleMember -Function Get-ConnectionMSOL
Export-ModuleMember -Function Get-Connection
Export-ModuleMember -Function Connection-AZlogin-SPN
Export-ModuleMember -Function Get-AZConnection
Export-ModuleMember -Function Get-Token
Export-ModuleMember -Function Get-Username
Export-ModuleMember -Function GetM365-Connection
Export-ModuleMember -Function Disconnect-M365Connection

#Export app util functions
Export-ModuleMember -Function Generate-AppToken
Export-ModuleMember -Function Generate-UserToken
Export-ModuleMember -Function Get-AppRole
Export-ModuleMember -Function Create-EnterpriseApplication
Export-ModuleMember -Function Create-AzEnterpriseApplication
Export-ModuleMember -Function Get-ApplicationRoleDetails 

#Export User util functions
Export-ModuleMember -Function New-AzureGuestInvite
Export-ModuleMember -Function Find-UserAADRole
Export-ModuleMember -Function Find-AADLicense
Export-ModuleMember -Function Get-UserDetails
Export-ModuleMember -Function Get-UserAppRoleAssignments

#Export Application util functions
Export-ModuleMember -Function Get-NewApplication
Export-ModuleMember -Function Add-NewAZDynamicGroup
Export-ModuleMember -Function Add-NewAZGroup

#Export LAWS util functions
Export-ModuleMember -Function Build-Signature
Export-ModuleMember -Function Post-LogAnalyticsData
Export-ModuleMember -Function Add-DataToLAWS
Export-ModuleMember -Function Check-AzureLogAnalyticsWorkspace
Export-ModuleMember -Function Add-DataToLogs
Export-ModuleMember -Function createSingleObj
Export-ModuleMember -Function Add-CombinedDataToLogs
Export-ModuleMember -Function Add-ApplicationDataToLAWS
Export-ModuleMember -Function Set-AzureLogAnalyticsWorkspace

#Export Storage util functions
Export-ModuleMember -Function Check-AzureBlobStorage
Export-ModuleMember -Function Add-FileToBlobStorage

#Export Resource Group util functions
Export-ModuleMember -Function Check-AzureResourceGroup

#Export Azure AD Assessment util functions
Export-ModuleMember -Function Check-AzADAssessmentPreReq
Export-ModuleMember -Function Get-AzureRBACAdmins
Export-ModuleMember -Function Get-GuestsUsersThroughAzureAD
Export-ModuleMember -Function Get-CompanyInformation
Export-ModuleMember -Function Get-AzureADRoleMembers
Export-ModuleMember -Function Get-AzureADGroupDetails
Export-ModuleMember -Function Get-PwdExpiryDetails
Export-ModuleMember -Function Get-LastLoginActivityDetails
Export-ModuleMember -Function Get-MFAUsers
Export-ModuleMember -Function Get-ClassicAdminsMFA

#Export conditional policy util functions
Export-ModuleMember -Function Check-IncludeApplications
Export-ModuleMember -Function Check-ExcludeApplications
Export-ModuleMember -Function Check-IncludeUsers
Export-ModuleMember -Function Check-ExcludeUsers
Export-ModuleMember -Function Get-GroupID
Export-ModuleMember -Function Get-RoleID
Export-ModuleMember -Function Check-UserRiskLevels
Export-ModuleMember -Function Check-SignInRiskLevels
Export-ModuleMember -Function Check-ClientAppTypes
Export-ModuleMember -Function Check-IncludePlatforms
Export-ModuleMember -Function Check-ExcludePlatforms
Export-ModuleMember -Function Check-IncludeLocations
Export-ModuleMember -Function Check-ExcludeLocations
Export-ModuleMember -Function Check-IncludeDeviceStates
Export-ModuleMember -Function Check-ExcludeDeviceStates 
Export-ModuleMember -Function Check-BuiltInControls
Export-ModuleMember -Function Check-CloudAppSecurityType
Export-ModuleMember -Function Check-SignInFrequencyType
Export-ModuleMember -Function Check-IncludeUserActions
Export-ModuleMember -Function Check-MandatoryKeyValue
Export-ModuleMember -Function create-policyTemplate

#Export O365 functions
Export-ModuleMember -Function Get-DLPCompliancePolicySummary
Export-ModuleMember -Function Get-SensitivityLabelSummaryDetails
Export-ModuleMember -Function Get-DataRetentionPolicySummary
Export-ModuleMember -Function Connect-EXOnline
Export-ModuleMember -Function Execute-MCASAPI
Export-ModuleMember -Function Get-Creds
#AccessPackage functions
Export-ModuleMember -Function Add-Catalog
Export-ModuleMember -Function Add-Catalog-Bulk-Load
Export-ModuleMember -Function Get-CatalogID
Export-ModuleMember -Function Add-AccessPackage
Export-ModuleMember -Function Get-AccessPackageID
Export-ModuleMember -Function Add-Policy
Export-ModuleMember -Function Add-Resource-To-Catalog
Export-ModuleMember -Function Add-ResourceScope

#Export Service Principal util functions
Export-ModuleMember -Function Add-ServicePrincipal-GraphAPIPermissions

#Export Alert util functions
Export-ModuleMember -Function Create-ActionGroup
Export-ModuleMember -Function Create-AlertRule
Export-ModuleMember -Function Create-AzAlert

#Logic App util
Export-ModuleMember -Function Create-AzLogicApplication

# Excel Util
Export-ModuleMember -Function Remove-ExcelSheet
Export-ModuleMember -Function Initialize-Excel
Export-ModuleMember -Function Add-ExcelSheetData
Export-ModuleMember -Function Add-ExcelSummaarySheetData
Export-ModuleMember -Function Add-ExcelReportSheetData
Export-ModuleMember -Function New-ExecutionReport

# M365 Assessment Util
Export-ModuleMember -Function Get-CsvEmbedFileData
Export-ModuleMember -Function Get-GraphApiData 

#IGA
Export-ModuleMember -Function Create-AzNetworkComponents
Export-ModuleMember -Function Create-AzNetworkComponentsUsingBlueprint
Export-ModuleMember -Function Add-AccessReview
Export-ModuleMember -Function Get-AccessReviewID
Export-ModuleMember -Function Create-PrejoinerWorkflow
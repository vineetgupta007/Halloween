<#
    .SYNOPSIS
        This contains all the utility functions related to Azure Storage
    .DESCRIPTION
        This contains all the common utility related to Log Azure Storage

#>

<#
    .SYNOPSIS
        This function is used for checking if Azure Blob Storage is present or not
    .DESCRIPTION
        This function is used for checking if Azure Blob Storage is present or not
    .PARAMETER storageAccountRG
        Resource Group Name where Azure Storage Account is defined
    .PARAMETER storageAccountName
        Name of the Azure Storage Account
    .PARAMETER storageContainerName
        Name of the Azure Storage Container
    .PARAMETER createResource
        Flag to create resources
	.PARAMETER resourceGroupLocation
        Location for resource group
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Check-AzureBlobStorage -storageAccountRG "AnalyticsDemo" -storageAccountName "demostorageaccnt2020" -storageContainerName "azureassessment" -createResource $true
#>
function Check-AzureBlobStorage {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$storageAccountRG,

        [Parameter(Mandatory = $true, Position = 1)]
        [string]$storageAccountName,

        [Parameter(Mandatory = $true, Position = 2)]
        [string]$storageContainerName,

        [Parameter(Mandatory = $true, Position = 3)]
        [bool]$createResource,
		
		[Parameter(Mandatory = $true, Position = 4)]
        [string]$resourceGroupLocation
        
    )
    Process {
        Write-LogInfo "Inside Function Check-AzureBlobStorage"
        
        try {
            $LASTEXITCODE = 1
            
            $checkResourceGroup = Check-AzureResourceGroup -resourceGroupName $storageAccountRG -createResource $createResource -resourceGroupLocation $resourceGroupLocation
            if ($checkResourceGroup -eq 0) {  
                $storageAccount = Get-AzStorageAccount -ResourceGroupName $storageAccountRG -Name $storageAccountName
                if ($storageAccount) {
                    $key = (Get-AzStorageAccountKey -ResourceGroupName $storageAccountRG -AccountName $storageAccountName).Value[0]
                    $storageContext = New-AzStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $key
                    
                    $storageContainer = Get-AzStorageContainer -Context $storageContext -Name $storageContainerName
                    if ($storageContainer) {
                        Write-LogInfo "Storage Container '$storageContainerName' does exist"
                    }
                    else {
                        if ($createResource) {
                            Write-LogDebug "Creating Storage account container '$storageContainerName'"
                            $AzStorageContainer = New-AzStorageContainer -Name $storageContainerName -Context $storageContext
                        }
                        else {
                            Throw "Storage Container '$storageContainerName' does not exist"
                        }
                    }
                }
                else {
                    Write-LogDebug "Storage account '$storageAccountName' does not exist in resource group $storageAccountRG"
                    if ($createResource) {
                        if (!$resourceGroupLocation) {
                            #$resourceGroupLocation = Read-Host "resourceGroupLocation";
							 Throw "Location to create storage account '$storageAccountName' is null"
                        }
                        Write-LogDebug "Creating Storage account '$storageAccountName'"
                        $AzStorageAccount = New-AzStorageAccount -ResourceGroupName $storageAccountRG -AccountName $storageAccountName -Location $resourceGroupLocation -SkuName "Standard_LRS"
                        $key = (Get-AzStorageAccountKey -ResourceGroupName $storageAccountRG -AccountName $storageAccountName).Value[0]
                        $storageContext = New-AzStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $key
                        Write-LogDebug "Creating Storage account container '$storageContainerName'"
                        $AzStorageContainer = New-AzStorageContainer -Name $storageContainerName -Context $storageContext

                    }
                    else {
                        Throw "Storage account '$storageAccountName' does not exist in resource group $storageAccountRG"
                    }
                
                }
            }
            $LASTEXITCODE = 0;
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
        }
        Write-LogInfo "Exiting Function Check-AzureBlobStorage"
        return $storageContext
    }

}
<#
    .SYNOPSIS
        This function is used for uploading file to blob storage for a given file
    .DESCRIPTION
        This function is used for uploading file to blob storage for a given file
    .PARAMETER storageContext
        Context created for storage accoount
    .PARAMETER filePath
        Full path of the file to be uploaded
    .PARAMETER storageContainerName
        Blob Storage container where file needs to be uploaded
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Add-FileToBlobStorage -storageContext $storageContext -filePath "\data\AssessmentCriteria.csv" -storageContainerName "azureassessment"
#>
function Add-FileToBlobStorage {
    [CmdletBinding()]
    [OutputType([int])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [Microsoft.WindowsAzure.Commands.Storage.AzureStorageContext]$storageContext,

        [Parameter(Mandatory = $true, Position = 1)]
        [string]$filePath,

        [Parameter(Mandatory = $true, Position = 2)]
        [string]$storageContainerName

    )
    Process {
        Write-LogInfo "Inside Function Add-FileToBlobStorage"
        try {
            $LASTEXITCODE = 1
            $upload = Set-AzStorageBlobContent -Container $storageContainerName -File $filePath -Context $storageContext -Force
            if ($null -eq $upload.LastModified) {
                $LASTEXITCODE = 2
                
            }
            $LASTEXITCODE = 0
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
        }
        Write-LogInfo "Exiting Function Add-FileToBlobStorage"
        return $LASTEXITCODE  
    }
}


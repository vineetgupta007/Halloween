function Add-AccessReview {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, Position = 0)]
        [PSCustomObject] $CreateReviewProps,
        [Parameter(Mandatory = $true, Position = 1)]
        [string] $Token,
        [Parameter(Mandatory = $true, Position = 2)]
        [string] $InvokeRestMethodURI
    )
    process {
        Write-LogInfo "Inside Function Add-AccessReview"
        try {
            $RevName = $CreateReviewProps.'displayName'
            #check if Catalogs exists
            $ReviewID = Get-AccessReviewID -Token $Token -ReviewName $RevName -InvokeRestMethodURI $InvokeRestMethodURI
            if (StringNullOrEmpty $ReviewID) {
                $headers = Get-Headers -Token $Token
                
                Write-LogInfo "CreateReviewProps=$CreateReviewProps"
                #$rawBody = $CreateReviewProps | Out-String | ConvertFrom-Json
                #Write-LogInfo "rawBody=$rawBody"

                #$Body = $rawBody.replace(";", ",")
                #$finalBody = $Body | ConvertTo-Json
                $Body = $CreateReviewProps | ConvertTo-Json -Depth 100
                #$finalBody = $Body.replace("\","");
                
                Write-LogInfo "CreateReviewJson=$Body"
                try {
                    $response = Invoke-RestMethod $InvokeRestMethodURI -Method 'POST' -Headers $headers -Body $Body;
                    $ReviewID = $response.id
                    Write-LogInfo "Catalog created successfully::$ReviewID"
                }
                catch {
                    Write-LogError "StatusCode:" $_.Exception.Response.StatusCode.value__ 
                    Write-LogError "StatusDescription:" $_.Exception.Response.StatusDescription
                    Write-LogError "Response:" $_.Exception.Response
                    Write-LogError "Response:" $_.
                    $ReviewID = $null
                    break
                }
                
            }
            else {
                Write-Host "Access review exists, skipping access review creation"
            }
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
        Write-LogInfo "Exiting Function Add-AccessReview"
    }
}

function Get-AccessReviewID {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory = $true, Position = 0)]
        [string] $ReviewName,
        [Parameter(Mandatory = $true, Position = 1)]
        [string] $Token,
        [Parameter(Mandatory = $true, Position = 2)]
        [string] $InvokeRestMethodURI
    )
    process {
        Write-LogInfo "Inside Function Get-AccessReviewID"
        $ReviewID = $null
        $headers = Get-Headers -Token $Token
        try {
            $InvokeRestMethodURI = $InvokeRestMethodURI + "?`$filter=displayName eq '$ReviewName'"
            Write-LogInfo "InvokeRestMethodURI=$InvokeRestMethodURI"
            $response = Invoke-RestMethod $InvokeRestMethodURI -Method 'GET' -Headers $headers
            Write-LogInfo "response=$response"
            $ReviewID = $response.value.id
            Write-LogInfo "ReviewID=$ReviewID"
        }
        catch {
            Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
            Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
            Write-Host "Response:" $_.Exception.Response
            Write-Host "Response:" $_.
            $ReviewID = $null
        }
        Write-LogInfo "Exiting Function Get-AccessReviewID"
        return $ReviewID
    }
}
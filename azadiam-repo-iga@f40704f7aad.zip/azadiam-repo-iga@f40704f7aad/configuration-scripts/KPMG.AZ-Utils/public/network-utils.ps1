<#
    .SYNOPSIS
        Deploy network componenets to Azure
    .DESCRIPTION
        This is the script to deploy network componenets in Azure using ARM template.
    .PARAMETER ConfigFile
        JSON containing configuration of alert that is to be created. This element exists in the config.json 
        file as logic-application-management.   
    .EXAMPLE
        1. To Execute the script in main-forest, DC1
		
#>
function Create-AzNetworkComponents {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $False, HelpMessage = "Enter the configuration file that has relevant configuration.", Position = 0)]
        [PSCustomObject]$networkConfig   
    )
    try {    
        Write-LogInfo "Entering Create-AzNetworkComponents"

        #Default exit code
        $LASTEXITCODE = 1

        #Read config types
        #$NetworkConfiguration = $networkConfig | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
        #$LogicAppKeyNames = $logicAppConfig | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
        if ($null -ne $networkConfig) {
            Write-LogInfo "Validating network configurations"

            #$AZNetwork = "network-config"
            Write-LogDebug "NetworkConfiguration::$networkConfig"

            #Validating configurations for networks
            try {
                If ($null -eq $networkConfig.resourceGroupName) {
                    $LASTEXITCODE = 10
                    Throw "ResourceGroupName is not configured in JSON properties file"
                }
                $log_var = $networkConfig.resourceGroupName
                Write-LogDebug "Resource Group Name: $log_var"

                If ($null -eq $networkConfig.templateFile) {
                    $LASTEXITCODE = 11
                    Throw "Template File is not configured in JSON properties file"
                }
                $log_var = $networkConfig.templateFile
                Write-LogDebug "Template File Name: $log_var"

                If ($null -eq $networkConfig.parameterFile) {
                    $LASTEXITCODE = 12
                    Throw "Parameter File is not configured in JSON properties file"
                }
                $log_var = $networkConfig.parameterFile
                Write-LogDebug "Parameter File Name: $log_var"

                If ($null -eq $networkConfig.isServicePrincipal) {
                    $LASTEXITCODE = 13
                    Throw "Service principle is not configured in JSON properties file"
                }
                $log_var = $networkConfig.isServicePrincipal
                Write-LogDebug "Is Service principle required: $log_var"
            }
            catch [System.Exception] {
                Write-LogInfo "Inside catch block."
                If (($LASTEXITCODE -eq $null) -or ($LASTEXITCODE -eq 0)) {
                    $LASTEXITCODE = 14
                }
                $ErrorMessage = $_.Exception.Message
                Write-LogError "Exit Code :: $LASTEXITCODE | Message :: $ErrorMessage"
            }
            $results = New-AzResourceGroupDeployment -ResourceGroupName $networkConfig.resourceGroupName -TemplateFile $networkConfig.templateFile -TemplateParameterFile $networkConfig.parameterFile
            
            #Deploying the network components          
            Write-LogDebug "Created all network components"
        }
        else {
            $LASTEXITCODE = 15
            Throw "Network configuration not found"
        }       
    }
    catch [System.Exception] {
        Write-LogInfo "Inside catch block."
        If (($LASTEXITCODE -eq $null) -or ($LASTEXITCODE -eq 0)) {
            $LASTEXITCODE = 16
        }
        $ErrorMessage = $_.Exception.Message
        Write-LogError "Exit Code :: $LASTEXITCODE | Message :: $ErrorMessage"
    }
    finally {
        Write-LogInfo "Inside finally block."
        Write-LogInfo "Script finished with exit code :: $LASTEXITCODE"
    }
}
function Create-AzNetworkComponentsUsingBlueprint {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $False, HelpMessage = "Enter the configuration file that has relevant configuration.", Position = 0)]
        [PSCustomObject]$networkConfig   
    )
    try {    
        Write-LogInfo "Entering Create-AzNetworkComponents"

        #Default exit code
        $LASTEXITCODE = 1

        #Read config types
        #$NetworkConfiguration = $networkConfig | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
        #$LogicAppKeyNames = $logicAppConfig | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
        if ($null -ne $networkConfig) {
            Write-LogInfo "Validating network configurations"

            #$AZNetwork = "network-config"
            Write-LogDebug "NetworkConfiguration::$networkConfig"

            #Validating configurations for networks
            try {
                If ($null -eq $networkConfig.subscriptionId) {
                    $LASTEXITCODE = 10
                    Throw "Subscription ID is not configured in JSON properties file"
                }
                $log_var = $networkConfig.subscriptionId
                Write-LogDebug "Subscription ID: $log_var"

                If ($null -eq $networkConfig.blueprintFilepath) {
                    $LASTEXITCODE = 11
                    Throw "Blueprint File path is not configured in JSON properties file"
                }
                $log_var = $networkConfig.blueprintFilepath
                Write-LogDebug "Blueprint File Path: $log_var"

                If ($null -eq $networkConfig.deplymentName) {
                    $LASTEXITCODE = 12
                    Throw "Deplyment Name not configured in JSON properties file"
                }
                $log_var = $networkConfig.deplymentName
                Write-LogDebug "Deplyment Name: $log_var"

                If ($null -eq $networkConfig.blueprintVersion) {
                    $LASTEXITCODE = 13
                    Throw "blueprint version not configured in JSON properties file"
                }
                $log_var = $networkConfig.blueprintVersion
                Write-LogDebug "Blueprint version: $log_var"
            }
            catch [System.Exception] {
                Write-LogInfo "Inside catch block."
                If (($LASTEXITCODE -eq $null) -or ($LASTEXITCODE -eq 0)) {
                    $LASTEXITCODE = 14
                }
                $ErrorMessage = $_.Exception.Message
                Write-LogError "Exit Code :: $LASTEXITCODE | Message :: $ErrorMessage"
            }
            $results = Import-AzBlueprintWithArtifact -Name $networkConfig.deplymentName -SubscriptionId $networkConfig.subscriptionId -InputPath $networkConfig.blueprintFilepath
            Write-LogDebug "Result:: $results"

            $bp = Get-AzBlueprint -SubscriptionId $networkConfig.subscriptionId -Name $networkConfig.deplymentName

            if($null -eq $bp){
                $LASTEXITCODE = 101
                Throw "Blueprint with name $networkConfig.deplymentName doesn't exist in subscription::: $networkConfig.subscriptionId"
            }

            $publish = Publish-AzBlueprint -Blueprint $bp -Version $networkConfig.blueprintVersion

            #Deploying the network components          
            Write-LogDebug "Created all network components"

            #Assign the blueprint
            $assignmentName = $networkConfig.deplymentName + "-assignment"
            $params = @{nameprefix=$networkConfig.nameprefix;password=$networkConfig.VMpwd;hublocation=$networkConfig.location}
            $assign = New-AzBlueprintAssignment -Name $assignmentName -Blueprint $bp -Location $networkConfig.location -SubscriptionId $networkConfig.subscriptionId -Parameter $params
        }
        else {
            $LASTEXITCODE = 15
            Throw "Network configuration not found"
        }       
    }
    catch [System.Exception] {
        Write-LogInfo "Inside catch block."
        If (($LASTEXITCODE -eq $null) -or ($LASTEXITCODE -eq 0)) {
            $LASTEXITCODE = 16
        }
        $ErrorMessage = $_.Exception.Message
        Write-LogError "Exit Code :: $LASTEXITCODE | Message :: $ErrorMessage"
    }
    finally {
        Write-LogInfo "Inside finally block."
        Write-LogInfo "Script finished with exit code :: $LASTEXITCODE"
    }
}
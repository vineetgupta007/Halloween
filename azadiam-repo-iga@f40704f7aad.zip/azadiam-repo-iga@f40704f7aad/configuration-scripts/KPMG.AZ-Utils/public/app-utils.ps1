<#
    .SYNOPSIS
        Create Enterprise application and application roles in Azure AD
    .DESCRIPTION
        This is the script to create Enterprise application and application roles in Azure AD.
    .PARAMETER ConfigFile
        JSON containing configuration of alert that is to be created. This element exists in the config.json 
        file as enterprise-application-management array.    
    .EXAMPLE
        1. To Execute the function,
		a	.\CreateAzEnterpriseApplication.ps1 -appConfig $enterpriseAppConfigJson
#>
function Create-AzEnterpriseApplication {
    [CmdletBinding()]
Param(
    [Parameter(Mandatory = $True, HelpMessage = "Enter the configuration file that has relevant enterprise application configuration.", Position = 0)]
    [PSCustomObject]$appConfig
   )
    try {
        Write-LogInfo "Entering CreateAzEnterpriseApplication script"
        #Default exit code
        $LASTEXITCODE = 1       
        
        #Read Application Config types and validate configurations
        Write-LogInfo "Validating Enterprise Application configurations"

        $EAKeyNames = $appConfig | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
        if($null -ne $EAKeyNames) {
            
            #Validate JSON Application load operation configurations
            $AZEnterpriseApp="enterprise-application-config"
            if($EAKeyNames -contains $AZEnterpriseApp) {
                $AZEnterpriseAppArray=$appConfig.$AZEnterpriseApp
            }
            If($null -eq $AZEnterpriseAppArray) {
                $LASTEXITCODE = 2
                Throw "Selected $AZEnterpriseApp is not configured in JSON properties file"
            }

            # Processing enterprise applications
            foreach($ea_count in 0..($AZEnterpriseAppArray.Count-1)) {
                try {
                    $incremented_count=$ea_count+1
                    Write-LogInfo "Enterprise App Iteration: $incremented_count"                
                    
                    #Validate Enterprise Application configurations
                    If($null -eq $AZEnterpriseAppArray[$ea_count].displayName){
                        $LASTEXITCODE = 3
                        Throw "Display Name is not configured in JSON properties file"
                    }
                    $logVar=$AZEnterpriseAppArray[$ea_count].displayName
                    Write-LogDebug "App display Name: $logVar"                
            
                    If($null -eq $AZEnterpriseAppArray[$ea_count].externalUrl){
                        $LASTEXITCODE = 4
                        Throw "externalUrl is not configured in JSON properties file"
                    }
                    $logVar=$AZEnterpriseAppArray[$ea_count].externalUrl
                    Write-LogDebug "externalUrl: $logVar"
            
                    If($null -eq $AZEnterpriseAppArray[$ea_count].internalUrl){
                        $LASTEXITCODE = 5
                        Throw "internalUrl is not configured in JSON properties file"
                    }
                    $logVar=$AZEnterpriseAppArray[$ea_count].internalUrl
                    Write-LogDebug "internalUrl: $logVar"
                    
                    If($null -eq $AZEnterpriseAppArray[$ea_count].connectorGroupId){
                        $LASTEXITCODE = 6
                        Throw "connectorGroupId is not configured in JSON properties file"
                    }
                    $logVar=$AZEnterpriseAppArray[$ea_count].connectorGroupId
                    Write-LogDebug "connectorGroupId: $logVar"

                    #Validating app role configuration
                    $AZAppRole="application-role-config"
                    If($null -eq $AZEnterpriseAppArray[$ea_count].$AZAppRole){
                        $LASTEXITCODE = 7
                        Throw "Selected $AZAppRole is not configured for single app load operation in JSON properties file"
                    }
                    $AZAppRoleArray=$AZEnterpriseAppArray[$ea_count].$AZAppRole
                                                    
                    #Create app role object array
                    $appRoles = New-Object System.Collections.Generic.List[PSObject]                
                    foreach($role_count in 0..($AZAppRoleArray.Count-1)) {
                        # initialize role object
                        $newRole = $null
                        
                        $incremented_count_inner=$role_count+1
                        Write-LogInfo "Application Role Iteration: $incremented_count_inner"                                    

                        If($null -eq $AZAppRoleArray[$role_count].displayName) {
                            $LASTEXITCODE = 8
                            Throw "Display Name is not configured in JSON properties file"
                        }
                        $logVarInner=$AZAppRoleArray[$role_count].displayName
                        Write-LogDebug "Role display Name: $logVarInner"

                        If($null -eq $AZAppRoleArray[$role_count].isEnabled){
                            $LASTEXITCODE = 9
                            Throw "isEnabled is not configured in JSON properties file"
                        }
                        $logVarInner=$AZAppRoleArray[$role_count].isEnabled
                        Write-LogDebug "isEnabled: $logVarInner" 

                        If($null -eq $AZAppRoleArray[$role_count].description){
                            $LASTEXITCODE = 10
                            Throw "description is not configured in JSON properties file"
                        }
                        $logVarInner=$AZAppRoleArray[$role_count].description
                        Write-LogDebug "Role description: $logVarInner"

                        If($null -eq $AZAppRoleArray[$role_count].allowedMemberTypes){
                            $LASTEXITCODE = 11
                            Throw "allowedMemberTypes is not configured in JSON properties file"
                        }
                        $logVarInner=$AZAppRoleArray[$role_count].allowedMemberTypes
                        Write-LogDebug "allowedMemberTypes: $logVarInner"
                        
                        #Call app utility module to construct app role object
                        $newRole = Get-AppRole -roleName $AZAppRoleArray[$role_count].displayName -roleDescription $AZAppRoleArray[$role_count].description -allowedMemberTypes $AZAppRoleArray[$role_count].allowedMemberTypes -isEnabled $AZAppRoleArray[$role_count].isEnabled
                        Write-LogDebug "Create role object: $newRole"

                        $appRoles.Add($newRole)  
                    }

                    Write-LogDebug "App roles array:  $appRoles"

                    # Call function to create application and assign app roles
                    if( $null -ne $appRoles -and $appRoles.Count -gt 0 ) {
                        Write-LogInfo "App roles found during creation of application"
                        Create-EnterpriseApplication -displayName $AZEnterpriseAppArray[$ea_count].displayName -externalUrl $AZEnterpriseAppArray[$ea_count].externalUrl -internalUrl $AZEnterpriseAppArray[$ea_count].internalUrl -connectorGroupId $AZEnterpriseAppArray[$ea_count].connectorGroupId -appRolesList $appRoles
                    } else {
                        Write-LogInfo "App roles not found during creation of application"
                        Create-EnterpriseApplication -displayName $AZEnterpriseAppArray[$ea_count].displayName -externalUrl $AZEnterpriseAppArray[$ea_count].externalUrl -internalUrl $AZEnterpriseAppArray[$ea_count].internalUrl -connectorGroupId $AZEnterpriseAppArray[$ea_count].connectorGroupId
                    }
                } catch [System.Exception] {
                    Write-LogInfo "Inside catch block."
                    If (($LASTEXITCODE -eq $null) -or ($LASTEXITCODE -eq 0)) {
                        $LASTEXITCODE = 1
                    }
                    $ErrorMessage = $_.Exception.Message
                    Write-LogError "Exit Code :: $LASTEXITCODE | Message :: $ErrorMessage"
                }
            }                         
        }
    } catch [System.Exception] {
        Write-LogInfo "Inside catch block."
        If (($LASTEXITCODE -eq $null) -or ($LASTEXITCODE -eq 0)) {
            $LASTEXITCODE = 1
        }
        $ErrorMessage = $_.Exception.Message
        Write-LogError "Exit Code :: $LASTEXITCODE | Message :: $ErrorMessage"
    } finally {
        Write-LogInfo "Inside finally block."
        Write-LogInfo "CreateAzEnterpriseApplication Script finished with exit code :: $LASTEXITCODE"
    }
}

    <#
        .SYNOPSIS
            This function is for registering a new application on Azure
        .DESCRIPTION
            Registers applications for all platforms (android, IOS, Desktop, Web)
        .PARAMETER ApplicationName
            Name of application
        .PARAMETER RedirectURI
            Redirect URI of the application
        .PARAMETER TenantType
            Multi-tenant (true) or SingleTenant (false) use
        .PARAMETER Platform
            Using a web platform (false) or using other platforms such as mobile/desktop(true)
    #>

    function Get-NewApplication {
        [CmdletBinding()]
        param(
           [Parameter(Mandatory=$true)]
           [string]
           $ApplicationName,
             [Parameter(Mandatory=$false)]
           $RedirectURIS = @(""),
            [Parameter(Mandatory=$false)]
           [bool]
           $TenantType = $false,
             [Parameter(Mandatory=$false)]
           [bool]
           $Platform = $false
           )
           process {
              if (!([string]::IsNullOrEmpty($ApplicationName)) -and !($myApp = Get-AzureADApplication -Filter "DisplayName eq '$($ApplicationName)'"  -ErrorAction SilentlyContinue)) {
                  $myApp = New-AzureADApplication -DisplayName $ApplicationName -ReplyUrls $RedirectURIS -AvailableToOtherTenants $TenantType -PublicClient $Platform
               } else {
                   Write-Output "did not create application"
                }
                    
           }
   }

 <#
        .SYNOPSIS
            This function is used for creating an Azure Application Role object
        .DESCRIPTION
            Application role objects are required while creating Applications by script. 
            This utility takes care of populating required values in app role object
        .PARAMETER roleName
            Name of role
        .PARAMETER roleDescription
            Description of role
        .PARAMETER allowedMemberTypes
            User or Application member type
        .PARAMETER isEnabled
            Enable role on creation
    #>
function Get-AppRole {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string] $roleName,
        [Parameter(Mandatory=$True)]
        [string] $roleDescription,
        [Parameter(Mandatory=$True)]
        [array] $allowedMemberTypes,
        [Parameter(Mandatory=$True)]
        [bool] $isEnabled        
    )
    process {
        Write-LogInfo "Inside Function Get-AppRole"
        $appRole = New-Object Microsoft.Open.AzureAD.Model.AppRole
        $appRole.AllowedMemberTypes = New-Object System.Collections.Generic.List[string]
        foreach( $memberType in $allowedMemberTypes  ) {
            $appRole.AllowedMemberTypes.Add($memberType);
        }
        
        $appRole.DisplayName = $roleName
        $appRole.Id = New-Guid
        $appRole.IsEnabled = $isEnabled
        $appRole.Description = $roleDescription
        $appRole.Value = $roleName;

        Write-LogDebug "Successfully created AppRole object"
        Write-LogInfo "Exiting Function Get-AppRole"
        return $appRole
    }
}

<#
    .SYNOPSIS
        Create Enterprise application and application roles in Azure AD
    .DESCRIPTION
        This is the function to create Enterprise application and application roles in Azure AD.
    .PARAMETER displayName
        Specifies the Display Name of the Enterprise Application.
    .PARAMETER externalUrl
        Specifies the Application Proxy external facing URL
    .PARAMETER internalUrl
        Specifies the Application Proxy internal facing URL
    .PARAMETER connectorGroupId
        Specifies the Application Proxy connector group id
    .PARAMETER appRolesList
        List containing Application Role objects that need to be added in the application.
    .OUTPUTS
        Returns the Enterprise Application object 
#>
function Create-EnterpriseApplication {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string] $displayName,

        [Parameter(Mandatory=$True)]
        [string] $externalUrl,

        [Parameter(Mandatory=$True)]
        [string] $internalUrl,

        [Parameter(Mandatory=$True)]
        [string] $connectorGroupId,
        
        [Parameter(Mandatory=$False)]
        [System.Collections.Generic.List[PSObject]] $appRolesList
    )
    process {
        Write-LogInfo "Inside Function Create-EnterpriseApplication"

        #Create enterprise application
        $createdApp=New-AzureADApplicationProxyApplication -DisplayName $displayName -ExternalUrl $externalUrl -InternalUrl $internalUrl -ConnectorGroupId $connectorGroupId        

        Write-LogDebug "Application created successfully"
        #Verify that app got created successfully
        $searchApp=Get-AzureADApplication -Filter "DisplayName eq '$displayName'"
        Write-LogDebug "Search done successfully"
        If($null -eq $searchApp){
			$LASTEXITCODE = 1
        	Throw "Created Application $displayName not found"
		}
        Write-LogDebug "Created application: $searchApp"

        if($appRolesList -and $appRolesList.count -gt 0) {
            Write-LogDebug "App roles detected for updation"
            $updatedApplication=Set-AzureADApplication -ObjectId $searchApp.ObjectId -AppRoles $appRolesList

            #Verify that roles got updated correctly
            $updatedApp=Get-AzureADApplication -Filter "DisplayName eq '$displayName'"
            $updatedAppRoles = $updatedApp.AppRoles
            Write-LogDebug "Roles added to application: $updatedAppRoles"
        } else {
            Write-LogDebug "No AppRoles detected"
        }
        Write-LogInfo "Exiting Function Create-EnterpriseApplication"
    }
}

    <#
        .SYNOPSIS
            This function creates group in Azure AD
        .DESCRIPTION
            This function creates group in Azure AD
        .PARAMETER CSVFile
            CSVFile
    #>

function Add-NewAZGroup {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string] $CSVFILEPATH,
        [Parameter(Mandatory=$True)]
        [array] $MandatoryAttr
    )
    process {
        Write-LogInfo "Inside Function Add-NewAZGroup"
        #Test if CSV file is present
        if ((Test-path ($CSVFILEPATH)) -eq $false){
            throw "CSV FILE $CSVFILEPATH not found!"
        }
        #Get number of columns in the header
        $headerColumnCount=Get-HeaderColumnCount -CSVFILEPATH $CSVFilePath
        Write-LogInfo "Number of header columns is >$headerColumnCount<"

        #Import CSV
        $csvdata = Import-Csv -Path $CSVFILEPATH
        if(!($null -eq $csvdata)){
            #Get all headers
            $headers = ($csvdata | Get-Member -MemberType NoteProperty).Name 
            foreach ($row in $csvdata) {
                 #Check for number of columns in the row
                 $noOfColumnsinRow = ($row -split ';').count
                 Write-LogInfo "Number of columns in the row is >$noOfColumnsinRow<"
                 if($headerColumnCount -eq $noOfColumnsinRow){
                     #Checking whether header is in mandatorylist
                     $isValidRow=validateDataInCSV -Row $row -Headers $headers -Mandatoryattr $Mandatoryattr
                     #If validation of the data in the row is successful, process the record
                     Write-LogInfo "IsValidRow is set to >$isValidRow<"
                     if($isValidRow){
                        $DisplayName=$row.DisplayName
                        $GroupDesc=$row.GroupDescription
                        $MailEnabled=([bool]([int]$row.MailEnabled ))
                        $SecurityEnabled=([bool]([int]$row.SecurityEnabled ))
                        $MailNickName=$row.MailNickName
                        New-AzureADGroup -DisplayName $DisplayName -Description $GroupDesc -MailEnabled $MailEnabled -SecurityEnabled $SecurityEnabled -MailNickName $MailNickName
                        Write-LogInfo "Group created successfully >$DisplayName<"
                     }else{
                        Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                    }
                 }else{
                    Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                }
            }
        }
    }
}


    <#
        .SYNOPSIS
            This function creates dynamic group in Azure AD
        .DESCRIPTION
            This function creates dynamic group in Azure AD
        .PARAMETER CSVFile
            CSVFile
    #>

    function Add-NewAZDynamicGroup {
        [CmdletBinding()]
        param(
            [Parameter(Mandatory=$true)]
            [string] $CSVFILEPATH,
            [Parameter(Mandatory=$True)]
            [array] $MandatoryAttr
        )
        process {
            Write-LogInfo "Inside Function NewAZDynamicGroup"
            #Test if CSV file is present
            if ((Test-path ($CSVFILEPATH)) -eq $false){
                throw "CSV FILE $CSVFILEPATH not found!"
            }
            #Get number of columns in the header
            $headerColumnCount=Get-HeaderColumnCount -CSVFILEPATH $CSVFilePath
            Write-LogInfo "Number of header columns is >$headerColumnCount<"
    
            #Import CSV
            $csvdata = Import-Csv -Path $CSVFILEPATH
            if(!($null -eq $csvdata)){
                #Get all headers
                $headers = ($csvdata | Get-Member -MemberType NoteProperty).Name 
                foreach ($row in $csvdata) {
                     #Check for number of columns in the row
                     $noOfColumnsinRow = ($row -split ';').count
                     Write-LogInfo "Number of columns in the row is >$noOfColumnsinRow<"
                     if($headerColumnCount -eq $noOfColumnsinRow){
                         #Checking whether header is in mandatorylist
                         $isValidRow=validateDataInCSV -Row $row -Headers $headers -Mandatoryattr $Mandatoryattr
                         #If validation of the data in the row is successful, process the record
                         Write-LogInfo "IsValidRow is set to >$isValidRow<"
                         if($isValidRow){
                            $DisplayName=$row.DisplayName
                            $GroupDesc=$row.Description
                            $MailEnabled=([bool]([int]$row.MailEnabled ))
                            $SecurityEnabled=([bool]([int]$row.SecurityEnabled ))
                            $MailNickName=$row.MailNickName
                            $GroupType=$row.GroupTypes
                            $MembershipRule=$row.MembershipRule
                            $MembershipRuleProcessingState=$row.MembershipRuleProcessingState
                            New-AzureADMSGroup -DisplayName $DisplayName -Description $GroupDesc -MailEnabled $MailEnabled -MailNickName $MailNickName -SecurityEnabled $SecurityEnabled -GroupTypes $GroupType -membershipRule $MembershipRule -membershipRuleProcessingState $MembershipRuleProcessingState
                            Write-LogInfo "Dynamic Group created successfully >$DisplayName<"
                         }else{
                            Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                        }
                     }else{
                        Write-LogInfo "Skipping the current row due to inaccurate data in >$row<"
                    }
                }
            }
        }
    }


 <#
    .SYNOPSIS
        This function returns the application and role details in the tenant
    .DESCRIPTION
        This function returns the application and role details in the tenant
    .PARAMETER CSVFile
        CSVFile
#>
function Get-ApplicationRoleDetails {
    [CmdletBinding()]
    param(        
        [Parameter(Mandatory=$true,Position=0)]
        [string] $Token,
        [Parameter(Mandatory=$true,Position=1)]
        [string] $InvokeRestMethodURI,
        [Parameter(Mandatory=$false,Position=2)]
        [string] $selectList = "",
        [Parameter(Mandatory=$false,Position=3)]
        [string] $filterList = "",
        [Parameter(Mandatory=$false,Position=4)]
        [int] $pageSize = 0
    )
    process {
        Write-LogInfo "Inside function Get-ApplicationRoleDetails"
        
        try {
            #Forming query parameters
            $anythingToAppend = ""
            if("" -ne $selectList) {
                Write-LogInfo "Found select criteria :: $selectList"
                $anythingToAppend="?"+'$select='+$selectList
            }

            if("" -ne $filterList) {
                Write-LogInfo "Found filterList criteria :: $filterList"
                if( $anythingToAppend.Contains("?") ){
                    $anythingToAppend = $anythingToAppend + "&" + '$filter='+$filterList 
                } else {
                    $anythingToAppend="?"+'$filter='+$filterList
                }
            }

            if(0 -ne $pageSize) {
                Write-LogInfo "Found pageSize criteria :: $pageSize"
                if( $anythingToAppend.Contains("?") ){
                    $anythingToAppend = $anythingToAppend + "&" + '$top='+$pageSize 
                } else {
                    $anythingToAppend="?"+'$top='+$pageSize
                }
            }

            Write-LogInfo "Final anythingToAppend::$anythingToAppend"

            #URL 
            $finalURL = $InvokeRestMethodURI + $anythingToAppend
            Write-LogInfo "Final finalURL::$finalURL"

            #Forming request header
            $headers = Get-Headers -Token $Token

            $isContinue = $true
            $nextLink = ""
            $responseHash = @{}
            while($isContinue) { 
                #Write-LogInfo "here 1" 
                $uri=""
                if( "" -ne $nextLink ) {
                    $uri = $nextLink
                } else { #only for first iteration
                    $uri = $finalURL
                }
                
                Write-LogInfo "uri::$uri"

                [array]$response = Invoke-WebRequest -Uri $uri -Method 'GET' -ContentType "application/json" -Headers $headers | ConvertFrom-Json

                $nextLink = $response.'@odata.nextLink'
                Write-LogInfo "Next link retrieved::$nextLink"

                #Checking if more iterations are required to fetch data
                if( $null -eq $nextLink ) {
                    $isContinue=$false
                }

                #Checking if any records in response
                If ($response.value.Count -eq 0) { 
                    Write-Host "No records found - exiting!"; 
                    break 
                }

                $response.value.ForEach( {
                    #Write-LogInfo "here 1.5"
                    $appName = $_.displayName
                    $appRoles = $_.appRoles
                    #Write-LogInfo "here 1.51"
                        
                    If ($appRoles.Count -eq 0) { 
                        Write-Host "No app roles found!";                                         
                    } else {                    
                        $appRoles.ForEach( {
                            #Write-LogInfo "here 1.52"
                            $appRoleName = $_.displayName
                            $appRoleId = $_.id
                            Write-LogInfo "appName::$appName"
                            Write-LogInfo "appRoleId::$appRoleId"
                            Write-LogInfo "appRoleName::$appRoleName"
                            $responseHash.Add($appName+"|"+$appRoleId, $appRoleName) 
                        })                    
                    } 
                                              
                } )
            }
            return $responseHash
        } catch {
            Write-LogError "StatusCode:" $_.Exception.Response.StatusCode.value__ 
            Write-LogError "StatusDescription:" $_.Exception.Response.StatusDescription
            Write-LogError "Response:" $_.Exception.Response
            Write-LogError "Response:" $_.
            $response=$null
            break
        }

    }
}

function Get-Headers {
    [CmdletBinding()]
    [OutputType('System.Collections.Generic.Dictionary[[String],[String]]')]
    param(
        [Parameter(Mandatory=$true,Position=0)]
        [string] $Token
    )
    process {
        $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
        $headers.Add("Content-Type", "application/json")
        $headers.Add("Authorization", "Bearer $Token")
        return $headers
    }
}


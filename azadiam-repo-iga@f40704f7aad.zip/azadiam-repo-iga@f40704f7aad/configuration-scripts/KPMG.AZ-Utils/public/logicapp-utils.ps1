<#
    .SYNOPSIS
        Deploy logic apps to Azure AD
    .DESCRIPTION
        This is the script to deploy logic apps in Azure AD using ARM template.
    .PARAMETER ConfigFile
        JSON containing configuration of alert that is to be created. This element exists in the config.json 
        file as logic-application-management.   
    .EXAMPLE
        1. To Execute the script in main-forest, DC1
			.\CreateAzLogicApp.ps1 -logicAppConfig $logicAppConfigJson
#>
function Create-AzLogicApplication {
    [CmdletBinding()]
Param(
    [Parameter(Mandatory = $False, HelpMessage = "Enter the configuration file that has relevant configuration.", Position = 0)]
    [PSCustomObject]$logicAppConfig   
)
    try {    
        Write-LogInfo "Entering CreateAzLogicApp"

        #Default exit code
        $LASTEXITCODE = 1

        #Read config types
        $LogicAppKeyNames = $logicAppConfig | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
        if($null -ne $LogicAppKeyNames) {
            Write-LogInfo "Validating Logic Application configurations"

            $AZLogicApp="logic-apps-config"
            if($LogicAppKeyNames -contains $AZLogicApp) {
                $AZLogicAppsArray=$logicAppConfig.$AZLogicApp
            }
            If($null -eq $AZLogicAppsArray){
                $LASTEXITCODE = 2
                Throw "Selected $AZLogicApp is not configured in JSON properties file"
            }
        } else {
            $LASTEXITCODE = 3
            Throw "Logic app deployment configuration not found"
        }
        
        # Processing logic app templates and parameter files
        foreach($i in 0..($AZLogicAppsArray.Count-1)) {
            try {
                $increment_count=($i+1)
                Write-LogInfo "Logic App Iteration: $increment_count" 

                #Validating configurations for individual logic apps
                If($null -eq $AZLogicAppsArray[$i].resourceGroupName){
                    $LASTEXITCODE = 4
                    Throw "ResourceGroupName is not configured in JSON properties file"
                }
                $log_var=$AZLogicAppsArray[$i].resourceGroupName
                Write-LogDebug "Resource Group Name: $log_var"

                If($null -eq $AZLogicAppsArray[$i].templateFile) {
                    $LASTEXITCODE = 5
                    Throw "TemplateFile is not configured in JSON properties file"
                }
                $log_var=$AZLogicAppsArray[$i].templateFile
                Write-LogDebug "Template File Name: $log_var"

                If($null -eq $AZLogicAppsArray[$i].parameterFile){
                    $LASTEXITCODE = 6
                    Throw "ParameterFile is not configured in JSON properties file"
                }
                $log_var=$AZLogicAppsArray[$i].parameterFile
                Write-LogDebug "Parameter File Name: $log_var"

                If($null -eq $AZLogicAppsArray[$i].logicAppName){
                    $LASTEXITCODE = 7
                    Throw "logicAppName is not configured in JSON properties file"
                }
                $log_var=$AZLogicAppsArray[$i].logicAppName
                Write-LogDebug "logic App Name : $log_var"

                If($null -eq $AZLogicAppsArray[$i].isServicePrincipal){
                    $LASTEXITCODE = 8
                    Throw "isServicePrincipal is not configured in JSON properties file"
                }
                $log_var=$AZLogicAppsArray[$i].isServicePrincipal
                Write-LogDebug "isServicePrincipal : $log_var"

                $results = New-AzResourceGroupDeployment -ResourceGroupName $AZLogicAppsArray[$i].resourceGroupName -TemplateFile $AZLogicAppsArray[$i].templateFile -TemplateParameterFile $AZLogicAppsArray[$i].parameterFile 
                
                $log_var=$AZLogicAppsArray[$i].logicAppName
                Write-LogDebug "Created logic app: $log_var"

                # Add service principal permissions for Graph API
                if( $AZLogicAppsArray[$i].isServicePrincipal -eq $true ) {
                    Write-LogInfo "Adding Service Principal permissions"
                    $log_var=$AZLogicAppsArray[$i].servicePrincipalPermissions
                    Write-LogDebug "Service Principal permissions to be added: $log_var"

                    $searchLAResult = Get-AzResource -ResourceGroupName $AZLogicAppsArray[$i].resourceGroupName -Name $AZLogicAppsArray[$i].logicAppName -ExpandProperties

                    $log_var=$searchLAResult.Identity.principalId
                    Write-LogDebug "Logic app service principal id: $log_var"
                    
                    Add-ServicePrincipal-GraphAPIPermissions -principalId $searchLAResult.Identity.principalId -permissionsList $AZLogicAppsArray[$i].servicePrincipalPermissions
                }

                $i++
            } catch [System.Exception] {
                Write-LogInfo "Inside catch block."
                If (($LASTEXITCODE -eq $null) -or ($LASTEXITCODE -eq 0)) {
                    $LASTEXITCODE = 1
                }
                $ErrorMessage = $_.Exception.Message
                Write-LogError "Exit Code :: $LASTEXITCODE | Message :: $ErrorMessage"
            }
        }
    } catch [System.Exception] {
        Write-LogInfo "Inside catch block."
        If (($LASTEXITCODE -eq $null) -or ($LASTEXITCODE -eq 0)) {
            $LASTEXITCODE = 1
        }
        $ErrorMessage = $_.Exception.Message
        Write-LogError "Exit Code :: $LASTEXITCODE | Message :: $ErrorMessage"
    } finally {
        Write-LogInfo "Inside finally block."
        Write-LogInfo "Script finished with exit code :: $LASTEXITCODE"
    }
}
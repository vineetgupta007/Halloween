function Create-PrejoinerWorkflow {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, Position = 0)]
        [PSCustomObject] $CreateWorkflow,
        [Parameter(Mandatory = $true, Position = 1)]
        [string] $Token,
        [Parameter(Mandatory = $true, Position = 2)]
        [string] $InvokeRestMethodURI
    )
    process {
        Write-LogInfo "Inside Function Create-prejoinerWorkflow"
        try {
            #check if Catalogs exists
            #$ReviewID = Get-AccessReviewID -Token $Token -ReviewName $RevName -InvokeRestMethodURI $InvokeRestMethodURI
            $headers = Get-Headers -Token $Token
                
            Write-LogInfo "CreateWorkflow=$CreateWorkflow"
            #$rawBody = $CreateReviewProps | Out-String | ConvertFrom-Json
            #Write-LogInfo "rawBody=$rawBody"

            #$Body = $rawBody.replace(";", ",")
            #$finalBody = $Body | ConvertTo-Json
            $Body = $CreateWorkflow.'workflowBody' | ConvertTo-Json -Depth 100
            #$finalBody = $Body.replace("\","");
                
            Write-LogInfo "WorkflowBody=$Body"
            try {
                $response = Invoke-RestMethod $InvokeRestMethodURI -Method 'POST' -Headers $headers -Body $Body;
                $workflowID = $response.id
                Write-LogInfo "Workflow created successfully::$workflowID"
            }
            catch {
                Write-LogError "StatusCode:" $_.Exception.Response.StatusCode.value__ 
                Write-LogError "StatusDescription:" $_.Exception.Response.StatusDescription
                Write-LogError "Response:" $_.Exception.Response
                Write-LogError "Response:" $_.
                $workflowID = $null
                break
            }
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
        Write-LogInfo "Exiting Function Create-prejoinerWorkflow"
    }
}
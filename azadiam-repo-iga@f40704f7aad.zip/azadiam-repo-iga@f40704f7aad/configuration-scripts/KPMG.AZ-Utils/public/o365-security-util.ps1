﻿<#
    .SYNOPSIS
        These functions are used for generating different type of reports for Office 355 Security Features
    .DESCRIPTION
        This utilty contains all the functions that are used for generating reports for security features from Office 365 and uploading them to LAWS
#>
Function Get-Creds{
    [CmdletBinding()]
    [OutputType([PSCredential])]
    Param(
        [Parameter(Mandatory=$True,Position=0)]
        [PSCustomObject] $LoginProps
    )
    Process{
        Write-LogInfo "Inside Function Get-Creds"
        Write-LogDebug "Input LoginProps :: $LoginProps"
        $Credential = $null
        $LoginConnProps = $null
        try{
            #check for connection type
            $ConnType = $LoginProps.'connection-type'
            If($ConnType -eq 'user-credential'){
                # Connect to Azure AD
                $LoginConnProps=$LoginProps.'az-ad-user-login'
                If($null -eq $LoginConnProps){
                    Throw "Login configuration is not configured in JSON properties file"
                }
                $LPwd=Convert-PasswordToSecureString -Password $LoginConnProps.password
                $Credential = Get-PSCredentials -Username $LoginConnProps.username -Password $LPwd
            } Else {
                Write-LogError "Invalid connection type :: $ConnType"
            }
         }

       catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
         Write-LogInfo "Exiting Function Get-Creds"
         return $Credential
    }
}

function Connect-EXOnline {
    [CmdletBinding()]   
    Param([PSCustomObject] $LoginProps     
    )
    Process { 
        Write-LogInfo "Inside Function Connect-EXOnline"
        Write-LogDebug "Input LoginProps :: $LoginProps"     
        try {  
            $credential = Get-Creds -LoginProps $LoginProps           
                       
            $session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://ps.compliance.protection.outlook.com/powershell-liveid/ -Credential $credential -Authentication "Basic" -AllowRedirection
            Import-PSSession $Session -ErrorAction Stop  -AllowClobber -DisableNameChecking
          
            $LASTEXITCODE = 0
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
            $allResults = $null
        }      
        Write-LogInfo "Exiting Function Connect-EXOnline"
        return $allResults
    }
    
}
function Get-SensitivityLabelSummaryDetails {
    [CmdletBinding()]
    [OutputType([System.Array])]      
        Param([PSCustomObject] $mcastoken,
        [PSCustomObject] $baseURL,
        [PSCustomObject] $mcasApp  
    )
    Process {
        Write-LogInfo "Inside Function Get-SensitivityLabelSummaryDetails"
        Write-LogDebug "Input MCAS Token :: $mcastoken"     
        Write-LogDebug "Input baseURL :: $baseURL"
        Write-LogDebug "Input mcasApp :: $mcasApp"
        try {
                $allResults = @()
                #Deafult exit code
                $LASTEXITCODE = 1                                             
                
                $labelPolicyJson =""
                $labelJson=""
                $jsonArray =""
                $json=""
                Write-LogInfo "Calling Get-LabelPolicy"         
                $labelPolicyJson = Get-LabelPolicy | ConvertTo-json               
                $jsonArray = $labelPolicyJson                          
                $json = $jsonArray.ToString().Replace("Value", "_Value") | ConvertFrom-Json
                $Enabled = ""
                $Encrypt_Disabled=""
                $aipEnabled = Get-AipService                    
                $labelJson = Get-Label | ConvertTo-Json                           
                $jsonArray1 = ConvertFrom-Json $labelJson

                foreach ($item in $json) {
                    $PolicyActive = $item.Enabled

                    if($null -ne $PolicyName){                        
                        $PolicyName += ", " + $item.Name
                    }
                    else {                        
                        $PolicyName= $item.Name
                    }
                   
                    foreach ($subItem in $item.Labels) {                                                                 
                        foreach($i in 0..($jsonArray1.Count-1))                       
                        {                                                                               
                            if($subItem -eq $jsonArray1[$i].Name)
                            {
                                if($null -ne $IncludedLabels){
                                    $LabelName = $jsonArray1[$i].Name
                                    $IncludedLabels += ", " + $LabelName
                                }
                                else {
                                    $LabelName = $jsonArray1[$i].Name
                                    $IncludedLabels= $LabelName
                                }

                                if($null -ne $jsonArray1[$i].Conditions -and $jsonArray1[$i].Conditions -ne ""){

                                    if($null -ne $AutoLabels){                                    
                                        $AutoLabels += ", " + $jsonArray1[$i].Name
                                    }
                                    else {                                    
                                        $AutoLabels= $jsonArray1[$i].Name
                                    }
                                }

                                $jsonArray2 = $jsonArray1[$i].LabelActions | ConvertFrom-Json
                             
                                foreach ($item1 in $jsonArray2) {
                                    $Type= $item1.Type
                                    $SubType= $item1.SubType
                                    $Settings = $item1.Settings

                                    if($Type -eq "Encrypt"){                                                              
                                        $Settings.GetEnumerator() | ForEach-Object {                                           
                                            if ($_.Key -eq "disabled") {                                                                                               
                                                
                                                if($_.Value -ne $true){
                                                    if($null -ne $Encrypt){
                                                        $Encrypt+= ", " + $LabelName 
                                                    }
                                                    else {
                                                        $Encrypt= $LabelName
                                                    }
                                                    
                                                }                                                
                                            }
                                        }                                  
                                    }                                
                                
                                    if($Type -eq "applywatermarking"){        
                                                                  
                                        $Settings.GetEnumerator() | ForEach-Object {                                            
                                            if ($_.Key -eq "disabled") {                                                                                                
                                                if($_.Value -ne $true){
                                                    if($null -ne $Watermarking){
                                                        $Watermarking+=", " + $LabelName
                                                    }
                                                    else {
                                                        $Watermarking= $LabelName
                                                    }
                                                }                                                                                             
                                            }                                           
                                        }                                  
                                    }                                                                                                 
                                }
                            }                                                             
                        }           
                    }
                }                         

                $response= Execute-MCASAPI -mcastoken $mcastoken -baseURL $baseURL             
                $gAction=$null 
                $gLocation=$null
                $allResults1= @()               
               
                foreach($i in $response){
                    If($i.PolicyType -eq 'FILE' -and $i.Enabled -eq $true ){                                           
                       foreach($cFilter in $i.consoleFilters){           
                          if($cFilter -like '*fileLabels*'){
                               if($null -ne $ThirdParty){
                                   $ThirdParty += ", " + $i.Name                                   
                               }
                               else {
                                   $ThirdParty = $i.Name                                    
                               }    
                          }                       
                        }                        
                    }
                }
                foreach($i in $response){
                    If($i.PolicyType -eq 'FILE' -and $i.Enabled -eq $true ){        
                       foreach($action in $i.actions)
                       {
                           $cols = $action[0].psobject.properties.name                         
                        }                      
                    }                                     
                }     
                    $cols=$cols|Select-Object -Unique
                    foreach ($item in $cols) {
                        $result=@{
                            'LocationType'= "MCAS";
                            'Location'= $mcasApp.$item;                            
                            'Policy'= $ThirdParty;                    
                            'Labels' = $null;                                
                            'Encryption' = $null;
                            'Watermarking' = $null;
                            'AutoLabeling' = $null;                                             
                        }
    
                        $results = New-Object PSObject -Property $result
                        $allResults += $results    
                    }              
                
                $result=@{
                    'LocationType'= "O365";
                    'Location' = "SharePoint";
                    'Policy'=$PolicyName;
                    'Labels' = $IncludedLabels;                                
                    'Encryption' = $Encrypt;
                    'Watermarking' = $Watermarking;
                    'AutoLabeling' = $AutoLabels;
                    'GovernanceLocation' = $null;  
                    'GovernanceAction'=$null;                                       
                }

                $results = New-Object PSObject -Property $result
                $allResults += $results 

                $result=@{
                    'LocationType'= "O365";
                    'Location' = "OneDrive";
                    'Policy'=$PolicyName;
                    'Labels' = $IncludedLabels;                                
                    'Encryption' = $Encrypt;
                    'Watermarking' = $Watermarking;
                    'AutoLabeling' = $AutoLabels;
                    'GovernanceLocation' = $null;   
                    'GovernanceAction'=$null;                  
                }

                $results = New-Object PSObject -Property $result
                $allResults += $results 

                $result=@{
                    'LocationType'= "O365";
                    'Location' = "Exchange";
                    'Policy'=$PolicyName;
                    'Labels' = $IncludedLabels;                                
                    'Encryption' = $Encrypt;
                    'Watermarking' = $Watermarking;
                    'AutoLabeling' = $AutoLabels;
                    'GovernanceLocation' = $null; 
                    'GovernanceAction'=$null;                  
                }

                $results = New-Object PSObject -Property $result
                $allResults += $results 

                $result=@{
                    'LocationType'= "O365";
                    'Location' = "Teams";
                    'Policy'=$PolicyName;
                    'Labels' = $IncludedLabels;                                
                    'Encryption' = $Encrypt;
                    'Watermarking' = $Watermarking;
                    'AutoLabeling' = $AutoLabels;
                    'GovernanceLocation' = $null;  
                    'GovernanceAction'=$null;                   
                }

                $results = New-Object PSObject -Property $result
                $allResults += $results 

                $result=@{
                    'LocationType'= "O365";
                    'Location' = "Devices";
                    'Policy'=$PolicyName;
                    'Labels' = $IncludedLabels;                                
                    'Encryption' = $Encrypt;
                    'Watermarking' = $Watermarking;
                    'AutoLabeling' = $AutoLabels;
                    'GovernanceLocation' = $null; 
                    'GovernanceAction'=$null;                    
                }

                $results = New-Object PSObject -Property $result
                $allResults += $results            

                if($null -ne $allResults){
                    $LASTEXITCODE = 0
                }              
            }
            catch [System.Exception] {
                $ErrorMessage = $_.Exception.Message
                Write-LogError "Message ::  $ErrorMessage"
                $allResults = $null
            }          
            Write-LogInfo "Existing Function Get-SensitivityLabelSummaryDetails"
            return $allResults
        }    
    }
function Get-DLPCompliancePolicySummary {
    [CmdletBinding()]
    [OutputType([System.Array])]       
    Param(
            [Parameter(Mandatory = $false, Position = 0)]
            [string] $mcastoken,
            [Parameter(Mandatory = $false, Position = 1)]
            [string] $baseURL,
            [PSCustomObject] $mcasApp 
    )
    Process {
        Write-LogInfo "Inside Function Get-DLPCompliancePolicySummary" 
        Write-LogDebug "Input MCAS Token :: $mcastoken"     
        Write-LogDebug "Input Base URL :: $baseURL"     
        Write-LogDebug "Input MCAS App :: $mcasApp"     
        try {
                $allResults = @()
                #Deafult exit code
                $LASTEXITCODE = 1                                                 
                                
                $json =""
                $jsonArray =""
                Write-Debug "Calling Get-DLPCompliancePolicy"
                $dlpCompliancePolicy= Get-DlpCompliancePolicy | ConvertTo-json
                $jsonArray = $dlpCompliancePolicy
                
                $Enabled=""
                $PolicyName=""

                $SharePoint=$null
                $OneDrive=$null
                $Exchange=$null
                $Teams=$null
                $Devices=$null

                $json = $jsonArray.ToString().Replace("Value", "_Value") | ConvertFrom-Json
                
                foreach ($item in $json) {                    
                    
                    #SharePoint
                    Write-LogInfo "Get DLP information for Sharepoint location"
                    if($null -ne $item.SharePointLocation -and $item.SharePointLocation -ne ""){                      
                        if($null -ne $SPolicyName){
                            $SPolicyName = $item.Name
                            $SharePoint += ", " + $SPolicyName
                        }
                        else {
                            $SPolicyName = $item.Name
                            $SharePoint = $SPolicyName
                        }                   
                        $rules = Get-DLPComplianceRule -Policy $item.Name                                                                    
                        foreach ($rl in $rules) {
                            if($null -ne $sname){
                                $sname = $rl.Name
                                $SRuleName += ", " + $sname
                            }
                            else {
                                $sname = $rl.Name
                                $SRuleName = $sname
                            }
                            $oInfoType=$null
                            if($null -ne $rl.ContentContainsSensitiveInformation.name){
                                $sInfoType = $rl.ContentContainsSensitiveInformation.name                            
                            }

                            if($null -eq $sInfoType){
                                if($null -ne $rl.ContentContainsSensitiveInformation.groups.sensitivetypes.name){
                                    $sInfoType = $rl.ContentContainsSensitiveInformation.groups.sensitivetypes.name                            
                                }
                            }                          

                            if($null -ne $rl.ContentContainsSensitiveInformation.groups.labels.name){
                                $sLabel = $rl.ContentContainsSensitiveInformation.groups.labels.name                            
                            }                                        
                            
                            if($null -ne $sc){
                                $sc = $sInfoType
                                $sptype += ", " + $sc                                                             
                            }                       
                            else {
                                $sc = $sInfoType
                                $sptype = $sc                          
                            }

                            if($null -ne $spILabel){
                                $sl = $sLabel
                                $spILabel += $sl                                                             
                            }                       
                            else {
                                $sl = $sLabel
                                $spILabel = $sl                          
                            }                                       
                        }
                    }                    

                    #MSTeams
                    Write-LogInfo "Get DLP information for MSTeams location"
                    if($null -ne $item.TeamsLocation -and $item.TeamsLocation -ne ""){
                        if($null -ne $tPolicyName){
                            $tPolicyName = $item.Name
                            $Teams += ", " + $tPolicyName
                        }
                        else {
                            $tPolicyName = $item.Name
                            $Teams = $tPolicyName
                        }
                        $rules = Get-DLPComplianceRule -Policy $item.Name                                                                       
                        foreach ($rl in $rules) {
                            if($null -ne $tname){
                                $tname = $rl.Name
                                $tRuleName += ", " + $tname
                            }
                            else {
                                $tname = $rl.Name
                                $tRuleName = $tname
                            }
                            $oInfoType=$null
                            if($null -ne $rl.ContentContainsSensitiveInformation.name){
                                $tInfoType = $rl.ContentContainsSensitiveInformation.name                            
                            }

                            if($null -eq $tInfoType){
                                if($null -ne $rl.ContentContainsSensitiveInformation.groups.sensitivetypes.name){
                                    $tInfoType = $rl.ContentContainsSensitiveInformation.groups.sensitivetypes.name                            
                                }
                            }    
                           
                            if($null -ne $rl.ContentContainsSensitiveInformation.groups.labels.name){
                                $tLabel = $rl.ContentContainsSensitiveInformation.groups.labels.name                            
                            }                            

                            if($null -ne $tmc){
                                $tmc = $tInfoType
                                $tmtype += ", " + $tmc                                                             
                            }                       
                            else {
                                $tmc = $tInfoType
                                $tmtype = $tmc                          
                            }
                            
                            if($null -ne $tmILabel){
                                $tl = $tLabel
                                $tmILabel += $tl                                                             
                            }                       
                            else {
                                $tl = $tLabel
                                $tmILabel = $tl                          
                            }
                        }
                    }

                    #OneDrive
                    Write-LogInfo "Get DLP information for OneDrive location"
                    if($null -ne $item.OneDriveLocation -and $item.OneDriveLocation -ne ""){
                        if($null -ne $oPolicyName){
                            $oPolicyName = $item.Name
                            $OneDrive += ", " + $oPolicyName
                        }
                        else {
                            $oPolicyName = $item.Name
                            $OneDrive = $oPolicyName
                        }
                        $rules = Get-DLPComplianceRule -Policy $item.Name                                                                        
                        foreach ($rl in $rules) {
                            if($null -ne $oname){
                                $oname = $rl.Name
                                $oRuleName += ", " + $oname
                            }
                            else {
                                $oname = $rl.Name
                                $oRuleName = $oname
                            }
                            $oInfoType=$null
                            if($null -ne $rl.ContentContainsSensitiveInformation.name){
                                $oInfoType = $rl.ContentContainsSensitiveInformation.name                            
                            }

                            if($null -eq $oInfoType){
                                if($null -ne $rl.ContentContainsSensitiveInformation.groups.sensitivetypes.name){
                                    $oInfoType = $rl.ContentContainsSensitiveInformation.groups.sensitivetypes.name                            
                                }
                            }                              

                            if($null -ne $rl.ContentContainsSensitiveInformation.groups.labels.name){
                                $oLabel = $rl.ContentContainsSensitiveInformation.groups.labels.name                            
                            }
                                                 
                                                    
                            if($null -ne $oc){
                                $oc = ", " + $oInfoType
                                $otype += $oc                                                             
                            }                       
                            else {
                                $oc = $oInfoType
                                $otype = $oc                          
                            }

                            if($null -ne $oILabel){
                                $ol = $oLabel
                                $oILabel += $ol                                                             
                            }                       
                            else {
                                $ol = $oLabel
                                $oILabel = $ol                          
                            }                                       
                        
                        }
                    }

                    #Exchange
                    Write-LogInfo "Get DLP information for Exchange location"
                    if($null -ne $item.ExchangeLocation -and $item.ExchangeLocation -ne ""){
                        if($null -ne $ePolicyName){
                            $ePolicyName = $item.Name
                            $Exchange += ", " + $ePolicyName
                        }
                        else {
                            $ePolicyName = $item.Name
                            $Exchange = $ePolicyName
                        }
                        $rules = Get-DLPComplianceRule -Policy $item.Name
                                                                                             
                        foreach ($rl in $rules) {
                            if($null -ne $exname){
                                $exname = $rl.Name
                                $exRuleName += ", " + $exname
                            }
                            else {
                                $exname = $rl.Name
                                $exRuleName = $exname
                            }
                            $exInfoType=$null
                            if($null -ne $rl.ContentContainsSensitiveInformation.name){
                                $exInfoType = $rl.ContentContainsSensitiveInformation.name                            
                            }
                            
                            if($null -eq $exInfoType){
                                if($null -ne $rl.ContentContainsSensitiveInformation.groups.sensitivetypes.name){
                                    $exInfoType = $rl.ContentContainsSensitiveInformation.groups.sensitivetypes.name                            
                                }
                            }      

                            if($null -ne $rl.ContentContainsSensitiveInformation.groups.labels.name){
                                $exLabel = $rl.ContentContainsSensitiveInformation.groups.labels.name                            
                            }
                                             
                            
                            if($null -ne $exc){
                                $exc = ", " + $exInfoType
                                $extype += $exc                                                             
                            }                       
                            else {
                                $exc = $exInfoType
                                $extype = $exc                          
                            }

                            if($null -ne $exILabel){
                                $exl = $exLabel
                                $exILabel += $exl                                                             
                            }                       
                            else {
                                $exl = $exLabel
                                $exILabel = $exl                          
                            }                                                    
                        }
                    }

                    #Endpoint Device
                    Write-LogInfo "Get DLP information for Endpoint device location"
                    if($null -ne $item.EndpointDlpLocation -and $item.EndpointDlpLocation -ne ""){
                        
                        if($null -ne $edPolicyName){
                            $edPolicyName = $item.Name
                            $Devices += ", " + $edPolicyName
                        }
                        else {
                            $edPolicyName = $item.Name
                            $Devices = $edPolicyName
                        }

                        $rules = Get-DLPComplianceRule -Policy $item.Name                                               

                        foreach ($rl in $rules) {    
                            if($null -ne $edRuleName){
                                $edRuleName += ", " +$rl.Name
                            }
                            else {
                                $edRuleName = $rl.Name
                            }    
                                                   
                            $edInfoType=$null
                            $edLabel=$null
                            if($null -ne $rl.ContentContainsSensitiveInformation.name){
                                $edInfoType = $rl.ContentContainsSensitiveInformation.name                            
                            }
                            
                            if($null -eq $edInfoType){
                                if($null -ne $rl.ContentContainsSensitiveInformation.groups.sensitivetypes.name){
                                    $edInfoType = $rl.ContentContainsSensitiveInformation.groups.sensitivetypes.name                            
                                }
                            }                                         

                            if($null -ne $rl.ContentContainsSensitiveInformation.groups.labels.name){
                                $edLabel = $rl.ContentContainsSensitiveInformation.groups.labels.name                            
                            }
                           
                            if($null -ne $edtype){
                                $edc = ", " + $edInfoType
                                $edtype +=  $edc                                                             
                            }                       
                            else {
                                $edc =  $edInfoType
                                $edtype = $edc                          
                            }                            
                            if($null -ne $edILabel){
                                $edl = $edLabel
                                $edILabel += $edl                                                             
                            }                       
                            else {
                                $edl = $edLabel
                                $edILabel = $edl                          
                            }                                                
                        }
                    }                
            }
            Write-LogInfo "Calling Execute-MCASAPI function to get policy details from Cloud App Security"
            $response= Execute-MCASAPI -mcastoken $mcastoken -baseURL $baseURL             
                $gAction=$null 
                $gLocation=$null
                             
                foreach($i in $response){
                    If($i.PolicyType -eq 'FILE' -and $i.Enabled -eq $true ){      
                        if($null -ne $ThirdParty){
                            $ThirdParty += ", " + $i.Name                                   
                        }
                        else {
                            $ThirdParty = $i.Name                                    
                        }
                    }
                }
                foreach($i in $response){
                    If($i.PolicyType -eq 'FILE' -and $i.Enabled -eq $true ){        
                        foreach($action in $i.actions)
                        {
                            $cols = $action[0].psobject.properties.name                         
                        }                      
                    }                                     
                }     
                $cols=$cols|Select-Object -Unique
                foreach ($item in $cols) {
                    $result=@{
                        'LocationType'= "MCAS";                       
                        'Location' = $mcasApp.$item;
                        'Policy'=$ThirdParty;  
                        'Rule'="";
                        'CSensitivityInfoType'="";
                        'CSensitivityLabel'="";                                                 
                    }
            
                    $results = New-Object PSObject -Property $result
                    $allResults += $results    
                }                                                             
                              
                $result=@{
                    'LocationType'= "O365";
                    'Location' = "SharePoint";
                    'Policy'=$SharePoint;
                    'Rule'=$SRuleName;
                    'CSensitivityInfoType'=$sptype | Out-String;
                    'CSensitivityLabel'=$spILabel | Out-String;                                     
                }

                $results = New-Object PSObject -Property $result
                $allResults += $results 

                $result=@{
                    'LocationType'= "O365";
                    'Location' = "OneDrive";
                    'Policy'=$OneDrive;
                    'Rule'=$oRuleName;
                    'CSensitivityInfoType'=$otype | Out-String;
                    'CSensitivityLabel'=$oILabel | Out-String;                                              
                }

                $results = New-Object PSObject -Property $result
                $allResults += $results 

                $result=@{
                    'LocationType'= "O365";
                    'Location' = "Exchange";
                    'Policy'=$Exchange;   
                    'Rule'=$exRuleName;
                    'CSensitivityInfoType'=$extype | Out-String;
                    'CSensitivityLabel'=$exILabel | Out-String;                                           
                }

                $results = New-Object PSObject -Property $result
                $allResults += $results 

                $result=@{
                    'LocationType'= "O365";
                    'Location' = "Teams";
                    'Policy'=$Teams;     
                    'Rule'=$tRuleName;
                    'CSensitivityInfoType'=$tmtype | Out-String;
                    'CSensitivityLabel'=$tmILabel| Out-String;                                        
                }

                $results = New-Object PSObject -Property $result
                $allResults += $results 

                $result=@{
                    'LocationType'= "O365";
                    'Location' = "Devices";
                    'Policy'=$Devices;   
                    'Rule'=$edRuleName;
                    'CSensitivityInfoType'=$edtype | Out-String;
                    'CSensitivityLabel'=$edILabel | Out-String;                                       
                }

                $results = New-Object PSObject -Property $result
                $allResults += $results            

                 if($null -ne $allResults){
                    $LASTEXITCODE = 0
                }                       
            }
            catch [System.Exception] {
                $ErrorMessage = $_.Exception.Message
                Write-LogError "Message ::  $ErrorMessage"
                $allResults = $null
            }          
            Write-LogInfo "Exiting Function Get-DLPCompliancePolicySummary"           
            return $allResults
        }    
    }
function Get-DataRetentionPolicySummary {
    [CmdletBinding()]
    [OutputType([System.Array])]  
    Param(     
    )
    Process {
        Write-LogInfo "Inside Function Get-DataRetentionPolicySummary"        
        try {                 
       
        $allResults = @()        
        $policies = Get-RetentionCompliancePolicy -DistributionDetail | ConvertTo-json       
        $jsonArray = $policies                            
 
        $policies1 = $jsonArray.ToString().Replace("Value", "_Value") | ConvertFrom-Json        
        
         foreach($t in $policies1)
         {             
             $PolicyName = $t.Name
             $Guid=$t.Guid
             $Enabled = $t.Enabled
             $rules = Get-RetentionComplianceRule -Policy $Guid             
             $tagList = [String]::Empty
             foreach($rule in $rules)
             {
                 if ([String]::IsNullOrEmpty($rule.PublishComplianceTag) -eq $False)
                 {
                     $tName = $rule.PublishComplianceTag.Split(',')[1]
                     $tagList = [String]::Concat($tagList, $tName, ",")
                 }
             
                 if (![String]::IsNullOrEmpty($tagList))
                 {
                     $tagList = $tagList.Substring(0, $tagList.LastIndexOf(','))
                 }
             }
              #SharePoint
              Write-LogInfo "Get Data Retention information for SharePoint location"
              if($null -ne $t.SharePointLocation -and $t.SharePointLocation -ne ""){                      
                 if($null -ne $SPolicyName){
                     $SPolicyName = $t.Name
                     $SharePoint += ", " + $SPolicyName
                     $SLabels += "," + $tagList
                 }
                 else {
                     $SPolicyName = $t.Name
                     $SharePoint = $SPolicyName
                     $SLabels = $tagList
                 }
             }                    
 
             #MSTeams
             Write-LogInfo "Get Data Retention information for MSTeams location"
             if($null -ne $t.TeamsPolicy -and $t.TeamsPolicy -ne "" -and $t.TeamsPolicy -ne $False){
                 if($null -ne $tPolicyName){
                     $tPolicyName = $t.Name
                     $Teams += ", " + $tPolicyName
                     $tLabels += "," + $tagList
                 }
                 else {
                     $tPolicyName = $t.Name
                     $Teams = $tPolicyName
                     $tLabels = $tagList 
                 }
             }
 
             #OneDrive
             if($null -ne $t.OneDriveLocation -and $t.OneDriveLocation -ne ""){
                 if($null -ne $oPolicyName){
                     $oPolicyName = $t.Name
                     $OneDrive += ", " + $oPolicyName
                     $oLabels += "," + $tagList
                 }
                 else {
                     $oPolicyName = $t.Name
                     $OneDrive = $oPolicyName
                     $oLabels = $tagList
                 }
             }
 
             #Exchange
             Write-LogInfo "Get Data Retention information for Exchange location"
             if($null -ne $t.ExchangeLocation -and $t.ExchangeLocation -ne ""){
                 if($null -ne $ePolicyName){
                     $ePolicyName = $t.Name
                     $Exchange += ", " + $ePolicyName
                     $eLabels += "," + $tagList
                 }
                 else {
                     $ePolicyName = $t.Name
                     $Exchange = $ePolicyName
                     $eLabels = $tagList
                 }
             }
 
             #Modern Groups
             Write-LogInfo "Get Data Retention information for Modern Groups location"
             if($null -ne $t.ModernGroupLocation -and $t.ModernGroupLocation -ne ""){
                 if($null -ne $edPolicyName){
                     $edPolicyName = $t.Name
                     $mgGroup += ", " + $edPolicyName
                     $mgLabels += "," + $tagList
                 }
                 else {
                     $edPolicyName = $t.Name
                     $mgGroup = $edPolicyName
                     $mgLabels = $tagList
                 }
             }
                        
             $result=@{
                 'Location' = "SharePoint";
                 'Policy' = $SharePoint;
                 'Labels' = $SLabels;                    
             }
 
             $results = New-Object PSObject -Property $result
             $allResults += $results 
                        
             $result=@{
                 'Location' = "OneDrive";
                 'Policy' = $OneDrive;  
                 'Labels' = $oLabels;                  
             }
            
             $results = New-Object PSObject -Property $result
             $allResults += $results
            
             $result=@{
                 'Location' = "Exchange";
                 'Policy' = $Exchange;    
                 'Labels' = $eLabels;                
             }           
                        
             $results = New-Object PSObject -Property $result
             $allResults += $results
           
             $result=@{
                 'Location' = "Teams";
                 'Policy' = $Teams;                    
                 'Labels' = $tLabels;
             } 
 
             $results = New-Object PSObject -Property $result
             $allResults += $results 
 
             $result=@{
                 'Location' = "Office 365 Groups";
                 'Policy' = $mgGroup;                    
                 'Labels' = $mgLabels;
             }
 
             $results = New-Object PSObject -Property $result
             $allResults += $results             
         
         }           
              
         if($null -ne $allResults){
             $LASTEXITCODE = 0
         }                       
            }
            catch [System.Exception] {
                $ErrorMessage = $_.Exception.Message
                Write-LogError "Message ::  $ErrorMessage"
                $allResults = $null
            }          
            Write-LogInfo "Exiting Function Get-DataRetentionPolicySummary"
            return $allResults
        }    
    }
    function Execute-MCASAPI {
        [CmdletBinding()]
        [OutputType([String])]     
        Param(
            [Parameter(Mandatory = $false, Position = 0)]
            [string] $mcastoken,
            [Parameter(Mandatory = $false, Position = 1)]
            [string] $baseURL  
        )
        Process {        
            Write-LogInfo "Inside Function Execute-MCASAPI"
            Write-LogDebug "Input MCAS Token :: $mcastoken"     
            Write-LogDebug "Input Base URL :: $baseURL"                 
            try {                
                
                $url="$($baseURL)/cas/api/v1/policies/"
                Write-LogDebug "Calling REST API to pull MCAS policy information"
                $response=Invoke-RestMethod  -Uri $url -Headers @{Authorization = "Token $($mcastoken)"} -Method GET  -Verbose
                $response = $response.data           
                             
                $LASTEXITCODE = 0
            }
            catch [System.Exception] {
                $ErrorMessage = $_.Exception.Message
                Write-LogError "Message ::  $ErrorMessage"
                $response = $null
            }          
            Write-LogInfo "Exiting Function Execute-MCASAPI"
            return $response
        }
        
    }
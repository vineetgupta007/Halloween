<#
    .SYNOPSIS
        These functions are used for generating different type of reports for Azure AD Assessment
    .DESCRIPTION
        This utilty contains all the functions that are used for generating reports for security assessment on Azure AD and uploading them to LAWS
#>

<#
    .SYNOPSIS
        This function is used for running pre-check before generaing Assessment reports
    .DESCRIPTION
        This function runs some pre-check on user perminssions before generaing Assessment reports
    .PARAMETER AADLicense
        Defines the Azure AD licenses requirement for running this assessment
    .PARAMETER userName
        Username of the user being used for running this report
    .PARAMETER subscriptionId
        Subscription ID of Azure Management Group where Azure Resources (Blob Storage, LAWS) are defined
    .PARAMETER resourceGroupName
        Resource Group Name Azure Blob Storage is defined
    .PARAMETER storageAccountName
        Name of the Azure Storage Account
    .PARAMETER storageContainerName
        Name of the Azure Storage Container
    .PARAMETER createResource
        Flag to create resources
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
        2 - User doesn't have sufficient permission
        3 - Resource not found
    .EXAMPLE
       Check-AzADAssessmentPreReq -AADLicense $AADLicense -userName $AZLoginProps.username -subscriptionId $subscriptionId -resourceGroupName $storageAccountRG -createResource $true
#>
function Check-AzADAssessmentPreReq {
    [CmdletBinding()]
    [OutputType([Int])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$AADLicense,

        [Parameter(Mandatory = $true, Position = 1)]
        [string]$userName
    )
    Process {
        Write-LogInfo "Inside Function Check-AzADAssessmentPreReq"
        try {
            
            Write-LogDebug "-- Setup Pre-requisite Summary --"
            $LASTEXITCODE = 1

            ## -- Check if azure active directory license is premium 
            If ($AADLicense -match "AAD_PREMIUM*" ) {
                Write-LogDebug "Azure Active Directory Tenant have a Premimum subscription"
            }
            Else {
                $LASTEXITCODE = 2
                Throw "Azure Active Directory Tenant does not a Premimum subscription"
            }
            
            ## -- Check if user/service principal used for set up has Global or User Account Administrator role
            $role = Get-AzureADDirectoryRole | Where-Object { $_.displayName -eq 'Company Administrator' }
            
            $getRoleMember = Get-AzureADDirectoryRoleMember -ObjectId $role.ObjectId | Where-Object { $_.UserPrincipalName -eq $userName } 
                                    
            if ($null -eq $getRoleMember) {
                $role = Get-AzureADDirectoryRole | Where-Object { $_.displayName -eq 'User Account Administrator' }
                $getRoleMember = Get-AzureADDirectoryRoleMember -ObjectId $role.ObjectId | Where-Object { $_.UserPrincipalName -eq $userName } 
                if ($null -eq $getRoleMember) {
                    $LASTEXITCODE = 2
                    Throw "User is not assigned as minimum, User Account Administrator Role to perform assessment"
                }
                
            }        
            
            $LASTEXITCODE = 0
            
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
        }
        Write-LogInfo "Exiting Function Check-AzADAssessmentPreReq"
        return $LASTEXITCODE

    }

}  

<#
    .SYNOPSIS
        This function is used for getting all the users with RBAC role assignment in Azure Tenant 
    .DESCRIPTION
        This functions gets all the RBAC role assignments in Azure and creates custom object containing details of all the users
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
        Get-AzureRBACAdmins
#>
function Get-AzureRBACAdmins {
    [CmdletBinding()]
    [OutputType([System.Array])]
    param ()
    Process {
        Write-LogInfo "Inside Function Get-AzureRBACAdmins"
        try {
            $result = "" 
            $allResults = @()

            #Deafult exit code
            $LASTEXITCODE = 1
            #Get all RBAC Role Assigments
            $azRoleUsers = Get-AzRoleAssignment
            Foreach ($azRoleUser in $azRoleUsers) {
                $userCount++
                $roleName = $azRoleUser.RoleDefinitionName
                $signInName = $azRoleUser.SignInName
                $displayName = $azRoleUser.DisplayName
                $objectType = $azRoleUser.ObjectType
                $canDelegate = $azRoleUser.CanDelegate
                $scope = $azRoleUser.Scope
                
                #Create User object for writing to CSV file
                $result = @{'RoleName' = $roleName; 'SignInName' = $signInName; 'DisplayName' = $displayName; 'ObjectType' = $objectType; 'CanDelegate' = $canDelegate; 'Scope' = $scope }
                
                #Add object to Array
                $results = New-Object PSObject -Property $result
				
                $allResults += $results
            }
            $LASTEXITCODE = 0
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
            $allResults = $null
        }
        Write-LogInfo "Exiting Function Get-AzureRBACAdmins"
        return $allResults
    }
    
}

<#
    .SYNOPSIS
        This function is used for getting all the guest users in Azure Tenant 
    .DESCRIPTION
        This function gets all guest users in Azure and creates custom object containing details of all the users
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Get-GuestsUsersThroughAzureAD
#>
function Get-GuestsUsersThroughAzureAD {
    [CmdletBinding()]
    [OutputType([System.Array])]
    param()
    process {
        Write-LogInfo "Inside Function Get-GuestsUsersThroughAzureAD"
        Try {     
            $allResults = @()
            #Deafult exit code
            $LASTEXITCODE = 1

            $TenantGuestsUsers = Get-AzureADUser -Filter "Usertype eq 'Guest'" -All $true
            foreach ($GuestUser in $TenantGuestsUsers) {  				
                $displayName = $GuestUser.DisplayName
                $userPrincipalName = $GuestUser.UserPrincipalName
                $mail = $GuestUser.Mail
                $objectId = $GuestUser.ObjectId
                $objectType = $GuestUser.AccountEnabled
                $accountEnabled = $GuestUser.AgeGroup
                $ageGroup = $GuestUser.AgeGroup
                $city = $GuestUser.City
                $companyName = $GuestUser.CompanyName
                $department = $GuestUser.Department
                $dirSyncEnabled = $GuestUser.DirSyncEnabled
                $jobTitle = $GuestUser.JobTitle
                $lastDirSyncTime = $GuestUser.LastDirSyncTime
                $passwordPolicies = $GuestUser.PasswordPolicies
                $userType = $GuestUser.UserType
				
                $result = @{'Guest User DisplayName' = $displayName; 'User Principal Name' = $userPrincipalName; 'Mail Address' = $mail; 'Object Id' = $objectId; 'Object Type' = $objectType; 'Account Enabled' = $accountEnabled; 'Age Group' = $ageGroup; 'City' = $city; 'Company Name' = $companyName; 'Department' = $department; 'Directory Synchronization Enabled' = $dirSyncEnabled; 'Job Title' = $jobTitle; 'Last Directory Synchronization Time' = $lastDirSyncTime; 'Password Policies' = $passwordPolicies; 'User Type' = $userType; }
                
                #Add object to Array
                $results = New-Object PSObject -Property $result
				
                $allResults += $results   
            }  
            $LASTEXITCODE = 0
        } 
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
            $allResults = $null    
        }
        Write-LogInfo "Exiting Function Get-GuestsUsersThroughAzureAD"
        return $allResults
    }
}

<#
    .SYNOPSIS
        This function is used for getting all information related to Azure tenant 
    .DESCRIPTION
        This function gets all the information about Azure tenant and creates custom object containing details of all the users
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Get-CompanyInformation
#>
function Get-CompanyInformation {
    [CmdletBinding()]
    [OutputType([System.Array])]
    param ()
    Process {
        Write-LogInfo "Inside Function Get-CompanyInformation"
        try {

            $allResults = @()
            #Deafult exit code
            $LASTEXITCODE = 1

            $companyInformation = Get-MsolCompanyInformation
            $displayName = $companyInformation.DisplayName
            $preferredLanguage = $companyInformation.PreferredLanguage
            $street = $companyInformation.Street
            $city = $companyInformation.City
            $state = $companyInformation.State
            $postalCode = $companyInformation.PostalCode
            $country = $companyInformation.Country
            $countryLetterCode = $companyInformation.CountryLetterCode
            $telephoneNumber = $companyInformation.TelephoneNumber
            $selfServePasswordResetEnabled = $companyInformation.SelfServePasswordResetEnabled
            $usersPermissionToCreateGroupsEnabled = $companyInformation.UsersPermissionToCreateGroupsEnabled
            $usersPermissionToReadOtherUsersEnabled = $companyInformation.UsersPermissionToReadOtherUsersEnabled
            $usersPermissionToCreateLOBAppsEnabled = $companyInformation.UsersPermissionToCreateLOBAppsEnabled
            $usersPermissionToUserConsentToAppEnabled = $companyInformation.UsersPermissionToUserConsentToAppEnabled
            $dirSyncServiceAccount = $companyInformation.DirSyncServiceAccount
            $passwordSynchronizationEnabled = $companyInformation.PasswordSynchronizationEnabled
            $temp = $companyInformation | Select-Object TechnicalNotificationEmails
            $technicalNotificationEmails = "$($Temp.TechnicalNotificationEmails)"
            $temp = $companyInformation | Select-Object MarketingNotificationEmails
            $marketingNotificationEmails = "$($Temp.MarketingNotificationEmails)"

            #Create object for writing to CSV file
            $result = @{'DisplayName' = $displayName; 'PreferredLanguage' = $preferredLanguage; 'Street' = $street; 'City' = $city; 'State' = $state; 'PostalCode' = $postalCode; 'Country' = $country; 'CountryLetterCode' = $countryLetterCode; 'TelephoneNumber' = $telephoneNumber; 'SelfServePasswordResetEnabled' = $selfServePasswordResetEnabled; 'UsersPermissionToCreateGroupsEnabled' = $usersPermissionToCreateGroupsEnabled; 'UsersPermissionToReadOtherUsersEnabled' = $usersPermissionToReadOtherUsersEnabled; 'UsersPermissionToUserConsentToAppEnabled' = $usersPermissionToUserConsentToAppEnabled; 'PasswordSynchronizationEnabled' = $passwordSynchronizationEnabled; 'UsersPermissionToCreateLOBAppsEnabled' = $usersPermissionToCreateLOBAppsEnabled; 'DirSyncServiceAccount' = $dirSyncServiceAccount; 'TechnicalNotificationEmails' = $technicalNotificationEmails; 'MarketingNotificationEmails' = $marketingNotificationEmails; }

            #Add object to Array
            $results = New-Object PSObject -Property $result
               
            $allResults += $results

            if ($null -ne $allResults) {
                $LASTEXITCODE = 0
            }
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
            $allResults = $null
        }
        Write-LogInfo "Exiting Function Get-CompanyInformation"
        return $allResults
    }
    
}

<#
    .SYNOPSIS
        This function is used for getting all the user data who are assigned to Azure AD roles
    .DESCRIPTION
        This function gets all the information about all the user data who are assigned to Azure AD roles in given Azure tenant and creates custom object
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Get-AzureADRoleMembers
#>
function Get-AzureADRoleMembers {
    [CmdletBinding()]
    [OutputType([System.Array])]
    param ()
    Process {

        Write-LogInfo "Inside Function Get-AzureADRoleMembers"
        try {
            $allResults = @()
            #Deafult exit code
            $LASTEXITCODE = 1

            $roles = Get-MsolRole
            foreach ($role in $roles) {
                $roleId = $role.ObjectID
                
                $roleName = $role.Name
                
                $roleMembers = Get-MsolRoleMember -RoleObjectId $roleId
                if ($roleMembers.Count -ne 0) {
                    #$RoleMembers
                    foreach ($roleMember in $roleMembers) {
                        
                        $roleMemberType = $roleMember.RoleMemberType
                        $userEmail = $roleMember.EmailAddress
                        $userDisplayName = $roleMember.DisplayName
                        $isLicensed = $roleMember.IsLicensed
                        
                        #Create object for writing to CSV file
                        $result = @{'RoleName' = $roleName; 'RoleMemberType' = $roleMemberType; 'UserEmail' = $userEmail; 'UserDisplayName' = $userDisplayName; 'IsLicensed' = $isLicensed; }
                        
                        $results = New-Object PSObject -Property $result
                
                        $allResults += $results                        

                    }
                }
                $LASTEXITCODE = 0
                
            }
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
            $allResults = $null
        }
        Write-LogInfo "Exiting Function Get-AzureADRoleMembers"
        return $allResults
    }
}

<#
    .SYNOPSIS
        This function is used for getting data for all the groups in Azure AD
    .DESCRIPTION
        This function gets all the information about all the groups, members and owners in Azure AD and creates custom object
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Get-AzureADGroupDetails
#>
function Get-AzureADGroupDetails {
    [CmdletBinding()]
    [OutputType([System.Array])]
    param ()
    Process {

        Write-LogInfo "Inside Function Get-AzureADGroupDetails "
        try {
            $allResults = @()
            #Deafult exit code
            $LASTEXITCODE = 1

            $groups = Get-AzureADGroup

            ForEach ($group in $groups) {
                $members = Get-AzureADGroupMember -ObjectId $group.ObjectId
                $noOfMembers = 0
                ForEach ($member in $members) {
                    $noOfMembers = $noOfMembers + 1
                }
                $owners = Get-AzureADGroupOwner -ObjectId $group.ObjectId
                $noOfOwners = 0
                ForEach ($owner in $owners) {
                    $noOfOwners = $noOfOwners + 1
                }
				
                $groupName = $group.DisplayName
                $numberOfMembers = $noOfMembers
                $numberOfOwners = $noOfOwners
				
                $result = @{'GroupName' = $groupName; 'NumberOfMembers' = $numberOfMembers; 'NumberOfOwners' = $numberOfOwners; }
				
                $results = New-Object PSObject -Property $result
                $allResults += $results
            }
            $LASTEXITCODE = 0
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
            $allResults = $null
        }
        Write-LogInfo "Exiting Function Get-AzureADGroupDetails "
        return $allResults
    }
}


<#
    .SYNOPSIS
        This function is used for getting data for password expiration of all the users in Azure AD
    .DESCRIPTION
        This function gets all the information about password expiration of users in Azure AD and creates custom object
    .PARAMETER PwdNeverExpires
        Setting this parameter will get users who's password never expires
    .PARAMETER PwdExpired
        Setting this parameter will get users who's password has expired
    .PARAMETER LicensedUserOnly
        Setting this parameter will get users who's are assigned to any Azure AD licenses
    .PARAMETER SoonToExpire
        It defines the number of days before password expire. For given value, this function will get all the users who's password going to expire in given number of days
    .PARAMETER RecentPwdChanges
        It defines the number of days before password has been changed. For given value, this function will get all the users who's password has been changed before given number of days
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Get-PwdExpiryDetails
#>
function Get-PwdExpiryDetails {
    [CmdletBinding()]
    [OutputType([System.Array])]
    param (
        [Parameter(Mandatory = $False, Position = 0)]
        [switch]$PwdNeverExpires,

        [Parameter(Mandatory = $False, Position = 1)]
        [switch]$PwdExpired, 

        [Parameter(Mandatory = $False, Position = 2)]
        [switch]$LicensedUserOnly,

        [Parameter(Mandatory = $false, Position = 3)] 
        [int]$SoonToExpire,
        
        [Parameter(Mandatory = $False, Position = 4)]
        [int]$RecentPwdChanges
    )
    Process {
        Write-LogInfo "Inside Function Get-PwdExpiryDetails"
        try {
            $allResults = @()
            $result = ""   
            $PwdPolicy = @{}
            $Results = @() 
            #Deafult exit code
            $LASTEXITCODE = 1

            #Getting Password policy for the domain
            $Domains = Get-MsolDomain
            foreach ($Domain in $Domains) { 
                #Check for federated domain
                if ($Domain.Authentication -eq "Federated") {
                    $PwdValidity = 0
                }
                else {
                    $PwdValidity = (Get-MsolPasswordPolicy -DomainName $Domain -ErrorAction SilentlyContinue ).ValidityPeriod
                    if ($null -eq $PwdValidity) {                                 
                        $PwdValidity = 90
                    }
                }
                $PwdPolicy.Add($Domain.name, $PwdValidity)
            }
			
            #Loop through each user 
            Get-MsolUser -All | foreach { 
                $UPN = $_.UserPrincipalName
                $DisplayName = $_.DisplayName
                [boolean]$Federated = $false
                $UserCount++
                #Remove external users
                if ($UPN -like "*#EXT#*") {
                    return
                }

                $PwdLastChange = $_.LastPasswordChangeTimestamp
                $PwdNeverExpire = $_.PasswordNeverExpires
                $LicenseStatus = $_.isLicensed
                if ($LicenseStatus -eq $true) {
                    $LicenseStatus = "Licensed"
                }
                else {
                    $LicenseStatus = "Unlicensed"
                }
			 

                #Finding password validity period for user
                $UserDomain = $UPN -Split "@" | Select-Object -Last 1 
                $PwdValidityPeriod = $PwdPolicy[$UserDomain]

                #Check for Pwd never expires set from pwd policy
                if ([int]$PwdValidityPeriod -eq 2147483647) {
                    $PwdNeverExpire = $true
                    $PwdExpireIn = "Never Expires"
                    $PwdExpiryDate = "-"
                    $PwdExpiresIn = "-"
                }
                elseif ($PwdValidityPeriod -eq 0) {
                    $Federated = $true
                    $PwdExpireIn = "Insufficient data in O365"
                    $PwdExpiryDate = "-"
                    $PwdExpiresIn = "-"
                }
                elseif ($PwdNeverExpire -eq $False) {
                    $PwdExpiryDate = $PwdLastChange.AddDays($PwdValidityPeriod)
                    $PwdExpiresIn = (New-TimeSpan -Start (Get-Date) -End $PwdExpiryDate).Days
                    if ($PwdExpiresIn -gt 0) {
                        $PwdExpireIn = "in $PwdExpiresIn days"
                    }
                    elseif ($PwdExpiresIn -lt 0) {
                        $PwdExpireIn = $PwdExpiresIn * (-1)
                        $PwdExpireIn = "$PwdExpireIn days ago"
                    }
                    else {
                        $PwdExpireIn = "Today"
                    }
                }
                else {
                    $PwdExpireIn = "Never Expires"
                    $PwdExpiryDate = "-"
                    $PwdExpiresIn = "-"
                }

                #Calculating Password since last set
                $PwdSinceLastSet = (New-TimeSpan -Start $PwdLastChange).Days

                #Filter for user with Password never expires
                if (($PwdNeverExpires.IsPresent) -and ($PwdNeverExpire = $false)) {
                    return
                }
			 
                #Filter for password expired users
                if (($pwdexpired.IsPresent) -and (($PwdExpiresIn -ge 0) -or ($PwdExpiresIn -eq "-"))) { 
                    return
                }

                #Filter for licensed users
                if (($LicensedUserOnly.IsPresent) -and ($LicenseStatus -eq "Unlicensed")) {
                    return
                }

                #Filter for soon to expire pwd users
                if (($SoonToExpire -ne "") -and (($PwdExpiryDate -eq "-") -or ([int]$SoonToExpire -lt $PwdExpiresIn) -or ($PwdExpiresIn -lt 0))) { 
                    return
                }

                #Filter for recently password changed users
                if (($RecentPwdChanges -ne "") -and ($PwdSinceLastSet -gt $RecentPwdChanges)) {
                    return
                }

                if ($Federated -eq $true) {
                    $PwdExpiryDate = "Insufficient data in O365"
                    $PwdExpiresIn = "Insufficient data in O365"
                } 
			 
                #Export result to csv
                $result = @{'Display Name' = $DisplayName; 'User Principal Name' = $upn; 'Pwd Last Change Date' = $PwdLastChange; 'Days since Pwd Last Set' = $PwdSinceLastSet; 'Pwd Expiry Date' = $PwdExpiryDate; 'Days since Expiry(-) / Days to Expiry(+)' = $PwdExpiresIn ; 'Friendly Expiry Time' = $PwdExpireIn; 'License Status' = $LicenseStatus }
			 
                $results = New-Object PSObject -Property $result
                $allResults += $results
            }
            $LASTEXITCODE = 0
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
            $allResults = $null
        }
        Write-LogInfo "Exiting Function Get-PwdExpiryDetails"
        return $allResults
    }
}

<#
    .SYNOPSIS
        This function is used for getting last login activity data for users in Azure AD
    .DESCRIPTION
        This function gets all the information about last login activity of users in Azure AD and creates custom object
    .PARAMETER accessToken
        Access Token used for making Microsoft Graph API call
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Get-PwdExpiryDetails
#>
function Get-LastLoginActivityDetails {
    [CmdletBinding()]
    [OutputType([System.Array])]
    param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$accessToken
    )
    Process {
        Write-LogInfo "Inside Function Get-LastLoginActivityDetails"
        try {
            $allResults = @()
            #Deafult exit code
            $LASTEXITCODE = 1

            # Get all users in source tenant
            $uri = 'https://graph.microsoft.com/beta/users?$select=displayName,userPrincipalName,signInActivity,accountEnabled'
			 
            # If the result is more than 999, we need to read the @odata.nextLink to show more than one side of users
            $Data = while (-not [string]::IsNullOrEmpty($uri)) {
                # API Call
                $apiCall = try {
                    Invoke-RestMethod -Headers @{Authorization = "Bearer $($accessToken)" } -Uri $uri -Method Get
                }
                catch {
                    $errorMessage = $_.ErrorDetails.Message | ConvertFrom-Json
                }
                $uri = $null
                if ($apiCall) {
                    # Check if any data is left
                    $uri = $apiCall.'@odata.nextLink'
                    $apiCall
                }
            }
			 
            # Set the result into an variable
            $result = ($Data | select-object Value).Value
            $users = $result | select DisplayName, UserPrincipalName, AccountEnabled, @{n = "LastLoginDate"; e = { $_.signInActivity.lastSignInDateTime } }
			 

            $UserDetails = @() 
            ForEach ($user in $users) {
                $CurrentTime = [DateTime]::UtcNow | get-date -Format "yyyy-MM-ddTHH:mm:ssZ"
                if ($user.LastLoginDate) {
                    $DaysLastLoginTime = New-TimeSpan -Start $user.LastLoginDate -end $CurrentTime
                    $DaysLastLogin = $DaysLastLoginTime.days
                    $LastLoginDate = [datetime]::Parse($user.LastLoginDate)
                }
                else {
                    $DaysLastLogin = "Never Signed In"
                    $LastLoginDate = "Never Signed In"
                }
				
                $DisplayName = $user.DisplayName
                $UserPrincipalName = $user.UserPrincipalName
                $LastLoginDate = $LastLoginDate
                $DaysSinceLastLogin = $DaysLastLogin
                $AccountEnabled = $user.AccountEnabled
                #$UserDetails+=$obj
				
                $result = @{'DisplayName' = $DisplayName; 'UserPrincipalName' = $UserPrincipalName; 'LastLoginDate' = $LastLoginDate; 'DaysSinceLastLogin' = $DaysSinceLastLogin; 'AccountEnabled' = $AccountEnabled; }
			 
                $results = New-Object PSObject -Property $result
                $allResults += $results
            }
            $LASTEXITCODE = 0
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
            $allResults = $null
        }
        Write-LogInfo "Exiting Function Get-LastLoginActivityDetails"
        return $allResults
    }
}

<#
    .SYNOPSIS
        This function is used for getting data for MFA related information of all the users in Azure AD
    .DESCRIPTION
        This function gets all the information about MFA related information of users in Azure AD and creates custom object
    .PARAMETER disabledOnly
        Setting this parameter will get users who are disabled
    .PARAMETER enabledOnly
        Setting this parameter will get users who are enabled
    .PARAMETER enforcedOnly
        Setting this parameter will get users for whom MFA is being enforced
    .PARAMETER conditionalAccessOnly
        Setting this parameter will get users for whom MFA is being applied as per Conditional Access Policy
    .PARAMETER adminOnly
       Setting this parameter will get users who are Admins (Global Administrators) in Azure AD
    .PARAMETER licensedUserOnly
        Setting this parameter will get users who have Azure AD license assigned
    .PARAMETER signInAllowed
        Setting this parameter will get users who are allowed to Sign In
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Get-MFAUsers
       Get-MFAUsers -disabledOnly
#>
function Get-MFAUsers {
    [CmdletBinding()]
    [OutputType([System.Array])]
    param (
        [Parameter(Mandatory = $False, Position = 0)]
        [switch]$disabledOnly,

        [Parameter(Mandatory = $False, Position = 1)]
        [switch]$enabledOnly,

        [Parameter(Mandatory = $False, Position = 2)]
        [switch]$enforcedOnly,

        [Parameter(Mandatory = $False, Position = 3)]
        [switch]$conditionalAccessOnly,

        [Parameter(Mandatory = $False, Position = 4)]
        [switch]$adminOnly,

        [Parameter(Mandatory = $False, Position = 5)]
        [switch]$licensedUserOnly,

        [Parameter(Mandatory = $False, Position = 6)]
        [Nullable[boolean]]$signInAllowed = $null
    )
    Process {

        Write-LogInfo "Inside Function Get-MFAUsers"
        
        try {
            $allResults = @()
            #Deafult exit code
            $LASTEXITCODE = 1

            Get-MsolUser -All | foreach { 
                $displayName = $_.DisplayName 
                $upn = $_.UserPrincipalName 
                $mfaStatus = $_.StrongAuthenticationRequirements.State 
                $methodTypes = $_.StrongAuthenticationMethods 
                #Write-Progress -Activity "`n     Processed user count: $UserCount "`n"  Currently Processing: $DisplayName" 
                if ($_.BlockCredential -eq "True") {  
                    $signInStatus = "False" 
                } 
                else { 
                    $signInStatus = "True" 
                } 
			  
                #Filter result based on SignIn status 
                if (($signInAllowed -ne $null) -and ([string]$signInAllowed -ne [string]$signInStatus)) { 
                    return 
                } 
			 
                #Filter result based on License status 
                if (($licensedUserOnly.IsPresent) -and ($_.IsLicensed -eq $False)) { 
                    return 
                } 
			 
                #Check for user's Admin role 
                $roles = (Get-MsolUserRole -UserPrincipalName $upn).Name 
                if ($roles -contains 'Company Administrator') {  
                    $isAdmin = "True"  
                }  
                else { 
                    $isAdmin = "False" 
                } 
			   
                #Filter result based on Admin users 
                if (($adminOnly.IsPresent) -and ([string]$isAdmin -eq "False")) { 
                    return 
                } 
			 
                #Check for MFA enabled user 
                if (($methodTypes -ne $Null) -or ($mfaStatus -ne $Null) -and (-Not ($disabledOnly.IsPresent) )) { 
                    #Check for Conditional Access 
                    if ($mfaStatus -eq $null) { 
                        $mfaStatus = 'Enabled via Conditional Access' 
                    } 
			 
                    #Filter result based on EnforcedOnly filter 
                    if ((([string]$mfaStatus -eq "Enabled") -or ([string]$mfaStatus -eq "Enabled via Conditional Access")) -and ($enforcedOnly.IsPresent)) {  
                        return 
                    } 
			   
                    #Filter result based on EnabledOnly filter 
                    if (([string]$mfaStatus -eq "Enforced") -and ($enabledOnly.IsPresent)) {  
                        return 
                    } 
			 
                    #Filter result based on MFA enabled via conditional access 
                    if ((($mfaStatus -eq "Enabled") -or ($mfaStatus -eq "Enforced")) -and ($conditionalAccessOnly.IsPresent)) { 
                        return 
                    } 
			 
                    $methods = "" 
                    $methodTypes = "" 
                    $methodTypes = $_.StrongAuthenticationMethods.MethodType 
                    $defaultMFAMethod = ($_.StrongAuthenticationMethods | where { $_.IsDefault -eq "True" }).MethodType 
                    $mfaPhone = $_.StrongAuthenticationUserDetails.PhoneNumber 
                    $mfaEmail = $_.StrongAuthenticationUserDetails.Email 
			 
                    if ($mfaPhone -eq $Null) 
                    { $mfaPhone = "-" } 
                    if ($mfaEmail -eq $Null) 
                    { $mfaEmail = "-" } 
			 
                    if ($methodTypes -ne $Null) { 
                        $activationStatus = "Yes" 
                        foreach ($methodType in $methodTypes) { 
                            if ($methods -ne "") { 
                                $methods = $methods + "," 
                            } 
                            $methods = $methods + $methodType 
                        } 
                    } 
			 
                    else {  
                        $activationStatus = "No" 
                        $methods = "-" 
                        $defaultMFAMethod = "-" 
                        $mfaPhone = "-" 
                        $mfaEmail = "-" 
                    } 
			 
                    #Print to output file 
                    #$PrintedUser++ 
                    $result = @{'DisplayName' = $displayName; 'UserPrincipalName' = $upn; 'MFAStatus' = $mfaStatus; 'ActivationStatus' = $activationStatus; 'DefaultMFAMethod' = $defaultMFAMethod; 'AllMFAMethods' = $methods; 'MFAPhone' = $mfaPhone; 'MFAEmail' = $mfaEmail; 'LicenseStatus' = $_.IsLicensed; 'IsAdmin' = $isAdmin; 'SignInStatus' = $signInStatus }  
                    $results = New-Object PSObject -Property $result
                    $allResults += $results
                    #$Results | Select-Object DisplayName,UserPrincipalName,MFAStatus,ActivationStatus,DefaultMFAMethod,AllMFAMethods,MFAPhone,MFAEmail,LicenseStatus,IsAdmin,SignInStatus | Export-Csv -Path $ExportCSVReport -Notype -Append 
                } 
			 
                #Check for disabled userwe 
                elseif (($disabledOnly.IsPresent) -and ($mfaStatus -eq $Null) -and ($_.StrongAuthenticationMethods.MethodType -eq $Null)) { 
                    $mfaStatus = "Disabled"
                    $result = @{'DisplayName' = $displayName; 'UserPrincipalName' = $upn; 'MFAStatus' = $mfaStatus; 'LicenseStatus' = $_.IsLicensed; 'IsAdmin' = $isAdmin; 'SignInStatus' = $signInStatus }  
                    $results = New-Object PSObject -Property $result
                    $allResults += $results
                    #$Results | Select-Object DisplayName,UserPrincipalName,Department,MFAStatus,LicenseStatus,IsAdmin,SignInStatus | Export-Csv -Path $ExportCSV -Notype -Append 
                } 
            } 
            $LASTEXITCODE = 0
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
            $allResults = $null
        }
        Write-LogInfo "Exiting Function Get-MFAUsers"
        return $allResults
    }
}

<#
    .SYNOPSIS
        This function is used for getting MFA information for Classic Admins in Azure tenant
    .DESCRIPTION
        This function gets all the information about MFA information for Classic Admins in Azure tenant and creates custom object
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Get-ClassAdminsMFA
#>
function Get-ClassicAdminsMFA {
    [CmdletBinding()]
    [OutputType([System.Array])]
    param ()
    Process {
        Write-LogInfo "Inside Function Get-ClassicAdminsMFA"
        try {
            $allResults = @()
            #Deafult exit code
            $LASTEXITCODE = 1

            $azRoleUsers = Get-AzRoleAssignment -IncludeClassicAdministrators

            foreach ($azRoleUser in $azRoleUsers) {
                $roleName = $azRoleUser.RoleDefinitionName
                if (($roleName -eq "ServiceAdministrator") -or ($roleName -eq "AccountAdministrator") -or ($roleName -eq "CoAdministrator")) { 
                    $classicAdminNames += $azRoleUser.SignInName
                }
            }
            #Write-LogDebug "ClassicAdmins :: $classicAdminNames"
            if ($classicAdminNames.count -ne 0) {
                Foreach ($classicAdminName in $classicAdminNames) {
                    if (($classicAdminName -match 'admin@godevsuite014.onmicrosoft.com') -or ($classicAdminName -match 'maikvandergaag@goazrsm01.onmicrosoft.com')) {
                        Write-Host `nSkipping Admin Found
                        $result = @{'DisplayName' = $displayName; 'UserPrincipalName' = $upn; 'MFAStatus' = $mfaStatus; 'DefaultMFAMethod' = $defaultMFAMethod; 'AllMFAMethods' = $methods; 'MFAPhone' = $mfaPhone; 'MFAEmail' = $mfaEmail; 'LicenseStatus' = $isLicensed; }
                        $results = New-Object PSObject -Property $result  
                        $allResults += $results
                    
                    }
                    else {
                        $userCount++
                        $user = Get-MsolUser -UserPrincipalName $classicAdminName
                        
                        $displayName = $User.DisplayName 
                        $upn = $User.UserPrincipalName 
                        $mfaStatus = $User.StrongAuthenticationRequirements.State 
                        $methodTypes = $User.StrongAuthenticationMethods
                        $methodTypes = $User.StrongAuthenticationMethods.MethodType 
                        $defaultMFAMethod = ($User.StrongAuthenticationMethods | Where-Object { $User.IsDefault -eq "True" }).MethodType 
                        $mfaPhone = $User.StrongAuthenticationUserDetails.PhoneNumber 
                        $mfaEmail = $User.StrongAuthenticationUserDetails.Email 
                        if ($Null -eq $mfaPhone) { 
                            $mfaPhone = ""
                        }if ($Null -eq $mfaEmail) {
                            $mfaEmail = ""
                        }if ($Null -ne $methodTypes) {
                            foreach ($methodType in $methodTypes) { 
                                if ($methods -ne "") { 
                                    $methods = $methods + "," 
                                } 
                                $methods = $methods + $methodType 
                            } 
                        }
                        else {  
                            $methods = "" 
                            $defaultMFAMethod = "" 
                            $mfaPhone = "" 
                            $mfaEmail = "" 
                        }
                        #Write-Progress -Activity "`n     Processed user count: $UserCount "`n"  Currently Processing: $DisplayName"
                        $result = @{'DisplayName' = $displayName; 'UserPrincipalName' = $upn; 'MFAStatus' = $mfaStatus; 'DefaultMFAMethod' = $defaultMFAMethod; 'AllMFAMethods' = $methods; 'MFAPhone' = $mfaPhone; 'MFAEmail' = $mfaEmail; 'LicenseStatus' = $user.IsLicensed; }
                        $results = New-Object PSObject -Property $result  
                        $allResults += $results
                    }
                }
            }
            else {
                Write-LogDebug "No Classic Admin Found"
            }
            $LASTEXITCODE = 0
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
            $allResults = $null
        }
        Write-LogInfo "Exiting Function Get-ClassicAdminsMFA"
        return $allResults
    }
    
}


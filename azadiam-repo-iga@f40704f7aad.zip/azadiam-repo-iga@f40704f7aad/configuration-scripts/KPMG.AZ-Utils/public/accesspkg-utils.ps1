function Get-CatalogID {
    [CmdletBinding()]
    [OutputType([string])]
    param(
       [Parameter(Mandatory=$true,Position=0)]
       [string] $CatalogName,
       [Parameter(Mandatory=$true,Position=1)]
       [string] $Token,
       [Parameter(Mandatory=$true,Position=2)]
       [string] $InvokeRestMethodURI
    )
    process {
        Write-LogInfo "Inside Function Get-CatalogID"
        $CatalogID=$null
        $headers = Get-Headers -Token $Token
        try {
            $InvokeRestMethodURI = $InvokeRestMethodURI +"?`$filter=displayName eq '$CatalogName'"
            $response = Invoke-RestMethod $InvokeRestMethodURI -Method 'GET' -Headers $headers
            $CatalogID = $response.value.id
            Write-LogInfo "CatalogID=$CatalogID"
        } catch {
            Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
            Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
            Write-Host "Response:" $_.Exception.Response
            Write-Host "Response:" $_.
            $CatalogID=$null
        }
        Write-LogInfo "Exiting Function Get-CatalogID"
        return $CatalogID
    }
}

function Get-Headers {
    [CmdletBinding()]
    [OutputType('System.Collections.Generic.Dictionary[[String],[String]]')]
    param(
        [Parameter(Mandatory=$true,Position=0)]
        [string] $Token
    )
    process {
        $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
        $headers.Add("Content-Type", "application/json")
        $headers.Add("Authorization", "Bearer $Token")
        return $headers
    }
}

function Get-AccessPackageID {
    [CmdletBinding()]
    [OutputType([string])]
    param(
       [Parameter(Mandatory=$true,Position=0)]
       [string] $PackageName,
       [Parameter(Mandatory=$true,Position=1)]
       [string] $Token,
       [Parameter(Mandatory=$true,Position=2)]
       [string] $InvokeRestMethodURI
    )
    process {
        Write-LogInfo "Inside Function Get-AccessPackageID"
        $PackageID=$null
        try {
            $headers = Get-Headers -Token $Token
            $InvokeRestMethodURI = $InvokeRestMethodURI +"?`$filter=displayName eq '$PackageName'"
            $response = Invoke-RestMethod $InvokeRestMethodURI -Method 'GET' -Headers $headers
            $PackageID = $response.value.id
            Write-LogInfo "PackageID=$PackageID"
         } catch {
            Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
            Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
            Write-Host "Response:" $_.Exception.Response
            Write-Host "Response:" $_.
            $PackageID=$null
        }
        Write-LogInfo "Exiting Function Get-AccessPackageID"
        return $PackageID
    }

}

function Add-Catalog {
    [CmdletBinding()]
    param(
       [Parameter(Mandatory=$true,Position=0)]
       [PSCustomObject] $CreateCatalogProps,
       [Parameter(Mandatory=$true,Position=1)]
       [string] $Token,
       [Parameter(Mandatory=$true,Position=2)]
       [string] $InvokeRestMethodURI
    )
    process {
        Write-LogInfo "Inside Function Add-Catalog"
        try {
            $CatalogName = $CreateCatalogProps.'catalog-name'
            #check if Catalogs exists
            $CatalogID = Get-CatalogID -Token $Token -CatalogName $CatalogName -InvokeRestMethodURI $InvokeRestMethodURI
            if(StringNullOrEmpty $CatalogID){
                $headers = Get-Headers -Token $Token
                $KeyNames=$CreateCatalogProps | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
                if($null -ne $KeyNames){
                    $CreateCatalogJson=@{"displayName"= $CatalogName;}
                    foreach ($kName in $KeyNames) {
                        if(!($kName -eq 'catalog-name')){
                            $kValue=$CreateCatalogProps.$kName
                            $CreateCatalogJson.Add($kName,$kValue)
                        }
                    }
                    $body = $CreateCatalogJson | ConvertTo-Json
                    Write-LogInfo "CreateCatalogJson=$body"
                    try {
                        $response = Invoke-RestMethod $InvokeRestMethodURI -Method 'POST' -Headers $headers -Body $body
                        $CatalogID = $response.id
                        Write-LogInfo "Catalog created successfully::$CatalogID"
                    } catch {
                        Write-LogError "StatusCode:" $_.Exception.Response.StatusCode.value__ 
                        Write-LogError "StatusDescription:" $_.Exception.Response.StatusDescription
                        Write-LogError "Response:" $_.Exception.Response
                        Write-LogError "Response:" $_.
                        $CatalogID=$null
                        break
                    }
                }else{
                    Write-LogInfo "Catalog configuration is not configured in JSON properties file"
                }
            }else{
                Write-Host "Catalog exists, skipping catalog creation"
            }
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
        Write-LogInfo "Exiting Function Add-Catalog"
    }
}

function Add-AccessPackage {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory=$true,Position=0)]
        [PSCustomObject] $AccessPkgProps,
        [Parameter(Mandatory=$true,Position=1)]
        [string] $Token,
        [Parameter(Mandatory=$false,Position=2)]
        [string] $AccessPkgInvokeRestMethodURI,
        [Parameter(Mandatory=$false,Position=3)]
        [string] $CatInvokeRestMethodURI
    )
    process {
        Write-LogInfo "Inside Function Add-AccessPackage"
        $AccessPackageID=$null
        try{
            $AccessPackageName=$AccessPkgProps.'package-name'
            #check if Access Package exists
            $CatalogID=Get-CatalogID -Token $Token -CatalogName $AccessPkgProps.'catalog-name' -InvokeRestMethodURI $CatInvokeRestMethodURI
            Write-LogInfo "CatalogID::$CatalogID"
            $AccessPackageID=Get-AccessPackageID -PackageName $AccessPackageName -Token $Token -InvokeRestMethodURI $AccessPkgInvokeRestMethodURI
            if(StringNullOrEmpty $AccessPackageID){
                $headers = Get-Headers -Token $Token
                $KeyNames=$AccessPkgProps | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
                if($null -ne $KeyNames){
                    $CreateAccessPackageJson=@{"catalogId"=$CatalogID;
                    "displayName"= "$AccessPackageName";
                    }
                    foreach ($kName in $KeyNames) {
                        if(!($kName -eq 'package-name') -or !($kName -eq 'catalog-name')){
                            $kValue=$AccessPkgProps.$kName
                            $CreateAccessPackageJson.Add($kName,$kValue)
                        }
                    }
                    $body = $CreateAccessPackageJson | ConvertTo-Json
                    Write-LogInfo "CreateAccessPackageJson=$body"
                    try {
                        $response = Invoke-RestMethod $AccessPkgInvokeRestMethodURI -Method 'POST' -Headers $headers -Body $body
                        $AccessPackageID=$response.id
                        Write-LogInfo "Access package created successfully::$AccessPackageID"
                    } catch {
                        Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
                        Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
                        Write-Host "Response:" $_.Exception.Response
                        Write-Host "Response:" $_.
                        $AccessPackageID=$null
                     }  
                }else{
                    Write-LogInfo "Access Package configuration is not configured in JSON properties file"
                }
            }else{
                Write-LogInfo "Package already exists, skipping access package creation"
            }
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
        Write-LogInfo "Exiting Function Add-AccessPackage"
        return $AccessPackageID
    }
}

function Add-Policy {
    [CmdletBinding()]
    param(
       [Parameter(Mandatory=$false, Position=0)]
       [PSCustomObject] $AccessPolicyProps,
       [Parameter(Mandatory=$true, Position=1)]
       [string] $Token,
       [Parameter(Mandatory=$True, Position=2)]
       [string] $AccessPackageID,
       [Parameter(Mandatory=$false,Position=3)]
       [string] $InvokeRestMethodURI
    )
    process {
        Write-LogInfo "Inside Function Add-Policy"
        try{
            $headers = Get-Headers -Token $Token
            $displayName=$AccessPolicyProps.'policy-name'
            $description=$AccessPolicyProps.'description'
            $canExtend=$AccessPolicyProps.'canExtend'
            $durationInDays=$AccessPolicyProps.'durationInDays'
            $accessReviewSettings=$AccessPolicyProps.'accessReviewSettings'
            $AccessPolicyJson=@{
                "accessPackageId"="$AccessPackageID";
                "displayName"="$displayName";
                "description"="$description";
                "canExtend"="$canExtend";
                "durationInDays"="$durationInDays";
                "accessReviewSettings"=$accessReviewSettings;
            }
            $shouldAccessPolicyExpire=$AccessPolicyProps.'shouldAccessPolicyExpire'
            $expirationDateTime=$AccessPolicyProps.'expirationDateTime'
            if($shouldAccessPolicyExpire){
                $AccessPolicyJson.Add("expirationDateTime",$expirationDateTime)
            }
            #Build Requestor Setting json object
            $RequestorSettingProps = $AccessPolicyProps.'requestorSettings'
            if($null -ne $RequestorSettingProps){
                $RequestorSettingData = $RequestorSettingProps.'allowedRequestors'
                $allowedRequestorsList = New-Object System.Collections.ArrayList
                if($null -ne $RequestorSettingData){
                    foreach ($reqData in $RequestorSettingData) {
                        $KeyNamesReqSettingProps=$reqData | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
                        if($null -ne $KeyNamesReqSettingProps){
                            $allowedRequestorsData = @{}
                            foreach ($kName in $KeyNamesReqSettingProps) {
                                $allowedRequestorsData.Add($kName,$reqData.$kName)
                            }
                            $allowedRequestorsList.Add($allowedRequestorsData)
                        }
                    }
                }
                $RequestorSettingJSON=@{}
                $RequestorSettingJSON.Add("scopeType",$RequestorSettingProps.scopeType)
                $RequestorSettingJSON.Add("acceptRequests",$RequestorSettingProps.acceptRequests)
                $RequestorSettingJSON.Add("allowedRequestors",$allowedRequestorsList)
                $AccessPolicyJson.Add("requestorSettings",$RequestorSettingJSON) 
            }else{
                Write-LogInfo "Requestor setting configuration not configured, skipping the config"
            }
            #Configure approval workflow
            $ApprProps = $AccessPolicyProps.'requestApprovalSettings'
            if($null -ne $ApprProps){
                $ApprJSON=@{}
                $isApprovalRequired = $ApprProps.'isApprovalRequired'
                $isApprovalRequiredForExtension = $ApprProps.'isApprovalRequiredForExtension'
                $isRequestorJustificationRequired = $ApprProps.'isRequestorJustificationRequired'
                $approvalMode = $ApprProps.'approvalMode'
                $ApprJSON.Add("isApprovalRequired",$isApprovalRequired)
                $ApprJSON.Add("isApprovalRequiredForExtension",$isApprovalRequiredForExtension)
                $ApprJSON.Add("isRequestorJustificationRequired",$isRequestorJustificationRequired)
                $ApprJSON.Add("approvalMode",$approvalMode)
                $ApprList = New-Object System.Collections.ArrayList
                $SingleStgApprData = $ApprProps.'approvalStages'
                if(!($approvalMode -eq 'NoApproval')){
                    foreach($data in $SingleStgApprData){
                        $approvalStageTimeOutInDays=$data.approvalStageTimeOutInDays
                        $isApproverJustificationRequired=$data.isApproverJustificationRequired
                        $isEscalationEnabled=$data.isEscalationEnabled
                        $escalationTimeInMinutes=$data.escalationTimeInMinutes
                        $apprData = @{
                            "approvalStageTimeOutInDays"=$approvalStageTimeOutInDays;
                            "isApproverJustificationRequired"=$isApproverJustificationRequired;
                            "isEscalationEnabled"=$isEscalationEnabled;
                            "escalationTimeInMinutes"=$escalationTimeInMinutes;
                        }
                        #Get primary approver data
                        $PrmApprData =  $data.'primaryApprovers'
                        $PrmApprList = New-Object System.Collections.ArrayList
                        if($null -ne $PrmApprData){
                            foreach ($prmData in $PrmApprData) {
                                $KeyNamesPrmApprData=$prmData | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
                                if($null -ne $KeyNamesPrmApprData){
                                    $approversData = @{}
                                    foreach ($kName in $KeyNamesPrmApprData) {
                                        $approversData.Add($kName,$prmData.$kName)
                                    }
                                    $PrmApprList.Add($approversData)
                                }
                            }
                        }
                        #Get Escalation approver data
                        $EscApprData =  $data.'escalationApprovers'
                        $EscApprList = New-Object System.Collections.ArrayList
                        if($null -ne $EscApprData){
                            foreach ($escData in $EscApprData) {
                                $KeyNamesApprData=$escData | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
                                if($null -ne $KeyNamesApprData){
                                    $escApprData = @{}
                                    foreach ($kName in $KeyNamesApprData) {
                                        $escApprData.Add($kName,$escData.$kName)
                                    }
                                    $EscApprList.Add($escApprData)
                                }
                            }
                        }
                        $apprData.Add("primaryApprovers",$PrmApprList)
                        $apprData.Add("escalationApprovers",$EscApprList)
                        $ApprList.Add($apprData)
                        if(!($ApprProps.'is-multi-stage-approval')){
                            break
                        }
                    }
                }
                $ApprJSON.Add("approvalStages",$ApprList)
                $AccessPolicyJson.Add("requestApprovalSettings",$ApprJSON)
            }else{
                Write-LogInfo "Approval setting configuration not configured"
            }
            $json = $AccessPolicyJson | ConvertTo-Json -Depth 32
            Write-LogInfo "AccessPolicyJson=$json"
            try{
                $response = Invoke-RestMethod $InvokeRestMethodURI -Method 'POST' -Headers $headers -Body $json
                $AccessPolicyID=$response.id
                Write-LogInfo "Access Policy created successfully::$AccessPolicyID"
                Write-LogInfo "Access Policy created successfully, response::$response"
            }catch{
                Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
                Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
                Write-Host "Response:" $_.Exception.Response
                Write-Host "Response:" $_.
            }
        }catch{
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError $ErrorMessage
            Write-LogError $FailedItem
            break
        }
        Write-LogInfo "Exiting Function Add-Policy"
    }
}

function Add-Resource-To-Catalog {
    param(
        [Parameter(Mandatory=$true,Position=0)]
        [PSCustomObject] $ResourceProps,

        [Parameter(Mandatory=$true,Position=1)]
        [string] $Token,

        [Parameter(Mandatory=$true,Position=2)]
        [string] $GrpMgmtInvokeRestMethodURI,

        [Parameter(Mandatory=$true,Position=3)]
        [string] $AppMgmtInvokeRestMethodURI,

        [Parameter(Mandatory=$true,Position=4)]
        [string] $ResourceInvokeRestMethodURI,

        [Parameter(Mandatory=$true,Position=4)]
        [string] $CatInvokeRestMethodURI
    )
    process{
        Write-LogInfo "Inside Function Add-Resource-To-Catalog"
        $ResourceID=$null
        #Check whether resource exists in Catalog
        if(StringNullOrEmpty $ResourceID){
            $headers = Get-Headers -Token $Token
            $CreateResourceJSON=@{}
            $CatalogID=Get-CatalogID -Token $Token -CatalogName $ResourceProps.'catalog-name' -InvokeRestMethodURI $CatInvokeRestMethodURI
            $CreateResourceJSON.Add("catalogId",$CatalogID)
            $CreateResourceJSON.Add("requestType",$ResourceProps.'requestType')
            $CreateResourceJSON.Add("justification",$ResourceProps.'justification') 
            $AccessPackageResource = $ResourceProps.'accessPackageResource'
            if($null -ne $AccessPackageResource){
                $AccessPackageResourceJSON=@{}
                $AccessPackageResourceJSON.Add("displayName",$AccessPackageResource.'resource-name')
                $AccessPackageResourceJSON.Add("description",$AccessPackageResource.'description')
                $resourceType=$AccessPackageResource.'resourceType'
                $AccessPackageResourceJSON.Add("originSystem",$AccessPackageResource.'originSystem')
                $AccessPackageResourceJSON.Add("resourceType",$resourceType)
                if($resourceType -eq 'SharePoint Online Site'){
                    $AccessPackageResourceJSON.Add("url",$AccessPackageResource.'url')
                    $AccessPackageResourceJSON.Add("originId",$AccessPackageResource.'url')
                }elseif ($resourceType -eq 'Application') {
                    $originId = Get-ServicePrincipalID -AppName $AccessPackageResource.'resource-name' -Token $Token -InvokeRestMethodURI $AppMgmtInvokeRestMethodURI
                    $AccessPackageResourceJSON.Add("originId",$originId)
                }elseif ($resourceType -eq 'Security Group') {
                    $originId = Get-GroupID -GroupName $AccessPackageResource.'resource-name' -Token $Token -InvokeRestMethodURI $GrpMgmtInvokeRestMethodURI
                    $AccessPackageResourceJSON.Add("originId",$originId)
                }else{
                    Write-LogInfo "Invalid resource type configured"
                }
                $CreateResourceJSON.Add("accessPackageResource",$AccessPackageResourceJSON)
            }
            $body = $CreateResourceJSON | ConvertTo-Json
            Write-LogInfo "CreateResourceJSON=$body"
            try {
                $response = Invoke-RestMethod $ResourceInvokeRestMethodURI -Method 'POST' -Headers $headers -Body $body
                Write-LogInfo "Resource successfully added to catalog:$response"
            } catch {
                Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
                Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
                Write-Host "Response:" $_.Exception.Response
                Write-Host "Response:" $_.                                            
            }
        }
        Write-LogInfo "Exiting Function Add-Resource-To-Catalog"
    }
}

function Get-GroupID {
    [CmdletBinding()]
    [OutputType([string])]
    param(
       [Parameter(Mandatory=$true,Position =0)]
       [string] $GroupName,
       [Parameter(Mandatory=$true, Position =1)]
       [string] $Token,
       [Parameter(Mandatory=$false,Position=2)]
        [string] $InvokeRestMethodURI
    )
    process {
        Write-LogInfo "Inside Function Get-GroupID"
        $GroupID=$null
        $headers = Get-Headers -Token $Token
        try {
            $InvokeRestMethodURI = $InvokeRestMethodURI +"?`$filter=displayName eq '$GroupName'"
            $response = Invoke-RestMethod $InvokeRestMethodURI -Method 'GET' -Headers $headers
            $GroupID=$response.value.id
        } catch {
            Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
            Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
            Write-Host "Response:" $_.Exception.Response
            Write-Host "Response:" $_.
            return $null
        }
        Write-LogInfo "Exiting Function Get-GroupID"
        return $GroupID
    }
}

function Get-ServicePrincipalID {
    [CmdletBinding()]
    [OutputType([string])]
    param(
       [Parameter(Mandatory=$true,Position =0)]
       [string] $AppName,
       [Parameter(Mandatory=$true, Position =1)]
       [string] $Token,
       [Parameter(Mandatory=$false,Position=2)]
        [string] $InvokeRestMethodURI
    )
    process {
        Write-LogInfo "Inside Function Get-ServicePrincipalID"
        $AppID=$null
        $headers = Get-Headers -Token $Token
        try {
            $InvokeRestMethodURI = $InvokeRestMethodURI +"?`$filter=displayName eq '$AppName'"
            $response = Invoke-RestMethod $InvokeRestMethodURI -Method 'GET' -Headers $headers
            $AppID=$response.value.id
        } catch {
            Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
            Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
            Write-Host "Response:" $_.Exception.Response
            Write-Host "Response:" $_.
            return $null
        }
        Write-LogInfo "Exiting Function Get-ServicePrincipalID"
        return $AppID
    }
}

function Add-ResourceScope  {
    [CmdletBinding()]
    param(
       [Parameter(Mandatory=$true,Position=0)]
       [PSCustomObject] $ResourceScopeProps,

       [Parameter(Mandatory=$true,Position=1)]
       [string] $Token,

       [Parameter(Mandatory=$true,Position=2)]
       [string] $CatInvokeRestMethodURI,

       [Parameter(Mandatory=$true,Position=2)]
       [string] $AccessPkgInvokeRestMethodURI
    )
    process {
        Write-LogInfo "Inside Function Add-ResourceScope"
        $headers = Get-Headers -Token $Token
        #Check if resource exists
        $CatalogID=Get-CatalogID -Token $Token -CatalogName $ResourceScopeProps.'catalog-name' -InvokeRestMethodURI $CatInvokeRestMethodURI
        $Resource = Get-Resource -CatalogName $ResourceScopeProps.'catalog-name' -ResourceName $ResourceScopeProps.'resource-name' -Token $Token -CatInvokeRestMethodURI $CatInvokeRestMethodURI
        $AccessPackageID=Get-AccessPackageID -PackageName $ResourceScopeProps.'package-name' -Token $Token -InvokeRestMethodURI $AccessPkgInvokeRestMethodURI
        
        if($Resource.value.originSystem -eq 'AadGroup'){
            $isGroup=$true
        }
        $ResourceScopeBase=@{}
        $AccessPackageResourceRole=@{}
         if($isGroup){
            $displayName="Owner"
            if(!($ResourceScopeProps.'isOwner')){
                $displayName="Member"
            }
            $AccessPackageResourceRole.Add("displayName",$displayName)
            $AccessPackageResourceRole.Add("description",$displayName+" Role")
            $AccessPackageResourceRole.Add("originId",$displayName+"_"+$Resource.value.originId)
            
        }else{
            $AccessPackageResourceRole.Add("displayName",$ResourceScopeProps.'displayName')
            $AccessPackageResourceRole.Add("description",$ResourceScopeProps.'description')
            $RoleID = Get-AppRoleID -CatalogID $CatalogID -RoleName $ResourceScopeProps.'displayName' -OriginSystem $Resource.value.originSystem -AccessPackageResourceID $Resource.value.id -Token $Token -InvokeRestMethodURI $CatInvokeRestMethodURI
            $AccessPackageResourceRole.Add("originId",$RoleID)
        }
        $AccessPackageResourceRole.Add("originSystem",$Resource.value.originSystem)
        $AccessPackageResource=@{}
        $AccessPackageResource.Add("id",$Resource.value.id)
        $AccessPackageResource.Add("resourceType",$Resource.value.resourceType)
        $AccessPackageResource.Add("originId",$Resource.value.originId)
        $AccessPackageResource.Add("originSystem",$Resource.value.originSystem)
        $AccessPackageResourceRole.add("accessPackageResource", $AccessPackageResource)
        $ResourceScopeBase.Add("accessPackageResourceRole",$AccessPackageResourceRole)
        $AccessPackageResourceScope=@{}
        $AccessPackageResourceScope.Add("originId",$Resource.value.originId)
        $AccessPackageResourceScope.Add("originSystem",$Resource.value.originSystem)
        $ResourceScopeBase.Add("accessPackageResourceScope",$AccessPackageResourceScope)
        $body = $ResourceScopeBase | ConvertTo-Json
        Write-LogInfo "ResourceScopeBase=$body"
        try {
            $AccessPkgInvokeRestMethodURI = $AccessPkgInvokeRestMethodURI+"/$AccessPackageID/accessPackageResourceRoleScopes"
            $response = Invoke-RestMethod $AccessPkgInvokeRestMethodURI -Method 'POST' -Headers $headers -Body $body

            Write-Host "******************$response"
         } catch {
            Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
            Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
            Write-Host "Response:" $_.Exception.Response
            Write-Host "Response:" $_.                                            
        }
        Write-LogInfo "Exiting Function Add-ResourceScope"
    }
}

function Get-Resource{
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
       [Parameter(Mandatory=$true,Position=0)]
       [string] $CatalogName,

       [Parameter(Mandatory=$true,Position=1)]
       [string] $ResourceName,

       [Parameter(Mandatory=$true,Position=2)]
       [string] $Token,

       [Parameter(Mandatory=$true,Position=3)]
       [string] $CatInvokeRestMethodURI
       )
    process {
        Write-LogInfo "Inside Function Get-Resource"
        $response=$null
        $headers = Get-Headers -Token $Token

        $CatalogID = Get-CatalogID -Token $Token -CatalogName $CatalogName -InvokeRestMethodURI $CatInvokeRestMethodURI
        try {
            $CatInvokeRestMethodURI=$CatInvokeRestMethodURI+"/$CatalogID/accessPackageResources?`$filter=displayName eq '$ResourceName'"
            $response = Invoke-RestMethod $CatInvokeRestMethodURI -Method 'GET' -Headers $headers
         } catch {
            Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
            Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
            Write-Host "Response:" $_.Exception.Response
            Write-Host "Response:" $_.
            return $null
        }
        Write-LogInfo "Exiting Function Get-Resourc"
        return $response
    }
}

function Get-AppRoleID {
    [CmdletBinding()]
    [OutputType([string])]
    param(
       [Parameter(Mandatory=$true,Position =0)]
       [string] $CatalogID,
       [Parameter(Mandatory=$true,Position =0)]
       [string] $RoleName,
       [Parameter(Mandatory=$true,Position =0)]
       [string] $OriginSystem,
       [Parameter(Mandatory=$true,Position =0)]
       [string] $AccessPackageResourceID,
       [Parameter(Mandatory=$true, Position =1)]
       [string] $Token,
       [Parameter(Mandatory=$false,Position=2)]
        [string] $InvokeRestMethodURI
    )
    process {
        Write-LogInfo "Inside Function Get-AppRoleID"
        $RoleID=$null
        $headers = Get-Headers -Token $Token
        try {
            $InvokeRestMethodURI = $InvokeRestMethodURI +"/$CatalogID/accessPackageResourceRoles?`$filter=(displayName eq '$RoleName' and originSystem eq '$OriginSystem' and accessPackageResource/id eq '$AccessPackageResourceID')&`$expand=accessPackageResource"
            Write-Host "InvokeRestMethodURI::$InvokeRestMethodURI"
            $response = Invoke-RestMethod $InvokeRestMethodURI -Method 'GET' -Headers $headers
            $RoleID=$response.value.originId
        } catch {
            Write-Host "StatusCode:" $_.Exception.Response.StatusCode.value__ 
            Write-Host "StatusDescription:" $_.Exception.Response.StatusDescription
            Write-Host "Response:" $_.Exception.Response
            Write-Host "Response:" $_.
            return $null
        }
        Write-LogInfo "Exiting Function Get-AppRoleID"
        return $RoleID
    }
}



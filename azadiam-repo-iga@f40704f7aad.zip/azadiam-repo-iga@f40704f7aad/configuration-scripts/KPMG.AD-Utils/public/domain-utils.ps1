<#
    .SYNOPSIS
        Creates Forest Root DC
    .DESCRIPTION
        Function Install-RootDC creates Forest Root DC. It also sets up the reverse DNS lookup zone.
    .PARAMETER DomainName
        Specifies the fully qualified domain name (FQDN) for the root domain in the forest
    .PARAMETER DomainMode
        Specifies the domain functional level of the first domain in the creation of a new forest i.e. WinThreshold,Windows2012R2Domain,Windows2008Domain, etc.
    .PARAMETER SafeModeAdminPassword
        Supplies the password for the administrator account when the computer is started in Safe Mode or a variant of Safe Mode
    .PARAMETER NetbiosName
        Specifies the NetBIOS name for the root domain in the new forest
    .PARAMETER LogPath
        Specifies the fully qualified, non-UNC path to a directory on a fixed disk of the local computer where the log file for this operation is written
    .PARAMETER SysvolPath
        Specifies the fully qualified, non-UNC path to a directory on a fixed disk of the local computer where the Sysvol file is written.
    .PARAMETER DatabasePath
        Specifies the fully qualified, non-Universal Naming Convention (UNC) path to a directory on a fixed disk of the local computer that contains the domain database
    .PARAMETER ForestMode
        Specifies the forest functional level for the new forest. Supported values for this parameter can be either a valid integer or a corresponding enumerated string value
    .PARAMETER ComputerName
        Computer name or ip address of the remote host server.
    .PARAMETER LAdminCreds
        PSCredential object with host's admin credentials
    .OUTPUTS
        int
        0 - successfully completed
        1 - when required input params are null/empty
        2 - when unknown error
#>
Function Install-RootDC {
    [CmdletBinding()]
    [OutputType([int])]

    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [string]
        $DomainName,

        [Parameter(Mandatory = $False, Position = 1)]
        [string]
        $DomainMode = "WinThreshold",

        [Parameter(Mandatory = $True, Position = 2)]
        [SecureString]
        $SafeModeAdminPassword,

        [Parameter(Mandatory = $True, Position = 3)]
        [string]
        $NetbiosName,

        [Parameter(Mandatory = $False, Position = 4)]
        [string]
        $LogPath = "C:\\Windows\\NTDS",

        [Parameter(Mandatory = $False, Position = 5)]
        [string]
        $SysvolPath = "C:\\Windows\\SYSVOL",

        [Parameter(Mandatory = $False, Position = 6)]
        [string]
        $DatabasePath = "C:\\Windows\\NTDS",

        [Parameter(Mandatory = $False, Position = 7)]
        [string]
        $ForestMode = "WinThreshold",

        [Parameter(Mandatory = $False, Position = 8)]
        [string]
        $ComputerName,

        [Parameter(Mandatory = $False, Position = 9)]
        [pscredential]
        $LAdminCreds
    )

    Process {
    
        $respCode = 2

        Write-LogInfo "Inside Function Install-RootDC."
        Write-LogDebug "Input DomainName :: $DomainName" 
        Write-LogDebug "Input DomainMode :: $DomainMode" 
        Write-LogDebug "Input SafeModeAdminPassword :: $SafeModeAdminPassword"
        Write-LogDebug "Input NetbiosName :: $NetbiosName" 
        Write-LogDebug "Input LogPath :: $LogPath" 
        Write-LogDebug "Input SysvolPath :: $SysvolPath" 
        Write-LogDebug "Input DatabasePath :: $DatabasePath" 
        Write-LogDebug "Input ForestMode :: $ForestMode" 
        Write-LogDebug "Input ComputerName :: $ComputerName" 

        try {

            If ((StringNullOrEmpty $DomainName) -or ($SafeModeAdminPassword.Length -le 0) -or (StringNullOrEmpty $NetbiosName)) {
                Write-LogError "Required input parameters DomainName / SafeModeAdminPassword / NetbiosName are null/empty."
                Write-LogInfo "Exiting Function Install-RootDC." 
                $respCode = 1
                return $respCode
            }
            
            Write-LogInfo "Starting forest root domain creation :: $DomainName"

            If (!(StringNullOrEmpty $ComputerName)) {

                Write-LogDebug "Invoke-Command -ComputerName $ComputerName -ScriptBlock { Install-ADDSForest -CreateDnsDelegation:$False -DatabasePath $DatabasePath -DomainMode $DomainMode -DomainName $DomainName -SafeModeAdministratorPassword $SafeModeAdminPassword -DomainNetbiosName $NetbiosName -ForestMode $ForestMode -InstallDns:$True -LogPath $LogPath -NoRebootOnCompletion:$False -SysvolPath $SysvolPath -Force:$True } -Credential $LAdminCreds"

                Invoke-Command -ComputerName $ComputerName -ScriptBlock { Install-ADDSForest -CreateDnsDelegation:$False -DatabasePath $using:DatabasePath -DomainMode $using:DomainMode -DomainName $using:DomainName -SafeModeAdministratorPassword $using:SafeModeAdminPassword -DomainNetbiosName $using:NetbiosName -ForestMode $using:ForestMode -InstallDns:$True -LogPath $using:LogPath -NoRebootOnCompletion:$False -SysvolPath $using:SysvolPath -Force:$True } -Credential $LAdminCreds | Out-Null

            }
            Else {

                Write-LogDebug "Install-ADDSForest -CreateDnsDelegation:$false -DatabasePath $DatabasePath -DomainMode $DomainMode -DomainName $DomainName -SafeModeAdministratorPassword $SafeModeAdminPassword -DomainNetbiosName $NetbiosName -ForestMode $ForestMode -InstallDns:$true -LogPath $LogPath -NoRebootOnCompletion:$False -SysvolPath $SysvolPath -Force:$true"

                Install-ADDSForest -CreateDnsDelegation:$false -DatabasePath $DatabasePath -DomainMode $DomainMode -DomainName $DomainName -SafeModeAdministratorPassword $SafeModeAdminPassword -DomainNetbiosName $NetbiosName -ForestMode $ForestMode -InstallDns:$true -LogPath $LogPath -NoRebootOnCompletion:$False -SysvolPath $SysvolPath -Force:$true | Out-Null
            }

            Write-LogInfo "Forest root DC setup is completed :: $DomainName"
            $respCode = 0

        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage"
            $respCode = 2        
        }
        Write-LogInfo "Exiting Function Install-RootDC with respCode :: $respCode" 
        return $respCode
    }
}

<#
    .SYNOPSIS
        Creates a child domain controller in existing Forest
    .DESCRIPTION
        Function Install-ChildDC creates a domain controller in existing Forest. It also adds the server to root DNS.
    .PARAMETER EAdminCredential
        Specifies the enterprise admin user name and password (account credentials) for creating the DNS delegation.
    .PARAMETER DomainName
        Specifies the new domain name that this cmdlet installs.
    .PARAMETER ParentDomainName
        Specifies the fully qualified domain name (FQDN) of an existing parent domain.
    .PARAMETER SiteName
        Specifies the name of an existing site where you can place the new domain controller.
    .PARAMETER DomainMode
        Specifies the domain functional level of the first domain in the creation of a new forest i.e Win2008, Win2008R2, Win2012, Win2012R2, WinThreshold, Default
    .PARAMETER SafeModeAdminPassword
        Specifies the password for the administrator account when the computer is started in Safe Mode or a variant of Safe Mode.
    .PARAMETER NetbiosName
        Specifies the NetBIOS name for the new domain.
    .PARAMETER LogPath
        Specifies the fully qualified, non-UNC path to a directory on a fixed disk of the local computer that contains the domain log files.
    .PARAMETER SysvolPath
        Specifies the fully qualified, non-UNC path to a directory on a fixed disk of the local computer.
    .PARAMETER DatabasePath
        Specifies the fully qualified, non-Universal Naming Convention (UNC) path to a directory on a fixed disk of the local computer that contains the domain database.
    .PARAMETER IntfAlias
        Specifies the friendly name of the interface.
    .PARAMETER DNServer
        Specifies a list of DNS server IP addresses to set for the interface.
    .PARAMETER ComputerName
        Computer name or ip address of the remote host server.
    .PARAMETER LAdminCreds
        PSCredential object with host's admin credentials
    .OUTPUTS
        int
        0 - successfully completed
        1 - when required input params are null/empty
        2 - when unknown error
#>
Function Install-ChildDC {
    [CmdletBinding()]
    [OutputType([int])]

    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [pscredential]
        $EAdminCredential,

        [Parameter(Mandatory = $True, Position = 1)]
        [string]
        $DomainName,

        [Parameter(Mandatory = $False, Position = 2)]
        [ValidateSet("ChildDomain", "TreeDomain")]
        [string]
        $DomainType = "ChildDomain",

        [Parameter(Mandatory = $True, Position = 3)]
        [string]
        $ParentDomainName,

        [Parameter(Mandatory = $False, Position = 4)]
        [string]
        $SiteName = "Default-First-Site-Name",

        [Parameter(Mandatory = $False, Position = 5)]
        [string]
        $DomainMode = "WinThreshold",

        [Parameter(Mandatory = $True, Position = 6)]
        [SecureString]
        $SafeModeAdminPassword,

        [Parameter(Mandatory = $True, Position = 7)]
        [string]
        $NetbiosName,

        [Parameter(Mandatory = $False, Position = 8)]
        [string]
        $LogPath = "C:\\Windows\\NTDS",

        [Parameter(Mandatory = $False, Position = 9)]
        [string]
        $SysvolPath = "C:\\Windows\\SYSVOL",

        [Parameter(Mandatory = $False, Position = 10)]
        [string]
        $DatabasePath = "C:\\Windows\\NTDS",

        [Parameter(Mandatory = $False, Position = 11)]
        [string]
        $ComputerName,

        [Parameter(Mandatory = $False, Position = 12)]
        [pscredential]
        $LAdminCreds
    )

    Process {
    
        $respCode = 5

        Write-LogInfo "Inside Function Install-ChildDC." 
        Write-LogDebug "Input DomainName :: $DomainName"
        Write-LogDebug "Input DomainType :: $DomainType" 
        Write-LogDebug "Input DomainMode :: $DomainMode" 
        Write-LogDebug "Input ParentDomainName :: $ParentDomainName" 
        Write-LogDebug "Input SiteName :: $SiteName" 
        Write-LogDebug "Input SafeModeAdminPassword :: $SafeModeAdminPassword" 
        Write-LogDebug "Input NetbiosName :: $NetbiosName" 
        Write-LogDebug "Input LogPath :: $LogPath" 
        Write-LogDebug "Input SysvolPath :: $SysvolPath" 
        Write-LogDebug "Input DatabasePath :: $DatabasePath" 
        Write-LogDebug "Input ComputerName :: $ComputerName" 

        try {

            If ((StringNullOrEmpty $DomainName) -or ($SafeModeAdminPassword.Length -le 0) -or (StringNullOrEmpty $NetbiosName) -or (StringNullOrEmpty $ParentDomainName) -or ($null -eq $EAdminCredential)) {
                $respCode = 1 
                Throw "Required input parameters DomainName / SafeModeAdminPassword / NetbiosName / ParentDomainName / EAdminCredential are null/empty."
            }
           
            If (!(StringNullOrEmpty $ComputerName)) {
                
                Write-LogInfo "Starting child domain creation :: $DomainName" 

                Write-LogDebug "Invoke-Command -ComputerName $ComputerName -ScriptBlock { Import-Module ADDSDeployment} -Credential $LAdminCreds"

                Invoke-Command -ComputerName $ComputerName -ScriptBlock { Import-Module ADDSDeployment } -Credential $LAdminCreds | Out-Null

                Write-LogDebug "Invoke-Command -ComputerName $ComputerName -ScriptBlock { Install-ADDSDomain -NoGlobalCatalog:$false -CreateDnsDelegation:$true -Credential $EAdminCredential -DatabasePath $DatabasePath -DomainMode $DomainMode -DomainType $DomainType -InstallDns:$true -LogPath $LogPath -NewDomainName $DomainName -NewDomainNetbiosName $NetbiosName -ParentDomainName $ParentDomainName -NoRebootOnCompletion:$False -SiteName $SiteName -SysvolPath $SysvolPath -Force:$true -SafeModeAdministratorPassword $SafeModeAdminPassword } -Credential $LAdminCreds | Out-Null"

                Invoke-Command -ComputerName $ComputerName -ScriptBlock { Install-ADDSDomain -NoGlobalCatalog:$false -CreateDnsDelegation:$true -Credential $using:EAdminCredential -DatabasePath $using:DatabasePath -DomainMode $using:DomainMode -DomainType $using:DomainType -InstallDns:$true -LogPath $using:LogPath -NewDomainName $using:DomainName -NewDomainNetbiosName $using:NetbiosName -ParentDomainName $using:ParentDomainName -NoRebootOnCompletion:$False -SiteName $using:SiteName -SysvolPath $using:SysvolPath -Force:$true -SafeModeAdministratorPassword $using:SafeModeAdminPassword } -Credential $LAdminCreds | Out-Null

            }
            Else {
                
                Write-LogInfo "Starting child domain creation :: $DomainName" 

                Import-Module ADDSDeployment

                Write-LogDebug"Install-ADDSDomain -NoGlobalCatalog:$false -CreateDnsDelegation:$true -Credential $EAdminCredential -DatabasePath $DatabasePath -DomainMode $DomainMode -DomainType $DomainType -InstallDns:$true -LogPath $LogPath -NewDomainName $DomainName -NewDomainNetbiosName $NetbiosName -ParentDomainName $ParentDomainName -NoRebootOnCompletion:$False -SiteName $SiteName -SysvolPath $SysvolPath -Force:$true -SafeModeAdministratorPassword $SafeModeAdminPassword | Out-Null"

                Install-ADDSDomain -NoGlobalCatalog:$false -CreateDnsDelegation:$true -Credential $EAdminCredential -DatabasePath $DatabasePath -DomainMode $DomainMode -DomainType $DomainType -InstallDns:$true -LogPath $LogPath -NewDomainName $DomainName -NewDomainNetbiosName $NetbiosName -ParentDomainName $ParentDomainName -NoRebootOnCompletion:$False -SiteName $SiteName -SysvolPath $SysvolPath -Force:$true -SafeModeAdministratorPassword $SafeModeAdminPassword | Out-Null

            }
            Write-LogInfo "Child DC setup is completed :: $DomainName" 
            $respCode = 0

        }
        Catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage" 
            If (($null -eq $respCode) -or (0 -eq $respCode)) {
                $respCode = 2
            }            
        }
        Write-LogInfo "Exiting Function Install-ChildDC with respCode :: $respCode" 
        return $respCode
    }
}

<#
    .SYNOPSIS
        Add computer to AD domain.
    .DESCRIPTION
        Function Add-ComputerToDomain will add the computer to AD domain and reboot the computer.
    .PARAMETER ComputerName,
        Remote computer name or ip address. For multiple computers, provide comma separated values i.e. Svr01,Svr02,Svr03
        If computers are not connected to right DNS server then use IP Addresses.
    .PARAMETER LAdminCreds
        PSCredential object with local admin credentials
    .PARAMETER DomainName,
        AD Domain Name
    .PARAMETER DAdminCreds
        PSCredential object with domain admin credentials
    .PARAMETER DoRestart
        Bool. Control whether to reboot computer automatically
    .OUTPUTS
        int
        0 - successfully completed
        1 - when required input params are null/empty
        2 - when add-to-domain operation failure
        3 - when unknown error
#>
Function Add-ComputerToDomain {
    [CmdletBinding()]
    [OutputType([int])]
    
    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [string]
        $ComputerName,

        [Parameter(Mandatory = $True, Position = 1)]
        [pscredential]
        $LAdminCreds,

        [Parameter(Mandatory = $True, Position = 2)]
        [string]
        $DomainName,

        [Parameter(Mandatory = $True, Position = 3)]
        [pscredential]
        $DAdminCreds,

        [Parameter(Mandatory = $false, Position = 4)]
        [bool]
        $DoRestart = $true
    )

    Process {
        $respCode = 3
        Write-LogInfo "Entering Function Add-ComputerToDomain." 
        try {
            Write-LogDebug "Input ComputerName :: $ComputerName" 
            Write-LogDebug "Input DomainName :: $DomainName" 
            Write-LogDebug "Input DoRestart :: $DoRestart" 

            If ((StringNullOrEmpty $ComputerName) -or (StringNullOrEmpty $DomainName)) {
                Write-LogError "Input parameters are null/empty."
                $respCode = 1
            }
            Else {
                Write-LogInfo "Adding $ComputerName to $DomainName"
                Write-LogDebug "Add-Computer -ComputerName $ComputerName -LocalCredential $LAdminCreds -DomainName $DomainName -Credential $DAdminCreds -Restart:$DoRestart -Force -PassThru" 
                $changeInfo = Add-Computer -ComputerName $ComputerName -LocalCredential $LAdminCreds -DomainName $DomainName -Credential $DAdminCreds -Restart:$DoRestart -Force -PassThru
                $changeResp = $changeInfo.HasSucceeded
                Write-LogDebug "Did Add-Computer cmdlet succeed :: $changeResp" 

                If ($changeResp) {
                    Write-LogDebug "$ComputerName added to $DomainName successfully."
                    $respCode = 0
                }
                Else {
                    Write-LogDebug "$ComputerName could not be added to $DomainName"
                    $respCode = 2
                }
            }                
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage" 
            $respCode = 3
        }
        Write-LogInfo "Exiting Function Add-ComputerToDomain with respCode :: $respCode"
        return $respCode
    }
}


<#
    .SYNOPSIS
        Orchestration function for domain controller setup
    .DESCRIPTION
        Function Install-DomainController orchestrates the domain controller setup steps for AD setup
    .PARAMETER ConfigJSON,
        Specifies the PSCustomObject paramter with domain controller configuration data.
    .OUTPUTS
        int
        0 - successfully completed
        1 - Required configuration for DC setup is missing from the cofig file
        2 - Local admin credentials were null.
        3 - Rename and reboot was not successful
        4 - Windows features installation was not successful
        5 - Root domain controller promotion was not successful
        6 - Configuration is missing for InterfaceAlias/DNSServer
        7 - DNS Server configuration not successful
        8 - Configuration is missing for EAUsername/EAPassword/ParentDomainName/RootDomainName
        9 - Enterprise admin's credentials were returned as null
        10 - Child domain controller promotion was not successful
        11 - Unsupported domain type found
		12 - Failed to reboot server after promotion to domain controller
		13 - Unknown exception occured
#>
Function Install-DomainController {
    [CmdletBinding()]
    [OutputType([int])]

    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [System.Object]
        $ConfigJSON
    ) 

    Process {
        $respCode = 1

        Write-LogInfo "Inside Function Install-DomainController."
        $ServerName = $ConfigJSON.'ServerName'
        $LAUsername = $ConfigJSON.'LAUsername'
        $LAPassword = $ConfigJSON.'LAPassword'
        $IpAddress = $ConfigJSON.'IpAddress'
        $DomainType = $ConfigJSON.'DomainType'
        $DomainName = $ConfigJSON.'DomainName'
        $SafeModeAdminPassword = $ConfigJSON.'SafeModeAdminPassword'
        $NetbiosName = $ConfigJSON.'NetbiosName'

        Try {
            #null checks
            If ((StringNullOrEmpty $ServerName) -or (StringNullOrEmpty $LAUsername) -or (StringNullOrEmpty $LAPassword) -or (StringNullOrEmpty $IpAddress) -or (StringNullOrEmpty $DomainType) -or (StringNullOrEmpty $DomainName) -or (StringNullOrEmpty $SafeModeAdminPassword) -or (StringNullOrEmpty $NetbiosName)) {
                $respCode = 1
                Throw "Required configuration (ServerName / LAUsername / LAPassword / IpAddress / DomainType / DomainName / SafeModeAdminPassword / NetbiosName) for DC setup is missing from the cofig file."
            }

            $SafeModeAdminPassword = Convert-PasswordToSecureString $SafeModeAdminPassword
            $LACredentials = Get-PSCredentials $LAUsername (Convert-PasswordToSecureString (Convert-Password $LAPassword))
            If ($null -eq $LACredentials) {
                $respCode = 2
                Throw "Local admin credentials were null."
            }

            Write-LogInfo "-------- START : STEP 1 --> RENAME and REBOOT --------"
            $renameResp = 1
            If ($ConfigJSON.'SkipRename') {
                Write-LogInfo "Skipping server rename step for $ServerName"
                $renameResp = 0
            }
            Else {
                $renameResp = Rename-AndReboot $IpAddress $ServerName $LACredentials
                Write-LogDebug "renameResp :: $renameResp"
            }
            Write-LogInfo "Did rename and reboot succeed for $IpAddress $ServerName :: $renameResp"
            If ($renameResp -ne 0) {
                $respCode = 3
                Throw "Rename and reboot was not successful for $IpAddress $ServerName"
            }
            Write-LogInfo "-------- END : STEP 1 --> RENAME and REBOOT --------"
            
            Write-LogInfo "-------- START : STEP 2 --> ADD WINDOWS FEATURES FOR DOMAIN CONTROLLER --------"
            $featureResp = 1
            If ($ConfigJSON.'SkipWinFeatures') {
                Write-LogInfo "Skipping windows features installation for $ServerName"
                $featureResp = 0
            }
            Else {
                $featureResp = Add-ADDCFeatures $IpAddress $LACredentials
                Write-LogDebug "featureResp :: $featureResp"
            }
            Write-LogInfo "Did windows features installation succeed for $IpAddress $ServerName :: $featureResp"
            If ($featureResp -ne 0) {
                $respCode = 4
                Throw "Windows features installation was not successful for $IpAddress $ServerName"
            }
            Write-LogInfo "-------- END : STEP 2 --> ADD WINDOWS FEATURES FOR DOMAIN CONTROLLER --------"

            #Separate flow for Child and Root
            $dcPromoResp = 1
            If ($DomainType -eq "RootDomain") {
                Write-LogInfo "-------- START : STEP 3 --> PROMOTE TO ROOT DOMAIN CONTROLLER --------"
                If ($ConfigJSON.'SkipDCPromo') {
                    Write-LogInfo "Skipping promotion to root domain controller for $ServerName"
                    $dcPromoResp = 0
                }
                Else {
                    $PSBoundParameters.Clear()
                    $RootDCParameters = $PSBoundParameters
                    $RootDCParameters.Add('DomainName', $DomainName)
                    $RootDCParameters.Add('SafeModeAdminPassword', $SafeModeAdminPassword)
                    $RootDCParameters.Add('NetbiosName', $NetbiosName)
                    $RootDCParameters.Add('ComputerName', $IpAddress)
                    $RootDCParameters.Add('LAdminCreds', $LACredentials)
                    
                    #add optional params
                    $RootDCParameters.Add('DomainMode', $ConfigJSON.'DomainMode')
                    $RootDCParameters.Add('ForestMode', $ConfigJSON.'ForestMode')
                    $RootDCParameters.Add('LogPath', $ConfigJSON.'LogPath')
                    $RootDCParameters.Add('SysvolPath', $ConfigJSON.'SysvolPath')
                    $RootDCParameters.Add('DatabasePath', $ConfigJSON.'DatabasePath')

                    #Call root dc setup 
                    $dcPromoResp = Install-RootDC @RootDCParameters
                }
                Write-LogInfo "Did root domain controller promotion succeed for $IpAddress $ServerName :: $dcPromoResp"
                If ($dcPromoResp -ne 0) {
                    $respCode = 5
                    Throw "Root domain controller promotion was not successful for $IpAddress $ServerName"
                }
                Write-LogInfo "-------- END : STEP 3 --> PROMOTE TO ROOT DOMAIN CONTROLLER --------"

            }
            ElseIf ($DomainType -eq "ChildDomain") {
                Write-LogInfo "-------- START : STEP 3 --> SETUP PREFERRED DNS SERVER ADDRESS --------"
                $dnsResp = 1
                If ($ConfigJSON.'SkipDnsServer') {
                    Write-LogInfo "Skipping root DC as DNS server setup for $ServerName"
                    $dnsResp = 0
                }
                Else {
                    $InterfaceAlias = $ConfigJSON.'InterfaceAlias'
                    Write-LogDebug "InterfaceAlias from config file :: $InterfaceAlias"
                    If (StringNullOrEmpty $InterfaceAlias) {
                        $InterfaceAlias = Get-InterfaceAliasByIP $IpAddress $IpAddress $LACredentials
                    }
                    Write-LogDebug "Final InterfaceAlias :: $InterfaceAlias"
                    $DNSServer = $ConfigJSON.'DNSServer'
                    Write-LogDebug "DNSServer :: $DNSServer"
                    If ((StringNullOrEmpty $InterfaceAlias) -or (StringNullOrEmpty $DNSServer)) {
                        $respCode = 6
                        Throw "Configuration is missing for InterfaceAlias/DNSServer."
                    }
                    #Setup DNS Server
                    $dnsResp = Set-InterfaceDNS $InterfaceAlias $DNSServer $LACredentials $IpAddress
                    Write-LogInfo "Did DNS Server configuratio succeed for $IpAddress $ServerName :: $dnsResp"
                    If ($dnsResp -ne 0) {
                        $respCode = 7
                        Throw "DNS Server configuration not successful for $IpAddress $ServerName"
                    }
                }
                Write-LogInfo "-------- END : STEP 3 --> SETUP PREFERRED DNS SERVER ADDRESS --------"

                #DC Setup
                Write-LogInfo "-------- START : STEP 4 --> PROMOTE TO CHILD DOMAIN CONTROLLER IN EXISTING FOREST --------"
                If ($ConfigJSON.'SkipDCPromo') {
                    Write-LogInfo "Skipping promotion to child domain controller in existing forest for $ServerName"
                    $dcPromoResp = 0
                }
                Else {
                    #Child DC setup
                    $EAUsername = $ConfigJSON.'EAUsername'
                    Write-LogDebug "EAUsername :: $EAUsername"
                    $EAPassword = $ConfigJSON.'EAPassword'
                    $ParentDomainName = $ConfigJSON.'ParentDomainName'
                    Write-LogDebug "ParentDomainName :: $ParentDomainName"
                    $RootDomainName = $ConfigJSON.'RootDomainName'
                    Write-LogDebug "RootDomainName :: $RootDomainName"
                    If ((StringNullOrEmpty $EAUsername) -or (StringNullOrEmpty $EAPassword) -or (StringNullOrEmpty $ParentDomainName) -or (StringNullOrEmpty $RootDomainName)) {
                        $respCode = 8
                        Throw "Configuration is missing for EAUsername/EAPassword/ParentDomainName/RootDomainName."
                    }

                    $EAPassword = Convert-PasswordToSecureString (Convert-Password $EAPassword)
                    $EACredentials = Get-PSCredentials ($RootDomainName + '\' + $EAUsername) $EAPassword
                    If ($null -eq $EACredentials) {
                        $respCode = 9
                        Throw "Enterprise admin's credentials were returned as null."
                    }

                    #Input object
                    $PSBoundParameters.Clear()
                    $ChildDCParameters = $PSBoundParameters
                    #Mandatory params
                    $ChildDCParameters.Add('EAdminCredential', $EACredentials)
                    $ChildDCParameters.Add('DomainName', $DomainName)                    
                    $ChildDCParameters.Add('ParentDomainName', $ParentDomainName)
                    $ChildDCParameters.Add('SafeModeAdminPassword', $SafeModeAdminPassword)
                    $ChildDCParameters.Add('NetbiosName', $NetbiosName)
                    $ChildDCParameters.Add('ComputerName', $IpAddress)
                    $ChildDCParameters.Add('LAdminCreds', $LACredentials)
                    
                    #Optional params
                    $ChildDCParameters.Add('DomainType', $DomainType)
                    $ChildDCParameters.Add('SiteName', $ConfigJSON.'SiteName')
                    $ChildDCParameters.Add('DomainMode', $ConfigJSON.'DomainMode')
                    $ChildDCParameters.Add('LogPath', $ConfigJSON.'LogPath')
                    $ChildDCParameters.Add('SysvolPath', $ConfigJSON.'SysvolPath')
                    $ChildDCParameters.Add('DatabasePath', $ConfigJSON.'DatabasePath')

                    $dcPromoResp = Install-ChildDC @ChildDCParameters
                }
                Write-LogInfo "Did child domain controller promotion succeed for $IpAddress $ServerName :: $dcPromoResp"
                If ($dcPromoResp -ne 0) {
                    $respCode = 10
                    Throw "Child domain controller promotion was not successful for $IpAddress $ServerName"
                }
                Write-LogInfo "-------- END : STEP 4 --> PROMOTE TO CHILD DOMAIN CONTROLLER IN EXISTING FOREST --------"

            }
            Else {
                $respCode = 11
                Throw "Unsupported domain type $DomainType found. Supported values are [RootDomain , ChildDomain]"
            }

            #Wait for reboot
            $serverRebooted = Wait-ForConnection $IpAddress 389 
            Write-LogDebug "serverRebooted :: $serverRebooted"
            If ($serverRebooted -ne 0) {
                $respCode = 12
                Throw "Failed to reboot $IpAddress $ServerName after promotion to domain controller."
            }

            #Add Reverse DNS lookup zone :: Known issue 1 --> After reboot, DNS server is not detected.
            If ($DomainType -eq "RootDomain") {
                $revDnsResp = 1
                If ($ConfigJSON.'SkipRevDns') {
                    Write-LogInfo "Skipping reverse DNS lookup zone setup for $IpAddress $ServerName"
                    $revDnsResp = 0
                }
                Else {
                    Write-LogInfo "-------- START : STEP 4 --> ADD REVERSE DNS LOOKUP ZONE --------"
                    $revDnsResp = Add-ReverseDNSZone $IpAddress $ConfigJSON.'RevDNSLastOct' $IpAddress $LACredentials
                    Write-LogDebug "revDnsResp :: $revDnsResp"
                    Write-LogInfo "Did reverse dns lookup zone setup succeed for $IpAddress $ServerName :: $revDnsResp"
                    If ($revDnsResp -ne 0) {
                        Write-LogError "Reverse dns lookup zone failed for $IpAddress $ServerName | Please check the configuration and retry."
                    }
                    Write-LogInfo "-------- END : STEP 4 --> ADD REVERSE DNS LOOKUP ZONE --------"
                }
            }

            #Final respCode
            $respCode = 0
        }
        Catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            $FailedItem = $_.Exception.ItemName
            Write-LogError "$FailedItem :: $ErrorMessage"
            If (($respCode -eq $null) -or ($respCode -eq 0)) {
                $respCode = 13
            }
        }
        Write-LogInfo "Exiting Function Install-DomainController. Response code :: $respCode"
        return $respCode
    }
}
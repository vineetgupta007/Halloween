<#
.Synopsis
   Initialize log4net [version 1.2.15] logger
.DESCRIPTION
   Function Initialize-Logger will initialize the log4net logger to write to logfiles or console. Log file will be created in $pwd\..\log directory
.EXAMPLE
   Initialize-Logger -LogLevel "Warn" -Type "file" -FileName "MyLog" -Verbose
.PARAMETER LogLevel
   Input Threshold log level ['Debug', 'Info', 'Warn', 'Error', 'Fatal']
.PARAMETER Type
   Input logging type ['file', 'console']
.PARAMETER FileName
   Input Log file name for logger. Logger file name will be appended with .log automatically
#>
Function Initialize-Logger {
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory = $false, Position = 0)]
        [ValidateSet('Debug', 'Info', 'Warn', 'Error', 'Fatal')]
        [string]$LogLevel = "Info",

        [Parameter(Mandatory = $false, Position = 1)]
        [ValidateSet('File', 'Console')]
        [string]$Type = 'Console',

        [Parameter(Mandatory = $false, Position = 2)]
        [string]$FileName
    )

    Process {
        Write-Verbose "[LOG] Logger initialization"
        try {
            Write-Verbose "[LOG] CURRENT_PATH is : '$CURRENT_PATH'"
            Write-Verbose "[LOG] SCRIPT_PATH is : '$SCRIPT_PATH'"
            Write-Verbose "[LOG] FULL_SCRIPT_PATH is : '$FULL_SCRIPT_PATH'"

            $log4netDllPath = Resolve-Path $SCRIPT_PATH\bin\log4net.dll -ErrorAction SilentlyContinue -ErrorVariable Err
            If ($Err) {
                throw "Log4net library cannot be found on the path $SCRIPT_PATH\bin\log4net.dll"
            }
            Else {
                Write-Verbose "[LOG] Log4net dll path is : '$log4netDllPath'"
                [void][Reflection.Assembly]::LoadFile($log4netDllPath)
                [log4net.LogManager]::ResetConfiguration();

                If (($Type -eq "File") -and ($FileName)) {
                    $FileApndr = new-object log4net.Appender.FileAppender([log4net.Layout.ILayout](new-object log4net.Layout.PatternLayout('[%date{yyyy-MM-dd HH:mm:ss.fff} ] [%level] [%message]%n')), ($CURRENT_PATH + '\..\log\' + $FileName + '.log'));
                    $FileApndr.Threshold = [log4net.Core.Level]::$LogLevel;
                    [log4net.Config.BasicConfigurator]::Configure($FileApndr);
                }
                Else {
                    #Example of Colored Console Appender initialization
                    $ColConsApndr = new-object log4net.Appender.ColoredConsoleAppender(([log4net.Layout.ILayout](new-object log4net.Layout.PatternLayout('[%date{yyyy-MM-dd HH:mm:ss.fff}] %message%n'))));
                    $ColConsApndrDebugCollorScheme = new-object log4net.Appender.ColoredConsoleAppender+LevelColors; $ColConsApndrDebugCollorScheme.Level = [log4net.Core.Level]::Debug; $ColConsApndrDebugCollorScheme.ForeColor = [log4net.Appender.ColoredConsoleAppender+Colors]::Green;
                    $ColConsApndr.AddMapping($ColConsApndrDebugCollorScheme);
                    $ColConsApndrInfoCollorScheme = new-object log4net.Appender.ColoredConsoleAppender+LevelColors; $ColConsApndrInfoCollorScheme.level = [log4net.Core.Level]::Info; $ColConsApndrInfoCollorScheme.ForeColor = [log4net.Appender.ColoredConsoleAppender+Colors]::White;
                    $ColConsApndr.AddMapping($ColConsApndrInfoCollorScheme);
                    $ColConsApndrWarnCollorScheme = new-object log4net.Appender.ColoredConsoleAppender+LevelColors; $ColConsApndrWarnCollorScheme.level = [log4net.Core.Level]::Warn; $ColConsApndrWarnCollorScheme.ForeColor = [log4net.Appender.ColoredConsoleAppender+Colors]::Yellow;
                    $ColConsApndr.AddMapping($ColConsApndrWarnCollorScheme);
                    $ColConsApndrErrorCollorScheme = new-object log4net.Appender.ColoredConsoleAppender+LevelColors; $ColConsApndrErrorCollorScheme.level = [log4net.Core.Level]::Error; $ColConsApndrErrorCollorScheme.ForeColor = [log4net.Appender.ColoredConsoleAppender+Colors]::Red;
                    $ColConsApndr.AddMapping($ColConsApndrErrorCollorScheme);
                    $ColConsApndrFatalCollorScheme = new-object log4net.Appender.ColoredConsoleAppender+LevelColors; $ColConsApndrFatalCollorScheme.level = [log4net.Core.Level]::Fatal; $ColConsApndrFatalCollorScheme.ForeColor = ([log4net.Appender.ColoredConsoleAppender+Colors]::HighIntensity -bxor [log4net.Appender.ColoredConsoleAppender+Colors]::Red);
                    $ColConsApndr.AddMapping($ColConsApndrFatalCollorScheme);
                    $ColConsApndr.ActivateOptions();
                    $ColConsApndr.Threshold = [log4net.Core.Level]::$LogLevel;
                    [log4net.Config.BasicConfigurator]::Configure($ColConsApndr);
                }
            }
            If ($null -ne $Global:LOGGER) {
                Write-Verbose "[LOG] Closing old logger."
                $OLD_LOGGER = $Global:LOGGER
                Write-Verbose "[LOG] Initializing new logger."
                $Global:LOGGER = [log4net.LogManager]::GetLogger("root");
                try {
                    Remove-Logger -OldLogger $OLD_LOGGER
                }
                catch {
                    Write-Verbose "[LOG] Old Logger could not be closed."
                    Write-Error $_.Exception.Message
                }            
            }
            Else {
                Write-Verbose "[LOG] Initializing new logger."
                $Global:LOGGER = [log4net.LogManager]::GetLogger("root");
            } 
            Write-Verbose "[LOG] Logger is initialized."

        }
        catch {
            Write-Verbose "[LOG] Logger could not be initialized."
            Write-Error $_.Exception.Message
        }

    }
}


<#
.Synopsis
   Only for internal use. Generic messsage logger
#>
Function WriteMessage {
    [CmdletBinding()]
    Param(
        [string]$Message,
        [string]$Level,
        [string]$Color
    )
    Process {
        try {
            If ($null -ne $Global:LOGGER) {
                $Global:LOGGER.$Level($Message)
            }
            Else {
                Initialize-Logger
                $Global:LOGGER.$Level($Message)
            }                
        }
        catch {
            WriteHost $Message -Color $Color
        }
    }
}

<#
.Synopsis
   Only for internal use. Logs to host console
#>
Function WriteHost {
    [CmdletBinding()]
    Param(
        [Parameter(ValueFromPipeline = $true, Position = 1)]
        $Object,
        [switch]$NoNewLine,
        $Color = "White"
    )
    process {
        Write-Host -Object $Object -ForegroundColor $Color -NoNewline:$NoNewLine -Separator ","
    }
}

<#
.Synopsis
   Logs a warning message
#>
Function Write-LogWarning {
    [CmdletBinding()]
    Param(
        [string]$Text
    )
    Process {
        WriteMessage -Message $Text -Level 'Warn' -Color 'Yellow'
    }
}

<#
.Synopsis
   Logs a Info message
#>
Function Write-LogInfo {
    [CmdletBinding()]
    Param(
        [string]$Text
    )
    Process {
        WriteMessage -Message $Text -Level 'Info' -Color 'White'
    }
}

<#
.Synopsis
   Logs a Debug message
#>
Function Write-LogDebug {
    [CmdletBinding()]
    Param(
        [string]$Text
    )
    Process {
        WriteMessage -Message $Text -Level 'Debug' -Color 'White'
    }
}

<#
.Synopsis
   Logs a Error message
#>
Function Write-LogError {
    [CmdletBinding()]
    Param(
        [string]$Text
    )
    Process {
        WriteMessage -Message $Text -Level 'Error' -Color 'Red'
    }
}

<#
.Synopsis
   Logs a Fatal message
#>
Function Write-LogFatal {
    [CmdletBinding()]
    Param(
        [string]$Text
    )
    Process {
        WriteMessage -Message $Text -Level 'Fatal' -Color 'Red'
    }
}

<#
.Synopsis
   Logs a verbose message
#>
Function Write-LogVerbose {
    [CmdletBinding()]
    Param(
        [string]$Text
    )
    Process {
        WriteMessage -Message $Text -Level 'Debug' -Color 'Yellow'
    }
}

<#
.Synopsis
   Remove existing Logger. You can only run one logger, to restart, remove first.
#>
Function Remove-Logger() {
    [CmdletBinding()]
    Param(
        [string]$OldLogger
    )

    Process {
        #TODO: Change the log close/shutdown
        $OldLogger = $null
    }
}
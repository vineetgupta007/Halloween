<#
    .SYNOPSIS
        This contains all the common utility functions
    .DESCRIPTION
        This contains all the common utility functions

#>

<#
    .SYNOPSIS
        This function is used for creating ARM template for Workbook
    .DESCRIPTION
        This function is used for creating ARM template for Workbook by replacing properties with provided values
    .PARAMETER SelAzLaws
        Defines the argument containing all the property values
    .PARAMETER templateFileName
        Full path of the template file
    .PARAMETER copyTemplateFileName
        Full path of the new file created from template
    .OUTPUTS
        Exit Codes:
        0 - successfully completed
        1 - Unknown exception occured
    .EXAMPLE
       Create-Template -SelAzLaws $AZAssessmentProps -templateFileName $workbookTemplatePath\"workbookTemplate.json" -copyTemplateFileName $workbookTemplatePath\"workbook.json"
#>
Function Create-Template {

    [CmdletBinding()]
    [OutputType([Int])]
    param (
        [Parameter(Mandatory = $True, Position = 0)]
        [PSCustomObject]$SelAzLaws,
        
        [Parameter(Mandatory = $True, Position = 1)]
        [string]$templateFileName,

        [Parameter(Mandatory = $True, Position = 2)]
        [string]$copyTemplateFileName
        
    )
    Process {
    
        Write-LogInfo "Entering Function Create-Template"
        try {
            #Deafult exit code
            $LASTEXITCODE = 1
            $TempProps = Get-Content -Path  $templateFileName
            foreach ($key in  $SelAzLaws.psobject.properties.name) {
                $keyName = "%%$key%%"
                $keyValue = $SelAzLaws.$key
                $TempProps = $TempProps -replace $keyName, $keyValue
            }
            $FileName = $copyTemplateFileName
            $TempProps | Out-File $FileName
            if (Test-Path $FileName) {
                $LASTEXITCODE = 0
                Write-LogDebug "Template File Created successfully"
            }
        }
        catch [System.Exception] {
            $ErrorMessage = $_.Exception.Message
            Write-LogError "Message ::  $ErrorMessage"
           
        }
        Write-LogInfo "Exiting Function Create-Template"
        return $LASTEXITCODE
    }
}

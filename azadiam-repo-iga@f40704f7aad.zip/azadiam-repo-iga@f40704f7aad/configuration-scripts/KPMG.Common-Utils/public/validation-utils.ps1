<#
    .SYNOPSIS
        Check string for null/empty/whitespace
    .DESCRIPTION
        Function StringNullOrEmpty returns True if string is Null/Empty/WhiteSpaces.
    .PARAMETER s
        Input string
    .OUTPUTS
        bool. True if string is null/empty/whitespace. Else False.
#>
Function StringNullOrEmpty {
    [CmdletBinding()]
    [OutputType([bool])]
    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [AllowEmptyString()]
        [string]
        $s
    )

    Process {

        If (([string]::IsNullOrEmpty($s)) -or ([string]::IsNullorWhitespace($s))) {
            return $True
        }
        Else {
            return $False
        }
    }
}

<#
    .SYNOPSIS
        Check HashTable for null/empty
    .DESCRIPTION
        Function HashTableNullOrEmpty returns True if HashTable is Null/Empty.
    .PARAMETER h
        Input System.Collections.Hashtable
    .OUTPUTS
        bool. True if HashTable is null/empty. Else False.
#>
Function HashTableNullOrEmpty {
    [CmdletBinding()]
    [OutputType([bool])]
    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [System.Collections.Hashtable]
        $h
    )

    Process {

        If ($h -eq $Null) {
            return $True
        }
        ElseIf (($h -ne $Null) -and ($h.Count -eq 0)) {
            return $True
        }
        Else {
            return $False
        }
    }
}

<#
    .SYNOPSIS
        Check ip address validity of a string
    .DESCRIPTION
        Function IsIPAddressValid checks ip address validity of a string
    .PARAMETER ip
        Input ip address string
    .OUTPUTS
        bool. True if ip address valid. Else False.
#>
Function IsIPAddressValid {
    [CmdletBinding()]
    [OutputType([bool])]
    Param(
        [Parameter(Mandatory = $True, Position = 0)]
        [AllowEmptyString()]
        [string]
        $ip
    )
    
    Process {
        $ipValidator = '^((25[0-5]|(2[0-4]|1[0-9]|[1-9]|)[0-9])(\.(?!$)|$)){4}$'

        If (([string]::IsNullOrEmpty($ip)) -or ([string]::IsNullorWhitespace($ip))) {
            return $false
        }
        Else {
            return ($ip -match $ipValidator)
        }
    }        
}
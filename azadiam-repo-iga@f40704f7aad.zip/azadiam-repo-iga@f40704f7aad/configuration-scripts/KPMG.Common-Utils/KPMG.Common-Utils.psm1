#Get public and private function definition files.
$Public = @( Get-ChildItem -Path $PSScriptRoot\public\*.ps1 -ErrorAction SilentlyContinue )
$Private = @( Get-ChildItem -Path $PSScriptRoot\private\*.ps1 -ErrorAction SilentlyContinue )

#Load module source files
Foreach ($import in @($Public + $Private)) {
    try {
        . $import.fullname
    }
    catch {
        Write-Error -Message "Failed to import function $($import.fullname): $_"
    }
}

Set-Variable -Name SCRIPT_PATH -Value (Split-Path (Resolve-Path $myInvocation.MyCommand.Path)) -Scope local
Set-Variable -Name FULL_SCRIPT_PATH -Value (Resolve-Path $myInvocation.MyCommand.Path) -Scope local
Set-Variable -Name CURRENT_PATH -Value ((Get-Location).Path) -Scope local
Set-Variable -Name LOGGER -Value $null -Scope global

#Export Logger util functions
Export-ModuleMember -Function Initialize-Logger
Export-ModuleMember -Function Write-LogWarning
Export-ModuleMember -Function Write-LogInfo
Export-ModuleMember -Function Write-LogDebug
Export-ModuleMember -Function Write-LogError
Export-ModuleMember -Function Write-LogFatal
Export-ModuleMember -Function Write-LogVerbose

#Export Validation util functions
Export-ModuleMember -Function StringNullOrEmpty
Export-ModuleMember -Function HashTableNullOrEmpty
Export-ModuleMember -Function IsIPAddressValid

#Export Security util functions
Export-ModuleMember -Function Convert-Password
Export-ModuleMember -Function Convert-PasswordToSecureString
Export-ModuleMember -Function Get-PSCredentials

#Export File util functions
Export-ModuleMember -Function Get-JSONFileData
Export-ModuleMember -Function Get-ConfigfromJSON
Export-ModuleMember -Function validateDataInCSV
Export-ModuleMember -Function Get-HeaderColumnCount
Export-ModuleMember -Function Get-ConfigfromKey

#Export General util functions
Export-ModuleMember -Function Create-Template
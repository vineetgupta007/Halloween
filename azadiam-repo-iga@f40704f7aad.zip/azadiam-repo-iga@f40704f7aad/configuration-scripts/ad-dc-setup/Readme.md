Module: ad-dc-setup
This module contains scripts associated with Active Directory domain controllers setup and configuration.

# AD Setup

The following scripts are available to orchestrate the installation and configuration of Active Directory Forest with
multiple domain controllers.

|     Script                |     Description                                                                                        |
|---------------------------|--------------------------------------------------------------------------------------------------------|
| SetupADForest.ps1         | An orchestration script to setup domain controllers as a new forest root domain or child domain to an  existing forest. It only supports remote execution. |
| SetupRevDNSLookupZone.ps1 | An orchestration script to add reverse DNS lookup zone to a newly setup root domain controller.It only supports remote execution. |

## Before you begin

### Enable Windows RM (Server)

The scripts leverage WindowsRM capability to install and configure the domain controllers. Before starting the installation
and configuration process, the WindowsRM must be enabled and configured on both the Windows server and powershell client
being used to invoke the script.

The following script with appropriate configuration for the machine can be used to configure the remote access
```
$LocalIPAddress = '<IP address of client machine e.g. 172.16.251.4>'
Enable-PSRemoting -Force;
Set-Item WSMan:\localhost\Client\TrustedHosts -Concatenate -Value '$LocalIPAddress' -Force;
Get-Item WSMan:\localhost\Client\TrustedHosts;
winrm quickconfig -quiet;
Restart-Service WinRM;
```

## Enable Windows RM (Client)

In case Trusted Host is being used for authentication, the same must be enabled on the local machine before running the script.
```
$ServerIPAddress = '<IP Address of server>'
Set-Item WSMan:\localhost\Client\TrustedHosts -Concatenate -Value '$ServerIPAddress' -Force;
```

## Configuration file

The script use a common configuration file available in `$SCRIPTHOME\configuration-scripts\ad-dc-setup\config\config.json`.
The configuration file must be updated with appropriate configuration before running the script.

The configuration file consists of different configuration sets corresponding to each forest, associated domains and domain controllers.

---

***NOTE***

- DO NOT change the parent config key 'ad-dc-setup'
- Every forest config in the file MUST END with the key 'forest' otherwise it'll not be recognized as a forest configuration.
  For example: main-forest, XYZ-forest
- Every domain controller config in the file MUST BEGIN with the key 'DC' otherwise it'll be recognized as a domain controller configuration. 
  For example: DCXYZ, DC1, DC_USA
  
---

The configuration contains the following parameters for the Root Domain setup:

|     Parameter          |Mandatory/Optional (Default Value) |    Description                                                                |
|------------------------|-----------------------------------|-------------------------------------------------------------------------------|
| SkipSetup              | Optional (false)                  | Flag to control DC setup. Set to true to skip full DC setup.                  |
| SkipRename             | Optional (false)                  | Flag to control server rename and reboot step. Set to true to skip rename.    |
| SkipWinFeatures        | Optional (false)                  | Flag to control windows feature installation. Set to true to skip feature     |
|                        |                                   | installation.                                                                 |
| SkipDCPromo            | Optional (false)                  | Flag to control server promotion to domain controller step.                   |
|                        |                                   | Set to true to skip promotion to a domain controller.                         |
| SkipRevDns             | Optional (false)                  | Flag to control reverse DNS setup. Reverse DNS setup will be skipped          |
|                        |                                   | if set to true.                                                               |
| ServerName             | Mandatory                         | Intended computer name for the DC machine.                                    |
| DomainType             | Mandatory                         | 'RootDomain' for root dc in forest.                                           |
| IpAddress              | Mandatory                         | The static IP address of the machine.                                         |
| RevDNSLastOct          | Optional (24)                     | Last octave for Reverse DNS lookup zone. Default is 24.                       |
| DomainName             | Mandatory                         | The intended fully qualified domain name for the forest DC.                   |
| SafeModeAdminPassword  | Mandatory                         | Admin password for the Safe Mode operations.                                  |
| NetbiosName            | Mandatory                         | NetBIOS name for the DC machine. Shouldn't be same as ServerName.             |
|                        |                                   | Not more than 15 chars.                                                       |
| LAUsername             | Mandatory                         | Local admin username for the DC machine.                                      |
| LAPassword             | Mandatory                         | Local admin's password for the DC machine.                                    |
| DomainMode             | Optional (WinThreshold)           | Domain functional level of the first domain in the creation of a new forest.  |
| ForestMode             | Optional (WinThreshold)           | Forest functional level for the new forest.                                   |
| SysvolPath             | Optional (C:\\Windows\\SYSVOL)    | Fully qualified, non-UNC path to a directory where the Sysvol file            |
|                        |                                   | for this operation is written.                                                |
| LogPath                | Optional (C:\\Windows\\NTDS)      | Fully qualified, non-UNC path to a directory where the log file               |
|                        |                                   | for this operation is written.                                                |
| DatabasePath           | Optional (C:\\Windows\\NTDS)      | Fully qualified,non-UNC path to a directory that contains the domain database.|

The configuration contains the following parameters for the Child Domain setup:

|     Parameter          |Mandatory/Optional (Default Value) |    Description                                                                |
|------------------------|-----------------------------------|-------------------------------------------------------------------------------|
| SkipSetup              | Optional (false)                  | Flag to control DC setup. Set to true to skip full DC setup.                  |
| SkipRename             | Optional (false)                  | Flag to control server rename and reboot step. Set to true to skip rename.    |
| SkipWinFeatures        | Optional (false)                  | Flag to control windows feature installation. Set to true to skip             |
|                        |                                   | feature installation.                                                         |
| SkipDCPromo            | Optional (false)                  | Flag to control server promotion to domain controller step. Set to true to    |
|                        |                                   | skip promotion to a domain controller.                                        |
| SkipDnsServer          | Optional (false)                  | Flag to control the DNS server setup. DNS server setup will be skipped        |
|                        |                                   | if set to true.                                                               |
| ServerName             | Mandatory                         | Intended computer name for the DC machine.                                    |
| DomainType             | Mandatory                         | 'ChildDomain' for child dc in forest.                                          |
| IpAddress              | Mandatory                         | The static IP address of the machine.                                         |
| DNSServer              | Mandatory                         | DNS server address of the AD forest. For integrated DNS setup, it'll be       |
|                        |                                   | the same as root DC's IP address.                                             |
| InterfaceAlias         | Optional                          | Network interface alias of child DC. This interface will be used to           |
|                        |                                   | point to Forest's DNS server.                                                 |
| DomainName             | Mandatory                         | Child domain name. Not FQDN. i.e. 'uk' will be DomainName for uk.eu.demo.com  |
|                        |                                   | when joining the eu.demo.com                                                  |
| ParentDomainName       | Mandatory                         | The parent domain name (FQDN) in the existing forest. i.e. eu.demo.com when   |
|                        |                                   | joining the eu.demo.com                                                       |
| RootDomainName         | Mandatory                         | Forest's root domain name (FQDN). i.e. demo.com when joining demo.com forest. |
| SafeModeAdminPassword  | Mandatory                         | Admin password for the Safe Mode operations.                                  |
| NetbiosName            | Mandatory                         | NetBIOS name for the DC machine. Shouldn't be same as ServerName.             |
|                        |                                   | Not more than 15 chars.                                                       |
| LAUsername             | Mandatory                         | Local admin username for the DC machine.                                      |
| LAPassword             | Mandatory                         | Local admin's password for the DC machine.                                    |
| EAUsername             | Mandatory                         | Enterprise admin username from the root domain.                               |
| EAPassword             | Mandatory                         | Enterprise admin password from the root domain.                               |
| DomainMode             | Optional (WinThreshold)           | Domain functional level of the first domain in the creation of a new forest.  |
| ForestMode             | Optional (WinThreshold)           | Forest functional level for the new forest.                                   |
| SysvolPath             | Optional (C:\\Windows\\SYSVOL)    | Fully qualified, non-UNC path to a directory where the Sysvol file for this   |
|                        |                                   | operation is written.                                                         |
| LogPath                | Optional (C:\\Windows\\NTDS)      | Fully qualified, non-UNC path to a directory where the log file for this      |
|                        |                                   | operation is written.                                                         |
| DatabasePath           | Optional (C:\\Windows\\NTDS)      | Fully qualified,non-UNC path to a directory that contains the domain database.|

---
**NOTE**

Remove all the comments, if present, from the configuration file. These are indicated by `//` at the start of the line.

---

## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

The domain controller setup script can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\ad-dc-setup\bin` folder
3. Run script
    ```powershell
    $ .\SetupADForest.ps1 -ConfigToLoad "ad-setup-config"
    ```
    This will install and configure all the domain controllers that are part of the setup.
  In case there is a need to run specific setup, the value passed to parameter `ad-setup-config` must be in
  `ad-setup-config,<forest id>,<domain controller id>` (e.g. `ad-setup-config,main-forest,DC1`) format.

### Examples
1. To setup all forests and DCs with Debug logs on console
    $ .\SetupADForest.ps1 -ConfigFile "config.json" -ConfigToLoad "ad-setup-config" -LogLevel "Debug"
2. To setup specific forest with Debug logs in file
    $ .\SetupADForest.ps1 -ConfigFile "config.json" -ConfigToLoad "ad-setup-config,main-forest" -LogLevel "Debug"
      -Type "File" -FileName "CustomADLogger"
3. To setup specific DC with Warning logs on console
    $ .\SetupADForest.ps1 -ConfigFile "config.json" -ConfigToLoad "ad-setup-config,main-forest,DC1" -LogLevel "Warn"


If the reverse DNS lookup zone fails then please run the SetupRevDNSLookupZone.ps1 script after the domain controller setup is done.
It can be executed as follows:
1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\ad-dc-setup\bin` folder
3. Run script
    ```powershell
    $ .\SetupRevDNSLookupZone.ps1 -ConfigToLoad "ad-setup-config,main-forest,DC1"
    ```
    This will configure the reverse DNS lookup zone for a given DC where it failed earlier.


---

------------------------------------------------------------
# AD Data Load Script
------------------------------------------------------------
This module include scripts to load data in Active Directory. Following operations can be performed using this script:

            1. Create Organizational Unit's
            2. Create Groups
            3. Add User to AD Groups
            4. Create Password Policies
            5. Apply Password Policies to Groups
            6. Create User
            7. Update User's manager
            8. Import Ldif for custom attributes

# AD Data Load Script :: Configuration file
The script use a common configuration file available in `$SCRIPTHOME\configuration-scripts\ad-dc-setup\config\config.json`.
The configuration file must be updated with appropriate configuration before running the script.

***NOTE***
1) DO NOT change the parent config key 'ad-setup-config'
2) Mandatory values needs to be provided
3) Do not change any default values

Mandatory config key in config.json 'ad-dataload'

|     Parameter                  |Mandatory/Optional                     |    Description                                                                                                                  | Allowed Values                                                                                                     |
---------------------------------|---------------------------------------|---------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------|
| ForestToExecute                | Mandatory                             |The forest config i.e. main-forest or partner-forest in which the script should execute                                          | main-forest or partner-forest                                                                                      |
| DCToExecute                    | Mandatory                             |The domain controller in the forest in which the script should execute                                                           | DC1, DC2, etc.                                                                                                     |
| CSVFile                        | Mandatory                             |The path to the location where the CSV file for the operation is placed                                                          | The CSV templates for AD data load operations are available in '$SCRIPTHOME\configuration-scripts\ad-dc-setup\data'|
| createOU                       | Optional                              |Set this flag to Yes if OU should be created, else set No                                                                        | Yes/No                                                                                                             |
| mandatoryColums_createOU       | Mandatory (if createOU is Yes)        |List of mandatory attributes required to be populated in the CSV file to create OU in Active Directory                           | Default Value: ["OrgUnit","OUPath"]                                                                                |
| createGroup                    | Optional                              |Set this flag to Yes if AD group should be created, else set No                                                                  | Yes/No                                                                                                             |
| mandatoryColums_createGroup    | Mandatory (if createGroup is Yes)     |List of mandatory attributes required to be populated in the CSV file to create group in Active Directory                        | Default Values: ["GroupName","GroupPath","GroupCategory","GroupScope"]                                             |
| addUsertoGroup                 | Optional                              |Set this flag to Yes if users should be added to AD groups, else set No                                                          | Yes/No                                                                                                             |
| mandatoryColums_addUsertoGroup | Mandatory (if addUsertoGroup is Yes)  |List of mandatory attributes required to be populated in the CSV file to adding users to groups in Active Directory              | Default Values: ["GroupName","GroupDN","GroupDomain","UserSAMAccountName","UserDN","UserDomain"]                   |
| createPwdPol                   | Optional                              |Set this flag to Yes if password policy should be created, else set No                                                           | Yes/No                                                                                                             |
| mandatoryColums_createPwdPol   | Mandatory (if createPwdPol is Yes)    |List of mandatory attributes required to be populated in the CSV file to creating password policy in Active Directory            | Default Values: ["PasswordPolicyName","Precedence"]                                                                |
| applyGrpPwdPol                 | Optional                              |Set this flag to Yes if password policy should be applied to AD group, else set No                                               | Yes/No                                                                                                             |
| mandatoryColums_applyGrpPwdPol | Mandatory  (if applyGrpPwdPol is Yes) |List of mandatory attributes required to be populated in the CSV file for applying password policy to groups in Active Directory | Default Values: ["PasswordPolicyName","GroupName"]                                                                 |
| createUser                     | Optional                              |Set this flag to Yes if user should be created, else set No                                                                      | Yes/No                                                                                                             |
| isPartner                      | Mandatory  (if createUser is Yes)     |Set this flag to Yes if user should be created in partner domain else set No                                                     | Yes/No                                                                                                             |
| mandatoryColums_createUser     | Mandatory  (if createUser is Yes)     |List of mandatory attributes required to be populated in the CSV file for creating users in Active Directory                     | Default Values: ["FirstName","LastName","Email","Path"]                                                            |
| updateMgr                      | Optional                              |Set this flag to Yes if user's manager should be updated, else set No                                                            | Yes/No                                                                                                             |
| mandatoryColums_updateMgr      | Mandatory  (if updateMgr is Yes)      |List of mandatory attributes required to be populated in the CSV file for updating users managers in Active Directory            | Default Values: ["UserSAMAccountName","MgrSAMAccountName"]                                                         |
| importLdif                     | Optional                              |Set this flag to Yes if ldif should be imported in Active Directory else set No                                                  | Yes/No                                                                                                             |
| ldifFileName                   | Mandatory  (if importLdif is Yes)     |Ldif file name to be imported                                                                                                    | Ldif file name                                                                                                     |
| sourceLdifFilePath             | Mandatory  (if importLdif is Yes)     |Path where the ldif is available on the host in which the script is being executed                                               | Path where the ldif is available on the host in which the script is being executed                                 |
| destLdifFilePath               | Mandatory  (if importLdif is Yes)     |Path on the DC where the ldif file will be copied                                                                                | Path on the DC where the ldif file will be copied                                                                  |

**NOTE**

*1) Don't alter the configuration template. Just key in the config values
2) Mandatory values needs to be provided to create groups
3) Do not change any default values

---

## Execute Script

Before you begin, ensure that the script has been unzipped in a folder with read and write permission.
The corresponding folder is identified as $SCRIPT_HOME below.

1. Start PowerShell as Administrator
2. Change directory to `$SCRIPT_HOME\configuration-scripts\ad-dc-setup\bin` folder
3. Run script
    ```powershell
    $ .\Configure_AD.ps1 -ConfigToLoad "ad-setup-config"
    ```

    ### Examples
1. To create custom domain with Debug logs on console
    ```powershell
	$ .\Configure_AD.ps1 -ConfigToLoad "ad-setup-config" -LogLevel "Debug"
	```
2. To create custom domain with Debug logs on console
    ```powershell
	$ .\Configure_AD.ps1 -ConfigToLoad "ad-setup-config" -LogLevel "Debug" -Type "File" -FileName "CustomADLogger"
	```
3. To create custom domain with Debug logs on console
    ```powershell
	$ .\Configure_AD.ps1 -ConfigToLoad "ad-setup-config" -LogLevel "Warn"
	```
---



package com.kpmg.advcyber.scim.mysql.util;

public final class Constants {
	
	//Operations
	public static final String ADD_OPERATION="add";
	public static final String REPLACE_OPERATION="replace";
	public static final String REMOVE_OPERATION="remove";
	public static final String EQUALS="eq";
	public static final String VALUE="value";
	public static final String TRUE="true";
	public static final String FALSE="false";
	
	//attributes
	public static final String MEMBERS="members";
	public static final String DISPLAY_NAME="displayName";
	public static final String DISPLAY="display";
	public static final String NAME="name";
	public static final String EMAILS="emails";
	public static final String ADDRESSES="addresses";
	public static final String PHONE_NUMBERS="phoneNumbers";
	public static final String ROLES="roles";
	public static final String TYPE="type";
	public static final String PRIMARY="primary";
	public static final String STREET_ADDRESS="streetAddress";
	public static final String LOCALITY="locality";
	public static final String REGION="region";
	public static final String POSTAL_CODE="postalCode";
	public static final String COUNTRY="country";
	public static final String WORK="work";
	public static final String GROUP_NAME="groupName";
	
	//patterns
	public static final String OPEN_SQ_BRACKET="[";
	public static final String CLOSE_SQ_BRACKET="]";
	public static final String PERIOD="\\.";
	
	//Date utils
	public static final String DATE_PATTERN="yyyy-MM-dd'T'HH:mm:ss.SSSz";
	
	//Regex patterns
	public static final String ENCLOSING_SINGLE_QUOTES="^\'|\'$";
	public static final String ENCLOSING_DOUBLE_QUOTES="^\"|\"$";
	public static final String BLANK_STRING="";
	
	//Schema
	public static final String ENTERPRISE_USER_SCHEMA="urn:ietf:params:scim:schemas:extension:enterprise:2.0:User";
}

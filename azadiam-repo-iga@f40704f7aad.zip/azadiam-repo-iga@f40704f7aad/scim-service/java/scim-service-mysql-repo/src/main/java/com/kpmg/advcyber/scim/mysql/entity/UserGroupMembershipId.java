package com.kpmg.advcyber.scim.mysql.entity;

import java.io.Serializable;


public class UserGroupMembershipId implements Serializable{
	private int groupid;
	private int userid;
	
	public UserGroupMembershipId() {
		
	}
	
	public UserGroupMembershipId(int userid, int groupid ) {
		this.userid=userid;
		this.groupid=groupid;
	}

	public int getGroupid() {
		return groupid;
	}

	public void setGroupid(int groupid) {
		this.groupid = groupid;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}	
}

package com.kpmg.advcyber.scim;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * Configuration class that forces Spring to scan this project for JPA Repository classes. 
 *
 */
@EnableAutoConfiguration
@EnableJpaRepositories
@Configuration
public class PersistenceJPAConfig {

}

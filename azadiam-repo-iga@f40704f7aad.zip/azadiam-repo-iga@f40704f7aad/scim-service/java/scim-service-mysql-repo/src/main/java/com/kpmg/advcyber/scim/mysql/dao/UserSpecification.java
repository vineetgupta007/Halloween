package com.kpmg.advcyber.scim.mysql.dao;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.domain.Specification;

import com.kpmg.advcyber.scim.core.filter.EqFilter;
import com.kpmg.advcyber.scim.core.filter.Filter;
import com.kpmg.advcyber.scim.core.filter.FilterType;
import com.kpmg.advcyber.scim.mysql.entity.User;

public class UserSpecification implements Specification<User>{
	
	Logger logger = LoggerFactory.getLogger(UserSpecification.class);
	private Filter filter;
	
	public UserSpecification(Filter filter) {
		this.filter = filter;
	}
	
	@Override
	public Predicate toPredicate(Root<User> root, CriteriaQuery<?> query,
			CriteriaBuilder builder) {
		logger.info("Entering toPredicate");
		//Only supports eq operator for now		
		if( filter == null ) {
			logger.debug("No filters found. Returning null");
			logger.info("Exiting toPredicate");
			return null;
		}
		
		if( filter.getFilterType().equals(FilterType.EQUAL) ) {
			logger.debug("EQUALS operator found");			
			if( filter instanceof EqFilter ) {
				EqFilter currentFilter = (EqFilter)filter;
				logger.info("Exiting toPredicate");
				return builder.equal(root.get(currentFilter.getAttributeName()), currentFilter.getAttributeValue());								
			} else {
				logger.debug("Filter is not instance of Equals filter!!!");
				logger.info("Exiting toPredicate");
				return null;
			}									
		} else {
			logger.debug("Operator not recognized or supported");
			logger.info("Exiting toPredicate");
			return null;
		}						
	}

	public Filter getFilter() {
		return filter;
	}

	public void setFilter(Filter filter) {
		this.filter = filter;
	}

}

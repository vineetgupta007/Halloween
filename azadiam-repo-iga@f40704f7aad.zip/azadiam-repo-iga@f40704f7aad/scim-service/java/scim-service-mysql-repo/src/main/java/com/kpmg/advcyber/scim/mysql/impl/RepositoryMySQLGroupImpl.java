package com.kpmg.advcyber.scim.mysql.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.kpmg.advcyber.scim.core.Repository;
import com.kpmg.advcyber.scim.core.domain.GroupResource;
import com.kpmg.advcyber.scim.core.domain.Member;
import com.kpmg.advcyber.scim.core.domain.PatchRequest;
import com.kpmg.advcyber.scim.core.domain.SearchParameter;
import com.kpmg.advcyber.scim.core.filter.Filter;
import com.kpmg.advcyber.scim.core.filter.FilterUtil;
import com.kpmg.advcyber.scim.mysql.dao.GroupDAO;
import com.kpmg.advcyber.scim.mysql.dao.GroupSpecificationBuilder;
import com.kpmg.advcyber.scim.mysql.dao.PatchGroupUtils;
import com.kpmg.advcyber.scim.mysql.entity.Group;
import com.kpmg.advcyber.scim.mysql.entity.UserGroupMembership;
import com.kpmg.advcyber.scim.mysql.repository.GroupRepository;
import com.kpmg.advcyber.scim.mysql.repository.UserGroupMembershipRepository;
import com.kpmg.advcyber.scim.mysql.util.Constants;

/**
 * Repository MySQL implementation class that processes incoming requests for 
 * CRUD operations on groups.
 * 
 *
 */
public class RepositoryMySQLGroupImpl implements Repository<GroupResource>{

	Logger logger = LoggerFactory.getLogger(RepositoryMySQLGroupImpl.class);

	private ApplicationContext applicationContext;

	@Override
	public Optional get(String id) throws Exception {
		logger.info("Entering get");
		try {
			//id being integer is specific to this repository implementation
			Integer groupId = Integer.valueOf(id);
		} catch ( NumberFormatException ex ) {
			logger.debug("Invalid id not an integer: {}",id);
			throw new Exception("Invalid id not an integer");
		}
		
		GroupRepository groupRepository = applicationContext.getBean(GroupRepository.class);
		Optional<Group> dbOptionalGroup = groupRepository.findById(Integer.valueOf(id));

		if( dbOptionalGroup.isPresent() ) {
			logger.debug("Found group: {}",id);
			GroupDAO groupDAO = applicationContext.getBean(GroupDAO.class);			
			GroupResource returnGroup = groupDAO.transformDBGroupToSCIM(dbOptionalGroup.get());

			//Checking for members
			if(returnGroup!=null) {
				returnGroup.setMembers(getGroupMemberships(id));				
			}	
			logger.info("Exiting get");
			return Optional.of(returnGroup);
		} else {
			logger.debug("Group not found: {}",id);
		}

		logger.info("Exiting get");
		return dbOptionalGroup;
	}

	private List<Member> getGroupMemberships(String groupid) {
		logger.info("Entering getGroupMemberships");
		UserGroupMembershipRepository memberRepository = applicationContext.getBean(UserGroupMembershipRepository.class);
		GroupDAO groupDAO = applicationContext.getBean(GroupDAO.class);

		List<UserGroupMembership> membershipList = memberRepository.getMembershipsByGroupId(Integer.valueOf(groupid));
		if( membershipList!=null && membershipList.size()>0 ) {
			List<Member>memberList = groupDAO.transformDBMembershipToSCIM(membershipList);

			if( memberList != null ) {
				logger.debug("Number of members found: {}",memberList);
			} else {
				logger.debug("No members found for group: {}",groupid);
			}

			logger.info("Exiting getGroupMemberships");
			return memberList;
		}
		logger.info("Exiting getGroupMemberships");
		return null;
	}

	private List<UserGroupMembership> getGroupDBMemberships(String groupid) {
		logger.info("Entering getGroupDBMemberships");
		UserGroupMembershipRepository memberRepository = applicationContext.getBean(UserGroupMembershipRepository.class);
		GroupDAO groupDAO = applicationContext.getBean(GroupDAO.class);

		List<UserGroupMembership> membershipList = memberRepository.getMembershipsByGroupId(Integer.valueOf(groupid));

		if( membershipList != null ) {
			logger.debug("Number of members found: {}",membershipList);
		} else {
			logger.debug("No members found for group: {}",groupid);
		}
		logger.info("Exiting getGroupDBMemberships");
		return membershipList;
	}

	@Override
	public List getAll(SearchParameter params) {
		logger.info("Entering getAll");
		logger.debug("Fetching repository bean from application context");
		GroupRepository groupRepository = applicationContext.getBean(GroupRepository.class);

		Specification<Group> searchSpec = null;
		if( params.getSearchFilter() != null && !params.getSearchFilter().equals(Constants.BLANK_STRING) ) {
			logger.debug("Search filter detected: "+params.getSearchFilter());

			//TO DO: move this to properties file and do replace by reading values from there
			String searchFilterString = params.getSearchFilter();
			if( searchFilterString.contains(Constants.DISPLAY_NAME) ) {
				searchFilterString = searchFilterString.replaceAll(Constants.DISPLAY_NAME, Constants.GROUP_NAME);
			}

			FilterUtil filterUtil = new FilterUtil();
			Filter searchFilter = filterUtil.buildFilter(searchFilterString);

			GroupSpecificationBuilder builder = new GroupSpecificationBuilder();
			searchSpec = builder.build(searchFilter);
		}				

		Page<Group> groupPage = null;

		if( searchSpec!=null ) {
			logger.debug("Searching using filter and pagination");
			groupPage = groupRepository.findAll(searchSpec, getPageableObject(params));
		} else {
			logger.debug("Searching using pagination");
			groupPage = groupRepository.findAll(getPageableObject(params));
		}

		if( groupPage != null ) {
			logger.debug("Retrieved number of groups: {}",groupPage.getSize());
			logger.info("Exiting getAll");

			List<Group> groupList = groupPage.getContent();

			GroupDAO groupDAO = applicationContext.getBean(GroupDAO.class);
			return groupDAO.transformDBGroupListToSCIMList(groupList);			
		} else {
			logger.debug("No groups retrieved");
		}
		logger.info("Exiting getAll");
		return null;
	}

	@Override
	public GroupResource save(GroupResource groupResource) {
		logger.info("Entering save");
		if( groupResource != null ) {			
			GroupDAO groupDAO = applicationContext.getBean(GroupDAO.class);

			//Saving group
			Group group = groupDAO.transformSCIMGroupToDB(groupResource);			
			GroupRepository groupRepository = applicationContext.getBean(GroupRepository.class);

			logger.debug("Saving group");
			Group savedGroup = groupRepository.save(group);
			GroupResource savedGroupResource = groupDAO.transformDBGroupToSCIM(savedGroup);

			//Saving memberships
			List<UserGroupMembership> membershipList = groupDAO.transformSCIMMembershiptoDB(groupResource);
			if( membershipList != null && membershipList.size()>0 ) {
				logger.debug("Saving members: {}",membershipList.size());
				UserGroupMembershipRepository memberRepository = applicationContext.getBean(UserGroupMembershipRepository.class);
				List<UserGroupMembership> savedMembershipList = memberRepository.saveAll(membershipList);

				List<Member> memberList = groupDAO.transformDBMembershipToSCIM(savedMembershipList);
				savedGroupResource.setMembers(memberList);
			}
			logger.info("Exiting save");
			return savedGroupResource;
		} 

		logger.debug("Group not saved!!");
		logger.info("Exiting save");
		return null;
	}

	@Override
	public GroupResource update(GroupResource groupResource) throws Exception {
		logger.info("Entering update");
		String groupId = groupResource.getId();
		try {
			//id being integer is specific to this repository implementation
			Integer id = Integer.valueOf(groupId);
		} catch ( NumberFormatException ex ) {
			logger.debug("Invalid id not an integer: {}",groupId);
			throw new Exception("Invalid id not an integer");
		}
		GroupDAO groupDAO = applicationContext.getBean(GroupDAO.class);
		Group currentGroup = groupDAO.transformSCIMGroupToDB(groupResource);
		List<UserGroupMembership>userGroupMembership =  groupDAO.transformSCIMMembershiptoDB(groupResource);

		logger.debug("Saving Group");
		GroupRepository groupRepository = applicationContext.getBean(GroupRepository.class);
		Group savedGroup = groupRepository.save(currentGroup);
		//Converting user object to scim format
		GroupResource returnGroup = groupDAO.transformDBGroupToSCIM(savedGroup);

		List<UserGroupMembership> updatedMembershipList = compareMembershipsAndUpdate( userGroupMembership,groupResource.getId() );
		List<Member> memberList = groupDAO.transformDBMembershipToSCIM(updatedMembershipList);
		returnGroup.setMembers(memberList);

		logger.info("Exiting update");
		return returnGroup;
	}

	private List<UserGroupMembership> compareMembershipsAndUpdate( List<UserGroupMembership> updateMemberList, String groupId ) {
		logger.debug("Entering compareMembershipsAndUpdate");
		List<UserGroupMembership> existingMembershipList = getGroupDBMemberships(groupId);
		UserGroupMembershipRepository memberRepository = applicationContext.getBean(UserGroupMembershipRepository.class);					

		//first process group memberships that need to be deleted
		if( existingMembershipList == null || existingMembershipList.size() == 0 ) { //no existing groups so nothing to delete
			logger.debug("No existing group memberships found for group: {}",groupId);			
		} else { //existing groups present
			logger.debug("Comparing existing and update groups");			
			if( updateMemberList == null || updateMemberList.size() == 0 ) { //delete all groups
				logger.debug("Update Membership list is empty. Deleting all groups");				
				memberRepository.deleteAll(existingMembershipList);

				logger.debug("Deleted all existing memberships for group: {}",groupId);
				logger.debug("Exiting compareMembershipsAndUpdate");
				return null;
			} else {
				// Compare existing membership list and update membership list 
				// Delete groups that are present in existing list but not present in update list
				List<UserGroupMembership> deleteMembershipList = new ArrayList<UserGroupMembership>();
				for( int i=0; i<existingMembershipList.size(); i++ ) { //find groups to delete
					UserGroupMembership currentExistingMembership = existingMembershipList.get(i);
					logger.debug("Processing existing member: {}",currentExistingMembership.getUserid());
					boolean isPresent = false;
					for( int j=0; j<updateMemberList.size(); j++ ) {
						UserGroupMembership currentUpdateMembership = updateMemberList.get(j);
						if( currentUpdateMembership.getUserid() == currentExistingMembership.getUserid() ) {
							isPresent = true;
							logger.debug("Found membership in existing and update list: {}",currentUpdateMembership.getUserid());
							break; //break inner loop
						}						
					}

					if( !isPresent ) { //Current membership is not present in update list. Mark for deletion.
						logger.debug("Adding current membership to delete list");
						deleteMembershipList.add(currentExistingMembership);
					}
				}
				//Deleting memberships that are not present in update membership list
				if( deleteMembershipList.size() >0 ) {
					logger.debug("Number of memberships to be deleted: {}",deleteMembershipList.size());					
					memberRepository.deleteAll(deleteMembershipList);					
				}				
			}						
		}

		// save memberships that are present in update list
		if( updateMemberList!=null && updateMemberList.size()>0 ) {
			logger.debug("Updating groups with patch request groups");				
			List<UserGroupMembership> savedMembershipList = memberRepository.saveAll(updateMemberList);			
			logger.debug("Exiting compareMembershipsAndUpdate");
			return savedMembershipList;
		}

		logger.debug("Exiting compareMembershipsAndUpdate");
		return null;
	}

	@Override
	public void delete(String id) throws Exception {
		logger.info("Entering delete");
		try {
			//id being integer is specific to this repository implementation
			Integer userId = Integer.valueOf(id);
		} catch ( NumberFormatException ex ) {
			logger.debug("Invalid id not an integer: {}",id);
			throw new Exception("Invalid id not an integer");
		}
		
		UserGroupMembershipRepository memberRepository = applicationContext.getBean(UserGroupMembershipRepository.class);
		Optional<GroupResource> groupResource = get(id);
		if( groupResource.isPresent() ) {
			List<Member> memberList = groupResource.get().getMembers();
			if(memberList!=null && memberList.size()>0) {
				for( int i=0; i<memberList.size(); i++ ) {
					Member currentMember = memberList.get(i);
					String memberid = currentMember.getValue();

					logger.debug("Deleting user: {}",currentMember);
					logger.debug(" group: {}",id);

					UserGroupMembership groupMember = new UserGroupMembership(Integer.valueOf(memberid), Integer.valueOf(id));
					memberRepository.delete(groupMember);
				}
			}			
		}

		GroupRepository groupRepository = applicationContext.getBean(GroupRepository.class);
		groupRepository.deleteById(Integer.valueOf(id));
		logger.debug("Deleted group: {}",id);
		logger.info("Entering delete");		
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;		
	}

	private Pageable  getPageableObject(SearchParameter params) {
		logger.info("Entering getPageableObject");
		int count = params.getCount();
		int startIndex= params.getStartIndex();

		//SCIM start index starts with 1. MySQL start index starts with 0. Compensating the difference.
		if( startIndex>0 ) {			
			startIndex-=1;
			logger.debug("Reducing start index by 1: {}",startIndex);
		}

		int pageNumber = (int) (startIndex / count) + ( startIndex % count );
		logger.debug("Calculated Page number: {}",pageNumber);
		PageRequest returnRequest = PageRequest.of(pageNumber, count);

		//PageRequest.of(page, size)
		logger.info("Exiting getPageableObject");
		return returnRequest;
	}
	
	@Override
	public GroupResource updatePartial(PatchRequest patchRequest, String groupId) throws Exception {
		logger.info("Entering updatePartial");
		if( patchRequest!=null && patchRequest.getOperations()!=null && patchRequest.getOperations().size()>0 ) {
			try {
				//id being integer is specific to this repository implementation
				Integer id = Integer.valueOf(groupId);
			} catch ( NumberFormatException ex ) {
				logger.debug("Invalid id not an integer: {}",groupId);
				throw new Exception("Invalid id not an integer");
			}
			Optional<GroupResource> existingGroup = get(groupId);
			
			if(existingGroup.isPresent()) {
				PatchGroupUtils patchUtils = new PatchGroupUtils();
				Map<String,GroupResource> updatedResource = patchUtils.convertPatchToResource(patchRequest, existingGroup.get());
				
				if( updatedResource!= null ) {
					if( updatedResource.get(Constants.ADD_OPERATION)!=null ) {
						addBulkGroupMemberships(updatedResource.get(Constants.ADD_OPERATION));
					}
					
					if( updatedResource.get(Constants.REMOVE_OPERATION)!=null ) {
						removeBulkGroupMemberships(updatedResource.get(Constants.REMOVE_OPERATION));
					}
				}

				logger.debug("Completed updating group");
				logger.info("Exiting updatePartial");
				//Microsoft recommends not to return any response body on patch operation for groups
				return null;				
			}			
		}
		logger.info("Entering updatePartial");
		return null;
	}
	
	private void addBulkGroupMemberships( GroupResource groupResource) {
		logger.info("Entering addBulkGroupMemberships");
		if( groupResource!=null && groupResource.getMembers()!=null && groupResource.getMembers().size()>0 ) {
			UserGroupMembershipRepository memberRepository = applicationContext.getBean(UserGroupMembershipRepository.class);
			GroupDAO groupDAO = applicationContext.getBean(GroupDAO.class);
			
			List<UserGroupMembership> memberList = groupDAO.transformSCIMMembershiptoDB(groupResource);
			memberRepository.saveAll(memberList);
		}
		logger.info("Exiting addBulkGroupMemberships");
	}
	
	private void removeBulkGroupMemberships(GroupResource groupResource) {
		logger.info("Entering removeBulkGroupMemberships");
		if( groupResource!=null && groupResource.getMembers()!=null && groupResource.getMembers().size()>0 ) {
			UserGroupMembershipRepository memberRepository = applicationContext.getBean(UserGroupMembershipRepository.class);
			GroupDAO groupDAO = applicationContext.getBean(GroupDAO.class);
			
			List<UserGroupMembership> memberList = groupDAO.transformSCIMMembershiptoDB(groupResource);
			
			if(memberList!=null && memberList.size()>0) {
				for( int i=0; i< memberList.size(); i++ ) {
					List<UserGroupMembership> resultList = memberRepository.findSpecificMembership(memberList.get(i).getGroupid(), memberList.get(i).getUserid());
					
					if( resultList!=null && resultList.size()>0 ) {
						logger.debug("Deleting membership: groupID: {} userid: {}",
								memberList.get(i).getGroupid(), memberList.get(i).getUserid());
						memberRepository.delete(memberList.get(i));
					} else {
						logger.debug("Current membership not found: groupID: {} userid: {}",
								memberList.get(i).getGroupid(), memberList.get(i).getUserid());
					}
				}				
			}			
		}
		logger.info("Exiting removeBulkGroupMemberships");
	}
}

package com.kpmg.advcyber.scim.mysql.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.domain.Specification;

import com.kpmg.advcyber.scim.core.filter.AndFilter;
import com.kpmg.advcyber.scim.core.filter.Filter;
import com.kpmg.advcyber.scim.core.filter.FilterType;
import com.kpmg.advcyber.scim.mysql.entity.User;

//TO do - Add mapping to convert scim attribute names to app application names
public class UserSpecificationBuilder {
	
	Logger logger = LoggerFactory.getLogger(UserSpecificationBuilder.class);
	
	//Only supporting AND operator for now without brackets
	public Specification<User> build( Filter filter ) {
		logger.debug("Entering build");
		
		logger.debug("Filter type: "+filter.getFilterType().getStringValue());
		//Checking for AND operator
		if( filter.getFilterType().equals(FilterType.AND) ) {
			logger.debug("AND operator found");
			if( filter instanceof AndFilter ) {
				AndFilter currentAndFilter = (AndFilter)filter;
				List<Filter> currentFilterList = currentAndFilter.getFilterList();
				
				if(currentFilterList!=null && currentFilterList.size() > 0) {					
					Specification<User> finalSpec = null;
					for( int i=0; i<currentFilterList.size(); i++ ) {
						Filter currentFilter = currentFilterList.get(i);
						logger.debug("Current filter: {}",currentFilter.getFilterType());
						
						UserSpecification currentSpec = new UserSpecification(currentFilter);
						
						if( i==0 ) {
							finalSpec = Specification.where(currentSpec);
						} else {
							finalSpec = finalSpec.and(currentSpec);
						}
					}
					
					logger.info("Exiting build");
					return finalSpec;
				} else {
					logger.debug("AND filter has a null list of filters!!!");
					logger.info("Exiting build");
					return null;
				}
				
				//return builder.equal(root.get(currentFilter.getAttributeName()), currentFilter.getAttributeName());								
			} else {
				logger.debug("Filter is not instance of AND filter");
				
				//return null;
			}					
			
		} else if( filter.getFilterType().equals(FilterType.EQUAL) ) {
			UserSpecification currentSpec = new UserSpecification(filter);
			logger.debug("found equals filter");
			return currentSpec;				
		}
		
		logger.debug("No valid filter type found");
		logger.info("Exiting build");
		return null;
	}
}

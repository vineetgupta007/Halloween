package com.kpmg.advcyber.scim.mysql.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.kpmg.advcyber.scim.mysql.entity.UserGroupMembership;

public interface UserGroupMembershipRepository extends JpaRepository<UserGroupMembership,String>{
	@Query("select new UserGroupMembership(userid, groupid) from UserGroupMembership where groupid=:groupid")
    public List<UserGroupMembership> getMembershipsByGroupId(@Param("groupid") int groupid);
	
	@Query("select new UserGroupMembership(userid, groupid) from UserGroupMembership where groupid=:groupid and userid=:userid")
    public List<UserGroupMembership> findSpecificMembership(@Param("groupid") int groupid, @Param("userid") int userid);
}

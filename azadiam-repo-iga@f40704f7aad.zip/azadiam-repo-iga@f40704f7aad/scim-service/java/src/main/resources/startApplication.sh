# Start the scim application

if [ -z $ENV_NAME ]; then
 echo "Profile not set: ENV_NAME"
 exit 1
fi

# Calling script to set environment variables

#Update the actual base path before deploying the application
export SCIM_BASE_PATH=<BASE PATH>
echo "SCIM_BASE_PATH: "$SCIM_BASE_PATH

export SCIM_JAR=${SCIM_BASE_PATH}/lib/scim-service-rest-1.0-SNAPSHOT.jar
echo "SCIM_JAR:"$SCIM_JAR

export SCIM_LIB_PATH="${SCIM_BASE_PATH}/lib,${SCIM_BASE_PATH}/ThirdParty"
echo "SCIM_LIB_PATH: "$SCIM_LIB_PATH

export MAIN_CLASS_NAME="com.kpmg.advcyber.scim.rest.Application"
echo "MAIN_CLASS_NAME: "$MAIN_CLASS_NAME

export CONFIG_FILE_NAME="${SCIM_BASE_PATH}/config/"
echo "CONFIG_FILE_NAME: "$CONFIG_FILE_NAME

export PID_FILE_NAME=${SCIM_BASE_PATH}/bin/pid.txt
echo "PID_FILE_NAME: "$PID_FILE_NAME

export LOGS_LOCATION="${SCIM_BASE_PATH}/logs/"
echo "LOGS_LOCATION: "$LOGS_LOCATION

# Starting springboot appliaction
nohup java -cp $SCIM_JAR -Dloader.path=$SCIM_LIB_PATH -Dloader.main=$MAIN_CLASS_NAME -Dspring.config.location=$CONFIG_FILE_NAME org.springframework.boot.loader.PropertiesLauncher &

processPid=$!
echo "pid: $processPid"

#Saving Process ID to file
echo $processPid >> $PID_FILE_NAME

#!/bin/sh
# setupScimService.sh
# Version 1.0 
# Create SCIM as a Service, and set up for auto-start on system reboot.
#

echo "Starting SCIM service configuration script."

#Set environment variables
##SCIM environment name
read -p "Enter the SCIM application environment name (e.g. dev or prod) : " SCIMENVNAME

##Service name for SCIM
read -p "Enter the service name for SCIM (e.g. scimservice) : " SERVICENAME

if [ -f "/etc/init.d/$SERVICENAME" ]; then
    echo "ERROR:: Service name $SERVICENAME already exists. Please try with different unique name again."
    exit
else
    echo "Valid service name: $SERVICENAME"
fi

##SCIM User
read -p "Enter the username to run the SCIM service : " SCIMUSER

if id "$SCIMUSER" &>/dev/null; then
    echo "User found: $SCIMUSER"
else
    echo "ERROR:: User not found: $SCIMUSER . Please try again with an existing user."
    exit
fi

##SCIM Base Path
read -p "Enter the base path for SCIM (e.g. /apps/iam/scimapplication) : " SCIMBASEPATH

if [ -d "$SCIMBASEPATH" ]; then
    echo "Path $SCIMBASEPATH is valid."
else
    echo "ERROR:: Invalid path: $SCIMBASEPATH . Please try again with valid SCIM base path."
    exit
fi

#varReplace function is used to replace pattern text with variables in target file
varReplace() {
    sed -i "s|$1|$2|g" $3
}

#Create SCIM Service Tomcat as Linux Service and configure to auto-start on system reboot.
if [ -f $SCIMBASEPATH/bin/scim.sh.template ]; then
    echo "#######################################################################"
    echo "START: SCIM Service Registration."
    echo "Service Name: $SERVICENAME"
    echo "SCIM Base Path: $SCIMBASEPATH"
    echo "SCIM Environment: $SCIMENVNAME"
    echo "User for SCIM Service: $SCIMUSER"

    #Create service file from template
    echo "Creating scim service from template: $SCIMBASEPATH/bin/scim.sh.template"
    cp -p $SCIMBASEPATH/bin/scim.sh.template $SCIMBASEPATH/bin/$SERVICENAME

    #Set variables in service script
    echo "Replacing service variables with input data."
    varReplace "%%SCIMENVNAME%%" "$SCIMENVNAME" "$SCIMBASEPATH/bin/$SERVICENAME"
    varReplace "%%SCIMBASEPATH%%" "$SCIMBASEPATH" "$SCIMBASEPATH/bin/$SERVICENAME"
    varReplace "%%SCIMUSER%%" "$SCIMUSER" "$SCIMBASEPATH/bin/$SERVICENAME"

    #Register service
    echo "Registering SCIM service in /etc/init.d"
    mv $SCIMBASEPATH/bin/$SERVICENAME /etc/init.d/$SERVICENAME
    chmod 755 /etc/init.d/$SERVICENAME

    echo "Registered service: $SERVICENAME"

    #Set to auto start on system reboot
    echo "Setting $SERVICENAME to auto-start on system reboots."
    chkconfig --add $SERVICENAME
    chkconfig --level 2345 $SERVICENAME on

    echo "Added service $SERVICENAME for auto start on system reboot."
    echo "END: SCIM Service Registration."
    echo "#######################################################################"
else
    echo "ERROR:: scim.sh.template file is not found at $SCIMBASEPATH/bin . Please check the binaries for template file."
fi

echo "Exiting SCIM service configuration script."

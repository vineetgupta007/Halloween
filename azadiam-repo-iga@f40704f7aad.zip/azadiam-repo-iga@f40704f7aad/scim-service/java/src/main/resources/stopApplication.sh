# Script to find PID of SCIM application and kill it

#Calling script to set environment variables

#Update the actual base path before deploying the application
export SCIM_BASE_PATH=<BASE PATH>
echo "SCIM_BASE_PATH: "$SCIM_BASE_PATH


PID_FILE_NAME=${SCIM_BASE_PATH}/bin/pid.txt
echo "PID_FILE_NAME: "$PID_FILE_NAME

#Checking if pid file exists
if [ ! -f $PID_FILE_NAME ]; then
 echo "PID file not found. Searching process and killing application."
 PID=`ps -eaf | grep com.kpmg.scim.Application | grep -v grep | awk '{print $2}'`
else
 echo "Found PID file"
 PID=`cat ./pid.txt`
fi

# killing process
if [[ "" !=  "$PID" ]]; then
  echo "killing $PID"
  kill -9 $PID
  rm $PID_FILE_NAME
fi

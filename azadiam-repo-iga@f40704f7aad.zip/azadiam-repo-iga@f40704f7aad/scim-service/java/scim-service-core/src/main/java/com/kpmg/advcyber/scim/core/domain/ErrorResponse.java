package com.kpmg.advcyber.scim.core.domain;

import java.util.ArrayList;
import java.util.List;

public class ErrorResponse {

	List<String> schemas;
	private String status;
    private String detail;
    //Todo: Add scimType values
    
    public ErrorResponse() {
    	schemas = new ArrayList<String>();
    	schemas.add("urn:ietf:params:scim:api:messages:2.0:Error");
    }
    
	public List<String> getSchemas() {
		return schemas;
	}
	public void setSchemas(List<String> schemas) {
		this.schemas = schemas;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
    
    
}

package com.kpmg.advcyber.scim.core.domain;

import java.net.URI;

public class Member {
	private String value;
	private URI ref;
	private String display;
	
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}
	
	public URI getRef() {
		return ref;
	}
	
	public void setRef(URI ref) {
		this.ref = ref;
	}
	
	public String getDisplay() {
		return display;
	}
	
	public void setDisplay(String display) {
		this.display = display;
	}
	
	public String toString() {
		String returnString = " ----Member Object starts---- value: "+value+" display: "+display+
				" ref: "+ref+" ----Member Object ends---- ";
		return returnString;
	}
}

package com.kpmg.advcyber.scim.core.domain;

import java.net.URI;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class UserResource extends BaseResource {
	private String userName;
	private Name name;
	private String displayName;
	private String nickName;
	private URI profileUrl;
	private String title;
	private String userType;
	private String preferredLanguage;
	private String locale;
	private String timezone;
	private Boolean active;
	private String password;
	private List<Email> emails;
	private List<PhoneNumber> phoneNumbers;
	private List<InstantMessagingAddress> ims;
	private List<Photo> photos;
	private List<Address> addresses;
	private List<Group> groups;
	private List<Entitlement> entitlements;
	private List<Role> roles;
	private List<X509Certificate> x509Certificates;
	
	public UserResource() {
		Set<String>schemaList = new HashSet<String>();
		schemaList.add("urn:ietf:params:scim:schemas:core:2.0:User");
		super.setSchemas(schemaList);
		
		Meta meta = new Meta();
		meta.setResourceType("User");
		super.setMeta(meta);
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public Name getName() {
		return name;
	}
	
	public void setName(Name name) {
		this.name = name;
	}
	
	public String getDisplayName() {
		return displayName;
	}
	
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	
	public String getNickName() {
		return nickName;
	}
	
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	
	public URI getProfileUrl() {
		return profileUrl;
	}
	
	public void setProfileUrl(URI profileUrl) {
		this.profileUrl = profileUrl;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getUserType() {
		return userType;
	}
	
	public void setUserType(String userType) {
		this.userType = userType;
	}
	
	public String getPreferredLanguage() {
		return preferredLanguage;
	}
	
	public void setPreferredLanguage(String preferredLanguage) {
		this.preferredLanguage = preferredLanguage;
	}
	
	public String getLocale() {
		return locale;
	}
	
	public void setLocale(String locale) {
		this.locale = locale;
	}
	
	public String getTimezone() {
		return timezone;
	}
	
	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}
	
	public Boolean getActive() {
		return active;
	}
	
	public void setActive(Boolean active) {
		this.active = active;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public List<Email> getEmails() {
		return emails;
	}
	
	public void setEmails(List<Email> emails) {
		this.emails = emails;
	}
	
	public List<PhoneNumber> getPhoneNumbers() {
		return phoneNumbers;
	}
	
	public void setPhoneNumbers(List<PhoneNumber> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}
	
	public List<InstantMessagingAddress> getIms() {
		return ims;
	}
	
	public void setIms(List<InstantMessagingAddress> ims) {
		this.ims = ims;
	}
	
	public List<Photo> getPhotos() {
		return photos;
	}
	
	public void setPhotos(List<Photo> photos) {
		this.photos = photos;
	}
	
	public List<Address> getAddresses() {
		return addresses;
	}
	
	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}
	
	public List<Group> getGroups() {
		return groups;
	}
	
	public void setGroups(List<Group> groups) {
		this.groups = groups;
	}
	
	public List<Entitlement> getEntitlements() {
		return entitlements;
	}
	
	public void setEntitlements(List<Entitlement> entitlements) {
		this.entitlements = entitlements;
	}
	
	public List<Role> getRoles() {
		return roles;
	}
	
	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}
	
	public List<X509Certificate> getX509Certificates() {
		return x509Certificates;
	}
	
	public void setX509Certificates(List<X509Certificate> x509Certificates) {
		this.x509Certificates = x509Certificates;
	}
	
	public String toString() {
		String returnString = "id: "+getId()+" userName: "+userName+" active: "+active+" externalId: "+getExternalId();
		
		if( name != null ) {
			returnString += name.toString();
		}
		
		if( emails != null ) {
			for( int i=0; i<emails.size(); i++ ) {
				if(emails.get(i) != null) {
					returnString += emails.get(i).toString();
				}				
			}
		}
		
		if( addresses != null ) {
			for( int i=0; i<addresses.size(); i++ ) {
				if(addresses.get(i) != null) {
					returnString += addresses.get(i).toString();
				}				
			}
		}
		
		if( phoneNumbers != null ) {
			for( int i=0; i<phoneNumbers.size(); i++ ) {
				if(phoneNumbers.get(i) != null) {
					returnString += phoneNumbers.get(i).toString();
				}				
			}
		}
		
		if( roles != null ) {
			for( int i=0; i<roles.size(); i++ ) {
				if(roles.get(i) != null) {
					returnString += roles.get(i).toString();
				}				
			}
		}

		if( super.getCustomAttributes() != null && super.getCustomAttributes().size() >0 ) {
			returnString += " ----Custom attributes Start---- ";
			for (Map.Entry<String, Object> entry : super.getCustomAttributes().entrySet()) {
				returnString += " key: "+entry.getKey()+"Value: "+entry.getValue().toString()+" ";
			}
			returnString += " ----Custom attributes End---- ";
		}
		return returnString;
	}
}

package com.kpmg.advcyber.scim.core.domain;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ListResponse {
	private List<String> schemas;
    private int totalResults;
    private int startIndex;
    private int itemsPerPage;

    @JsonProperty("Resources")
    private List<? extends BaseResource> resources;
    
    public ListResponse() {
    	this.schemas = new ArrayList<String>();
    	schemas.add("urn:ietf:params:scim:api:messages:2.0:ListResponse");
    }

	public List<String> getSchemas() {
		return schemas;
	}

	public void setSchemas(List<String> schemas) {
		this.schemas = schemas;
	}

	public int getTotalResults() {
		return totalResults;
	}

	public void setTotalResults(int totalResults) {
		this.totalResults = totalResults;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	public int getItemsPerPage() {
		return itemsPerPage;
	}

	public void setItemsPerPage(int itemsPerPage) {
		this.itemsPerPage = itemsPerPage;
	}

	public List<? extends BaseResource> getResources() {
		return resources;
	}

	public void setResources(List<? extends BaseResource> resources) {
		this.resources = resources;
	}
    
    
}

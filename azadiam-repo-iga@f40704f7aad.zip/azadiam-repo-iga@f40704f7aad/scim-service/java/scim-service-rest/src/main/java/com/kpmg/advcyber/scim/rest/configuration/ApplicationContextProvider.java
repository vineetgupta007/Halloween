package com.kpmg.advcyber.scim.rest.configuration;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * Class to provide application context to backend persistence layer.
 * This is so that application context can be provided to the persistence layer
 * which is instantiated by the repo factory and not by Spring framework.
 * 
 *
 */
@Component
public class ApplicationContextProvider implements ApplicationContextAware{
	 private static ApplicationContext context;
// To Do: Check usage of static 
	    public static ApplicationContext getApplicationContext() {
	        return context;
	    }

	    @Override
	    public void setApplicationContext(ApplicationContext ac)
	            throws BeansException {
	        context = ac;
	    }
}

package com.kpmg.advcyber.scim.rest.persistence.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import com.kpmg.advcyber.scim.core.Repository;
import com.kpmg.advcyber.scim.core.domain.GroupResource;
import com.kpmg.advcyber.scim.core.domain.PatchRequest;
import com.kpmg.advcyber.scim.core.domain.SearchParameter;

/**
 * This is a dummy implementation of the persistence layer. The purpose of this class is to be able
 * to deploy the SCIM REST service and test without having to implement any repository plug-in.
 *
 */
public class RepositoryDefaultGroupImpl implements Repository<GroupResource> {

	Logger logger = LoggerFactory.getLogger(RepositoryDefaultGroupImpl.class);
			
	private ApplicationContext applicationContext;
	
	@Override
	public Optional get(String id) {
		logger.debug("Reached Default get group by id method");
		return null;
	}

	@Override
	public List getAll(SearchParameter params) {
		logger.debug("Reached Default getAll group method");
		return null;
	}

	@Override
	public GroupResource save(GroupResource t) {
		logger.debug("Reached Default save group method");
		return null;
	}

	@Override
	public GroupResource update(GroupResource t) {
		logger.debug("Reached Default update group method");
		return null;
	}

	@Override
	public void delete(String id) {
		logger.debug("Reached Default delete group method");		
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext=applicationContext;		
	}

	@Override
	public GroupResource updatePartial(PatchRequest patchRequest,
			String resourceId) throws Exception {
		logger.debug("Reached Default updatePartial group method");
		return null;
	}


}

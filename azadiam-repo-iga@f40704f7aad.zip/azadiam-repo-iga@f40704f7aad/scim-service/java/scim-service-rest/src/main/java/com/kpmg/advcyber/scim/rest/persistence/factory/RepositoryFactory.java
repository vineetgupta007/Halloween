package com.kpmg.advcyber.scim.rest.persistence.factory;

import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kpmg.advcyber.scim.core.Repository;
import com.kpmg.advcyber.scim.rest.configuration.ApplicationContextProvider;
import com.kpmg.advcyber.scim.rest.configuration.BackendMapping;
import com.kpmg.advcyber.scim.rest.util.Constants;

/**
 * This class finds out the correct backend repository plugin instance to return based on the 
 * details provided by Service. This abstracts the persistence layer and allows to easily plug-in 
 * different types of repository implementations.
 * 
 *
 * @param <T>
 */
public class RepositoryFactory<T> {
	
	Logger logger = LoggerFactory.getLogger(RepositoryFactory.class);	

	private Repository instance;
	
	private boolean isInitialized = false;
	
	public Repository getInstance() {
		return instance;
	}

	public void setInstance(Repository instance) {
		this.instance = instance;
	}

	public void setInitialized(boolean isInitialized) {
		this.isInitialized = isInitialized;
	}
	
	private void initializeRepoFactory(String entityName, BackendMapping backendMapping) throws Exception {
		logger.info("Entering initializeRepoFactory");	
		if( backendMapping == null ) {
			logger.debug("Properties file not loaded");
			throw new Exception("Properties file not loaded");			
		}
		
		//Fetch repository name and entity types from properties
		String repoType = (String)backendMapping.getBackend().get(Constants.REPOSITORY);
		if( entityName!=null && !entityName.equals("")) {
			//Creating property name
			logger.debug("Current Entity Type: {}",entityName);
			logger.debug("Repo Type: {}",repoType);
			String propertyName = repoType.toLowerCase()+entityName.toLowerCase();
			logger.debug("Checking propertyname: {}",propertyName);

			//Fetching class name from properties file
			String classname = (String)backendMapping.getBackend().get(propertyName);
			if( classname == null || classname.equals("") ) {
				logger.info("Exiting getObject");
				throw new Exception("Invalid persistence repository name passed");
			}		
			logger.debug("Persistence implementation classname retrieved from properties is: {}",classname);

			//Get instance of backend repository
			instance = (Repository<T>)Class.forName(classname).newInstance();
			logger.debug("Got the backend repository class instance");
			instance.setApplicationContext(ApplicationContextProvider.getApplicationContext());
		} else {
			throw new Exception("Invalid entity type passed");
		}
		
		this.setInitialized(true);
		logger.info("Exiting initializeRepoFactory");		
	}
		
	public Repository<T> getObject(String entityName, BackendMapping backendMapping) throws Exception {
		logger.info("Entering getObject");
		
		if( !this.isInitialized ) {
			initializeRepoFactory(entityName, backendMapping);
		}
		
		if( this.getInstance() == null || this.getInstance() == null ) {
			throw new Exception("Repository Factory not initialized");
		}
		
		logger.info("Exiting getObject");
		return this.getInstance();
	}
	
	public boolean isInitialized() {		
		return this.isInitialized;
	}
}

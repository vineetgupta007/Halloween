package com.kpmg.advcyber.scim.rest.configuration;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 * Class to read the backend configuration from the application.properties file.
 * 
 *
 */
@Component
@ConfigurationProperties(prefix="persistence")
public class BackendMapping {
	
	private Map<String, String> backend;

	public void setBackend(Map<String, String> backend) {
		this.backend = backend;
	}

	public Map<String, String> getBackend() {
		return backend;
	}

}

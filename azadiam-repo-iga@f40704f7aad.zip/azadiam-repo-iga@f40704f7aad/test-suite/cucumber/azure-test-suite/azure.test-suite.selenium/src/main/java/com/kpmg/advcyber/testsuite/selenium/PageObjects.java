package com.kpmg.advcyber.testsuite.selenium;


import org.apache.log4j.Logger;
import org.openqa.selenium.By;

/**
 *
 * This class is used manipulate  Xpath of UI element
 */
public class PageObjects {
	
	private static Logger log = Logger.getLogger(PageObjects.class);
	//private static GenericUtils genericUtils = new GenericUtils();
				
	/**
	 * @param application
	 * @param elementName
	 * @return
	 * @throws Exception
	 * Accept element Name return Ui element identifier
	 */
	public static By getElementIdentifier(String elementNameXpath) throws Exception{
		//System.out.println("In the getElementIdentifierforInvestigatorPortal");
		By element=getIdentifier(elementNameXpath);;
//		if(application.equalsIgnoreCase("Azure")) {
////			Properties properties = genericUtils.readPropertiesFile(genericUtils.getObjectsFilepath());
////			String elementIdentifier = properties.getProperty(elementName);
//			element = 
//		}
		
		
		return element;
	}
	

	

	/**
	 * @param elementIdentifier
	 * @return
	 * Accept xPath and return identifier 
	 */
	private static By getIdentifier(String elementIdentifier){
		//System.out.println("In the getIdentifier");
		By byIdentifier=null;
		String[] stringArray =  elementIdentifier.split("##");
		String byMethod = null;
		String value=null;
		
		if(stringArray.length==2){
			byMethod = stringArray[0].toUpperCase().toString();
			value = stringArray[1];
			
			switch (byMethod) {
				case "CLASSNAME":
					byIdentifier = By.className(value);
					break;
					
				case "CSSSELECTOR":
					byIdentifier = By.cssSelector(value);
					break;
					
				case "ID":
					byIdentifier = By.id(value);
					break;
					
				case "LINKTEXT":
					byIdentifier = By.linkText(value);
					break;
					
				case "NAME":
					byIdentifier = By.name(value);
					break;
					
				case "PARTIALLINKTEXT":
					byIdentifier = By.partialLinkText(value);
					break;
					
				case "TAGNAME":
					byIdentifier = By.tagName(value);
					break;
					
				case "XPATH":
					byIdentifier = By.xpath(value);
					break;
					
				default:
					log.error( byMethod + " - Element Identifier is not valid." );
			}
		}else{
			log.error( elementIdentifier + " - Element Identifier is not valid in the PageObjects.properties." );
		}
		return byIdentifier;
	}
	
	
}

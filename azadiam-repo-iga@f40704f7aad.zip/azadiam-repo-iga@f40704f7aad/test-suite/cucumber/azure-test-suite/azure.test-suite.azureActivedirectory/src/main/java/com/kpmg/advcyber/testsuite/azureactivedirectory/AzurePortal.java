/**
 * 
 */
package com.kpmg.advcyber.testsuite.azureactivedirectory;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.kpmg.advcyber.testsuite.selenium.SeleniumUIOperation;
import com.kpmg.advcyber.testsuite.selenium.SeleniumWebDriver;


/**
 * @author 
 * his class is used perform all operation  on Azure Portal 
 */
public class AzurePortal {
	private static Logger log = Logger.getLogger(AzurePortal.class);
	private String configFilePath = "Resources/config.properties";
	private String azureXpathConfigfilePath = "Resources/azure.properties";
	
	Properties configProperties = null;
	Properties azureXpathProperties = null;
	SeleniumWebDriver webDriverUtils;
	SeleniumUIOperation loginpage ;
	
	public AzurePortal(SeleniumWebDriver webDriverUtils,SeleniumUIOperation loginpage) throws Exception {
		this.webDriverUtils = webDriverUtils;
		this.loginpage =loginpage;
		
		configProperties = new Properties();
		
		
		File configfileLocation = new File(configFilePath);
		System.out.println(configfileLocation.getAbsolutePath());
		System.out.println(configfileLocation.getPath());
//		URL url = getClass().getResource(configFilePath);
//		String configfileLocation = url.getFile();
	
		InputStream inputStream = new FileInputStream(configfileLocation);
		configProperties.load(inputStream);
		
		File azurefileLocation = new File(azureXpathConfigfilePath);
		
		azureXpathProperties  = new Properties();
		inputStream = new FileInputStream(azurefileLocation);
		azureXpathProperties.load(inputStream);
	}
	/**
	 * @param imageName
	 * @param brandingText
	 * @return
	 * @throws Exception
	 * Accept logo image unique id and branding text and validate on Azure portal
	 */
	public boolean checkBranding(String imageName, String brandingText) throws Exception  {
		log.info("------Start step " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
		boolean result=false;
		try {
			webDriverUtils.setUpDriver(configProperties.getProperty("webdriver.driver"),configProperties.getProperty("webdriver.browser.headless")); 
			webDriverUtils.launchApplication(configProperties.getProperty("azure.webdriver.base.url"));
			
			result = loginpage.fillTextField(configProperties.getProperty("Azure.login.user"), azureXpathProperties.getProperty("azure.loginPageUserName.txt.userName"));
			if(result) {
				result = loginpage.clickOnBUtton(azureXpathProperties.getProperty("azure.loginPageUserName.btn.next"));
				if(result) {
					String imageSrc = loginpage.getImageSrc(azureXpathProperties.getProperty("azure.loginPagePassword.img.logoImage"));
					if(imageSrc.contains(imageName)) {
						result = true;
					}else {
						result = false;
					}
				}
				
				if(result) {
					String actualText = loginpage.getLabelText(azureXpathProperties.getProperty("azure.loginPagePassword.lbl.welcomelabel"));
					if(brandingText.equalsIgnoreCase(actualText)) {
						result = true;
					}else {
						result = false;
					}
				}
				
			}
			
		}catch(Exception ex) {
			log.error("Branding verfication not triggered");
			log.error(Arrays.toString(ex.getStackTrace()));
			throw ex;
		}finally {
			webDriverUtils.shutDownDriver();
		}
		log.info("result :" + result);
		log.info("------End step " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
		return result;
	}
	
	/**
	 * @param validateString
	 * @return
	 * @throws Exception
	 * This method checkAuthenicationonPortal
	 */
	public boolean validateAuthenticationonPortal(String portalUrl , String userName,String password,String validateText) throws Exception  {
		log.info("------Start step " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
		boolean result=false;
		try {
			webDriverUtils.setUpDriver(configProperties.getProperty("webdriver.driver"),configProperties.getProperty("webdriver.browser.headless")); 
			webDriverUtils.launchApplication(portalUrl);
			
			boolean userFillresult = loginpage.fillTextField(userName, azureXpathProperties.getProperty("azure.loginPageUserName.txt.userName"));
			boolean buttonClickresult = loginpage.clickOnBUtton(azureXpathProperties.getProperty("azure.loginPageUserName.btn.next"));
			if(userFillresult && buttonClickresult) {
				userFillresult = loginpage.fillTextField(password, azureXpathProperties.getProperty("azure.loginPagePassword.txt.Password"));
				buttonClickresult = loginpage.clickOnBUtton(azureXpathProperties.getProperty("azure.loginPageUserName.btn.next"));
				if(userFillresult && buttonClickresult) {
					String actualText = loginpage.getLabelText(azureXpathProperties.getProperty("Azure.moreinfomationPage.lbl.information"));
					System.out.println("actualText :" + actualText);
					if(validateText.equals(actualText)) {
						result = true;
					}else {
						result = false;
					}
					
					
				}
			}
			
		}catch(Exception ex) {
			log.error("Branding verfication not triggered");
			log.error(Arrays.toString(ex.getStackTrace()));
			throw ex;
		}finally {
			webDriverUtils.shutDownDriver();
		}
		log.info("result :" + result);
		log.info("------End step " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
		return result;
	}
}

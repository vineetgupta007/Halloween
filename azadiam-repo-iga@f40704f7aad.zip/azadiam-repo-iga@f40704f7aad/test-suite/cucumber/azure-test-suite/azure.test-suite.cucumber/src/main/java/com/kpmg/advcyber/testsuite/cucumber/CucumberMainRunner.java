/**
 * 
 */
package com.kpmg.advcyber.testsuite.cucumber;

import java.io.File;

import org.apache.log4j.PropertyConfigurator;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;



/**
 * @author kpmg
 *
 */
@RunWith(Cucumber.class)
@CucumberOptions(glue = {
		"com.kpmg.advcyber.testsuite"
},
features= {
		
		"features/AzureBranding.feature"
}
)
public class CucumberMainRunner {
	@BeforeClass
	public static void setup() throws Exception {
		String logFile = "Resources/log4j.properties";
		File file = new File(logFile);
		System.out.println(file.getAbsolutePath());
		PropertyConfigurator.configure(file.getAbsolutePath());
	}
}

package com.kpmg.advcyber.testsuite.branding;


import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.apache.log4j.Logger;

import com.kpmg.advcyber.testsuite.selenium.SeleniumUIOperation;
import com.kpmg.advcyber.testsuite.selenium.SeleniumWebDriver;


import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.When;

/**
 *
 * This is class is used to perform  Azure Branding feature cucumber step definition 
 */
public class AzureBrandingStepDefinition {
	private static Logger log = Logger.getLogger(AzureBrandingStepDefinition.class);
	
	SeleniumWebDriver webDriverUtils;
	SeleniumUIOperation loginpage ;
	AzureBranding azureBradning;
	public AzureBrandingStepDefinition(SeleniumWebDriver webDriverUtils,SeleniumUIOperation loginpage, AzureBranding azureBradning) {
		this.webDriverUtils = webDriverUtils;
		this.loginpage = loginpage;
		this.azureBradning = azureBradning;
		
	}
	public AzureBrandingStepDefinition() throws Exception {
		webDriverUtils = new SeleniumWebDriver();
		loginpage = new SeleniumUIOperation(webDriverUtils);
		azureBradning = new AzureBranding(webDriverUtils,loginpage);
	}
	
	/**
	 * @param data
	 * @throws Exception
	 * Perform When operation of Azure Branding steps
	 */
	@When("^Check Azure Branding$")
	public void check_Azure_Branding(DataTable data) throws Exception{
		log.info("------Start step " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
		
		HashMap<String, Object> inputData=new HashMap<String, Object>();
		List<Map<String,Object>> inputRows = data.asMaps(String.class, Object.class);
		
		for(Map<String,Object> row:inputRows) {
			inputData.put((String) row.get("AttributeName"), row.get("AttributeValue"));
		}
		log.info("Input Data " + inputData);
		
		boolean success = azureBradning.checkBranding((String)inputData.get("BrandingFileName"),(String)inputData.get("BrandingText"));
		log.info("success :" + success);
		if(success) {
			log.info("This Use Case is successfully completed");
		}else {
			log.info("------End step with error " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
			throw new Exception("This use has error >>>> Logo OR Branding Text mismatch");
		}
		log.info("------End step " + new Object(){}.getClass().getEnclosingMethod().getName() +"------");
			
	}
	
}
